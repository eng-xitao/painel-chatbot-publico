"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { BarChart3, Bell, ChevronRight, LineChart, Menu, MessageSquare, Play, Settings, X } from "lucide-react"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { ModeToggle } from "@/components/mode-toggle"
import Image from "next/image"

interface MainLayoutProps {
  children: React.ReactNode
}

export function MainLayout({ children }: MainLayoutProps) {
  const pathname = usePathname()
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  const routes = [
    {
      href: "/",
      label: "Dashboard",
      icon: BarChart3,
      active: pathname === "/",
    },
    {
      href: "/alertas",
      label: "Alertas",
      icon: Bell,
      active: pathname === "/alertas",
    },
    {
      href: "/backtest",
      label: "Backtest",
      icon: LineChart,
      active: pathname === "/backtest",
    },
    {
      href: "/auto-trading",
      label: "Auto Trading",
      icon: Play,
      active: pathname === "/auto-trading",
    },
    {
      href: "/configuracoes",
      label: "Configurações",
      icon: Settings,
      active: pathname === "/configuracoes",
    },
    {
      href: "/telegram-messages",
      label: "Mensagens Telegram",
      icon: MessageSquare,
      active: pathname === "/telegram-messages",
    },
  ]

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-30 flex h-16 items-center gap-4 border-b bg-background px-4 md:px-6">
        <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" className="md:hidden">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Toggle Menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-72">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/FlexInvest.jpg-mvQVRz9lChkrNY9mWowFvjJp5YSxwx.jpeg"
                  alt="FlexInvest Logo"
                  width={120}
                  height={60}
                  className="h-auto"
                />
              </div>
              <Button variant="ghost" size="icon" onClick={() => setIsMobileMenuOpen(false)}>
                <X className="h-5 w-5" />
                <span className="sr-only">Close Menu</span>
              </Button>
            </div>
            <nav className="mt-8 flex flex-col gap-2">
              {routes.map((route) => (
                <Link
                  key={route.href}
                  href={route.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={cn(
                    "flex items-center gap-2 rounded-md px-3 py-2 text-sm transition-colors",
                    route.active ? "bg-accent text-accent-foreground" : "hover:bg-accent hover:text-accent-foreground",
                  )}
                >
                  <route.icon className="h-5 w-5" />
                  {route.label}
                  <ChevronRight className="ml-auto h-4 w-4" />
                </Link>
              ))}
            </nav>
          </SheetContent>
        </Sheet>
        <div className="flex items-center gap-2">
          <Link href="/" className="flex items-center">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/FlexInvest.jpg-mvQVRz9lChkrNY9mWowFvjJp5YSxwx.jpeg"
              alt="FlexInvest Logo"
              width={140}
              height={70}
              className="h-auto hidden md:block"
            />
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/FlexInvest.jpg-mvQVRz9lChkrNY9mWowFvjJp5YSxwx.jpeg"
              alt="FlexInvest Logo"
              width={40}
              height={40}
              className="h-auto md:hidden"
            />
          </Link>
        </div>
        <nav className="hidden md:flex flex-1 items-center gap-4 md:gap-6 text-sm">
          {routes.map((route) => (
            <Link
              key={route.href}
              href={route.href}
              className={cn(
                "flex items-center gap-2 rounded-md px-3 py-2 transition-colors",
                route.active ? "bg-accent text-accent-foreground" : "hover:bg-accent hover:text-accent-foreground",
              )}
            >
              <route.icon className="h-5 w-5" />
              {route.label}
            </Link>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-2">
          <ModeToggle />
        </div>
      </header>
      <main className="flex-1">{children}</main>
    </div>
  )
}
