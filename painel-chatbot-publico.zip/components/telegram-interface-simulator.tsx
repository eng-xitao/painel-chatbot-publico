"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Avatar } from "@/components/ui/avatar"
import { ArrowLeft, MoreVertical, Search, Paperclip, Send } from "lucide-react"

interface Message {
  id: string
  sender: "bot" | "user"
  content: string
  timestamp: Date
}

export function TelegramInterfaceSimulator() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      sender: "bot",
      content: `🤖 FlexInvest Trading Bot - Menu Principal 🤖

🔔 Notificações: ON

📊 Ver Sinais Ativos
⚙️ Configurações
📈 Escolher Moedas
ℹ️ Status do Sistema
❓ Ajuda`,
      timestamp: new Date(Date.now() - 60000),
    },
    {
      id: "2",
      sender: "user",
      content: "📊 Ver Sinais Ativos",
      timestamp: new Date(Date.now() - 30000),
    },
    {
      id: "3",
      sender: "bot",
      content: `📊 Sinais Ativos 📊

Não há sinais ativos no momento.

Novos sinais serão enviados automaticamente quando detectados.`,
      timestamp: new Date(Date.now() - 25000),
    },
    {
      id: "4",
      sender: "bot",
      content: `🚨 Alerta de Trading - FlexInvest

📊 Moeda: BTC-BRL
💲 Preço Atual: R$250000.00
📈 Ação: COMPRA
📊 Variação 1h: +0.58%
✅ Confiabilidade: 55%

🕒 Horário de Entrada: 23:50:25
⏳ Expiração: Entrada válida por 3 minutos

📝 Justificativa: MACD aponta tendência de alta | Média móvel cruzada com volume relevante

🤖 Sinal gerado automaticamente por FlexInvest`,
      timestamp: new Date(Date.now() - 10000),
    },
  ])

  const [newMessage, setNewMessage] = useState("")

  const handleSendMessage = () => {
    if (!newMessage.trim()) return

    // Adicionar mensagem do usuário
    const userMessage: Message = {
      id: Date.now().toString(),
      sender: "user",
      content: newMessage,
      timestamp: new Date(),
    }

    setMessages([...messages, userMessage])
    setNewMessage("")

    // Simular resposta do bot
    setTimeout(() => {
      let botResponse: Message

      if (newMessage.toLowerCase().includes("sinal") || newMessage.includes("📊")) {
        botResponse = {
          id: (Date.now() + 1).toString(),
          sender: "bot",
          content: `📊 Sinais Ativos 📊

Não há sinais ativos no momento.

Novos sinais serão enviados automaticamente quando detectados.`,
          timestamp: new Date(),
        }
      } else if (newMessage.toLowerCase().includes("menu") || newMessage.includes("🔙")) {
        botResponse = {
          id: (Date.now() + 1).toString(),
          sender: "bot",
          content: `🤖 FlexInvest Trading Bot - Menu Principal 🤖

🔔 Notificações: ON

📊 Ver Sinais Ativos
⚙️ Configurações
📈 Escolher Moedas
ℹ️ Status do Sistema
❓ Ajuda`,
          timestamp: new Date(),
        }
      } else if (newMessage.toLowerCase().includes("ajuda") || newMessage.includes("❓")) {
        botResponse = {
          id: (Date.now() + 1).toString(),
          sender: "bot",
          content: `❓ Ajuda

Comandos disponíveis:
📊 Ver Sinais Ativos - Mostra os sinais ativos no momento
⚙️ Configurações - Ajuste as configurações do bot
📈 Escolher Moedas - Selecione quais moedas deseja monitorar
ℹ️ Status do Sistema - Verifica o status do sistema
🔙 Voltar ao Menu - Retorna ao menu principal

Para mais informações, visite nosso site ou entre em contato com o suporte.`,
          timestamp: new Date(),
        }
      } else {
        botResponse = {
          id: (Date.now() + 1).toString(),
          sender: "bot",
          content: "Comando não reconhecido. Digite 🔙 para voltar ao menu principal ou ❓ para ajuda.",
          timestamp: new Date(),
        }
      }

      setMessages((prev) => [...prev, botResponse])
    }, 1000)
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="p-4 border-b">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ArrowLeft className="h-5 w-5" />
            <Avatar className="h-8 w-8 bg-blue-500">
              <span className="text-white font-semibold">F</span>
            </Avatar>
            <div>
              <CardTitle className="text-base">FlexInvest Trading Bot</CardTitle>
              <p className="text-xs text-muted-foreground">online</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Search className="h-5 w-5 text-muted-foreground" />
            <MoreVertical className="h-5 w-5 text-muted-foreground" />
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="bg-[#e6ebee] dark:bg-[#1e1e1e] min-h-[400px] max-h-[500px] flex flex-col">
          <ScrollArea className="flex-1 p-4">
            <div className="space-y-4">
              {messages.map((message) => (
                <div key={message.id} className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-[80%] rounded-lg p-3 ${
                      message.sender === "user" ? "bg-[#effdde] dark:bg-green-900" : "bg-white dark:bg-gray-800"
                    }`}
                  >
                    <div className="whitespace-pre-wrap text-sm">{message.content}</div>
                    <div className="text-right mt-1">
                      <span className="text-xs text-muted-foreground">
                        {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
          <div className="p-3 border-t bg-white dark:bg-gray-900 flex items-center gap-2">
            <Paperclip className="h-5 w-5 text-muted-foreground" />
            <Input
              placeholder="Mensagem"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  handleSendMessage()
                }
              }}
              className="border-none focus-visible:ring-0 focus-visible:ring-offset-0"
            />
            <Button size="icon" variant="ghost" onClick={handleSendMessage}>
              <Send className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
