"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { ChevronDown, Search, Loader2 } from "lucide-react"
import { exchangeManager } from "@/lib/exchange-service"

type Coin = {
  id: string
  name: string
  symbol: string
  image?: string
}

interface CoinSelectorRealProps {
  selectedCoin: string
  onSelectCoin: (coinId: string) => void
  isLoading?: boolean
  exchangeName?: string
}

export function CoinSelectorReal({
  selectedCoin,
  onSelectCoin,
  isLoading = false,
  exchangeName,
}: CoinSelectorRealProps) {
  const [availableCoins, setAvailableCoins] = useState<Coin[]>([])
  const [coinSearch, setCoinSearch] = useState("")
  const [isLoadingCoins, setIsLoadingCoins] = useState(false)
  const [isPopoverOpen, setIsPopoverOpen] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Buscar lista de criptomoedas da exchange
  const fetchCoinList = async () => {
    setIsLoadingCoins(true)
    setError(null)

    try {
      // Verificar se temos uma exchange configurada
      if (!exchangeManager.listExchanges().length) {
        setError("Nenhuma exchange configurada. Configure uma exchange nas configurações.")
        return
      }

      // Obter a exchange especificada ou a padrão
      const exchange = exchangeManager.getExchange(exchangeName)

      // Buscar símbolos disponíveis
      const symbols = await exchange.getSymbols()

      // Formatar para o componente
      const formattedCoins = symbols.map((symbol) => {
        const parts = symbol.split("-")
        const baseAsset = parts[0]
        const quoteAsset = parts[1] || "USD"

        return {
          id: symbol,
          name: `${baseAsset}/${quoteAsset}`,
          symbol: baseAsset,
        }
      })

      setAvailableCoins(formattedCoins)
    } catch (error) {
      console.error("Erro ao buscar lista de criptomoedas:", error)
      setError("Erro ao buscar lista de criptomoedas. Verifique suas configurações de API.")

      // Usar lista estática em caso de erro
      setAvailableCoins([
        { id: "BTC-USD", name: "Bitcoin (BTC/USD)", symbol: "BTC" },
        { id: "ETH-USD", name: "Ethereum (ETH/USD)", symbol: "ETH" },
        { id: "USDT-USD", name: "Tether (USDT/USD)", symbol: "USDT" },
        { id: "BNB-USD", name: "BNB (BNB/USD)", symbol: "BNB" },
        { id: "XRP-USD", name: "XRP (XRP/USD)", symbol: "XRP" },
        { id: "SOL-USD", name: "Solana (SOL/USD)", symbol: "SOL" },
        { id: "ADA-USD", name: "Cardano (ADA/USD)", symbol: "ADA" },
        { id: "DOGE-USD", name: "Dogecoin (DOGE/USD)", symbol: "DOGE" },
        { id: "DOT-USD", name: "Polkadot (DOT/USD)", symbol: "DOT" },
        { id: "MATIC-USD", name: "Polygon (MATIC/USD)", symbol: "MATIC" },
      ])
    } finally {
      setIsLoadingCoins(false)
    }
  }

  // Buscar lista de criptomoedas ao abrir o popover pela primeira vez
  const handlePopoverOpen = (open: boolean) => {
    setIsPopoverOpen(open)
    if (open && availableCoins.length === 0 && !isLoadingCoins) {
      fetchCoinList()
    }
  }

  // Filtrar criptomoedas com base na busca
  const filteredCoins = coinSearch
    ? availableCoins.filter(
        (coin) =>
          coin.name.toLowerCase().includes(coinSearch.toLowerCase()) ||
          coin.symbol.toLowerCase().includes(coinSearch.toLowerCase()),
      )
    : availableCoins

  // Ordenar por símbolo para facilitar a busca
  const sortedCoins = [...filteredCoins].sort((a, b) => a.symbol.localeCompare(b.symbol))

  return (
    <Popover open={isPopoverOpen} onOpenChange={handlePopoverOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" className="w-[220px] justify-between">
          {isLoading ? (
            <span className="flex items-center">
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Carregando...
            </span>
          ) : (
            <span className="truncate">
              {availableCoins.find((c) => c.id === selectedCoin)?.name || selectedCoin || "Selecione uma moeda"}
            </span>
          )}
          <ChevronDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[280px] p-0" align="start">
        <div className="p-2">
          <div className="flex items-center border rounded-md">
            <Search className="ml-2 h-4 w-4 shrink-0 opacity-50" />
            <Input
              placeholder="Buscar criptomoeda..."
              value={coinSearch}
              onChange={(e) => setCoinSearch(e.target.value)}
              className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
            />
            {coinSearch && (
              <Button variant="ghost" onClick={() => setCoinSearch("")} className="h-8 w-8 p-0 mr-1">
                &times;
              </Button>
            )}
          </div>
        </div>
        <div className="max-h-[300px] overflow-auto">
          {isLoadingCoins ? (
            <div className="flex justify-center items-center py-4">
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Carregando moedas...
            </div>
          ) : error ? (
            <div className="p-4 text-center text-red-500">
              <p>{error}</p>
              <Button variant="outline" size="sm" className="mt-2" onClick={fetchCoinList}>
                Tentar novamente
              </Button>
            </div>
          ) : sortedCoins.length > 0 ? (
            sortedCoins.map((coin) => (
              <div
                key={coin.id}
                className={`flex items-center px-3 py-2 cursor-pointer hover:bg-muted ${
                  selectedCoin === coin.id ? "bg-muted" : ""
                }`}
                onClick={() => {
                  onSelectCoin(coin.id)
                  setCoinSearch("")
                  setIsPopoverOpen(false)
                }}
              >
                {coin.image && (
                  <img
                    src={coin.image || "/placeholder.svg"}
                    alt={coin.symbol}
                    className="w-5 h-5 mr-2"
                    onError={(e) => {
                      // Remover src em caso de erro para não mostrar ícone quebrado
                      e.currentTarget.src = ""
                      e.currentTarget.style.display = "none"
                    }}
                  />
                )}
                <div className="font-medium">{coin.symbol}</div>
                <div className="ml-2 text-sm text-muted-foreground truncate">{coin.name}</div>
              </div>
            ))
          ) : (
            <div className="text-center py-4 text-muted-foreground">Nenhuma moeda encontrada</div>
          )}
        </div>
      </PopoverContent>
    </Popover>
  )
}
