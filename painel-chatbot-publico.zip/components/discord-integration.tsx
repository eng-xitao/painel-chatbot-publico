"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"
import { MessageSquare, Send, AlertTriangle } from "lucide-react"

interface DiscordIntegrationProps {
  discordConfig: any
  onUpdateConfig: (config: any) => void
}

export function DiscordIntegration({ discordConfig, onUpdateConfig }: DiscordIntegrationProps) {
  const [webhookUrl, setWebhookUrl] = useState(discordConfig?.webhookUrl || "")
  const [isTesting, setIsTesting] = useState(false)
  const { toast } = useToast()

  const handleToggleDiscord = (enabled: boolean) => {
    onUpdateConfig({
      ...discordConfig,
      enabled,
    })
  }

  const updateDiscordConfig = () => {
    onUpdateConfig({
      ...discordConfig,
      webhookUrl,
    })

    toast({
      title: "Configurações salvas",
      description: "As configurações do Discord foram atualizadas",
    })
  }

  const testDiscordWebhook = async () => {
    if (!webhookUrl) {
      toast({
        title: "URL não configurada",
        description: "Por favor, insira uma URL de webhook válida",
        variant: "destructive",
      })
      return
    }

    setIsTesting(true)
    try {
      const response = await fetch(webhookUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          content: null,
          embeds: [
            {
              title: "🤖 Teste de Notificação",
              description: "Seu robô de trading está configurado corretamente para enviar alertas via Discord.",
              color: 3447003, // Azul
              timestamp: new Date().toISOString(),
              footer: {
                text: "Robô de Trading",
              },
            },
          ],
        }),
      })

      if (response.ok) {
        toast({
          title: "Teste enviado com sucesso",
          description: "Verifique seu servidor Discord para confirmar o recebimento",
        })
      } else {
        toast({
          title: "Falha no envio",
          description: "Não foi possível enviar a mensagem de teste. Verifique a URL do webhook.",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao testar a notificação",
        variant: "destructive",
      })
    } finally {
      setIsTesting(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Integração com Discord</CardTitle>
        <CardDescription>Configure notificações via webhook do Discord</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <MessageSquare className="h-5 w-5" />
            <Label htmlFor="discord-enabled" className="font-medium">
              Notificações via Discord
            </Label>
          </div>
          <Switch
            id="discord-enabled"
            checked={discordConfig?.enabled || false}
            onCheckedChange={handleToggleDiscord}
          />
        </div>

        <Tabs defaultValue="setup" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="setup">Configuração</TabsTrigger>
            <TabsTrigger value="help">Ajuda</TabsTrigger>
          </TabsList>

          <TabsContent value="setup" className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label htmlFor="webhook-url">URL do Webhook</Label>
              <Input
                id="webhook-url"
                type="url"
                placeholder="https://discord.com/api/webhooks/..."
                value={webhookUrl}
                onChange={(e) => setWebhookUrl(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                Cole a URL do webhook do Discord que você criou no seu servidor
              </p>
            </div>

            <div className="flex space-x-2 pt-2">
              <Button onClick={updateDiscordConfig} className="flex-1">
                Salvar Configurações
              </Button>
              <Button
                variant="outline"
                onClick={testDiscordWebhook}
                disabled={isTesting || !webhookUrl}
                className="flex-1"
              >
                {isTesting ? "Enviando..." : "Testar Webhook"}
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="help" className="space-y-4 mt-4">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Send className="h-5 w-5 text-blue-500" />
                <h3 className="font-medium">Como configurar o Discord</h3>
              </div>

              <ol className="space-y-2 list-decimal list-inside text-sm">
                <li>Abra seu servidor Discord onde deseja receber as notificações</li>
                <li>Clique com o botão direito em um canal e selecione "Editar Canal"</li>
                <li>Vá para "Integrações" e depois "Webhooks"</li>
                <li>Clique em "Novo Webhook"</li>
                <li>Dê um nome ao webhook (ex: "Robô de Trading")</li>
                <li>Opcionalmente, altere o avatar</li>
                <li>Clique em "Copiar URL do Webhook"</li>
                <li>Cole a URL no campo acima</li>
              </ol>

              <div className="mt-4 p-4 bg-amber-50 dark:bg-amber-950 rounded-md">
                <div className="flex items-center space-x-2">
                  <AlertTriangle className="h-5 w-5 text-amber-500" />
                  <h4 className="font-medium text-amber-700 dark:text-amber-300">Importante</h4>
                </div>
                <p className="text-sm text-amber-600 dark:text-amber-400 mt-2">
                  Mantenha a URL do webhook em segredo. Qualquer pessoa com acesso a ela pode enviar mensagens para o
                  seu servidor Discord.
                </p>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
