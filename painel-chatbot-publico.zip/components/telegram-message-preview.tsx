"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/hooks/use-toast"
import { TelegramMessageFormatter } from "./telegram-message-formatter"

export function TelegramMessagePreview() {
  const { toast } = useToast()
  const [messageType, setMessageType] = useState<"buy" | "sell" | "menu" | "flash" | "confirmation" | "error">("buy")

  const [buySignalData, setBuySignalData] = useState({
    symbol: "BTC-BRL",
    price: 250000.0,
    variation1h: 0.58,
    confidence: 55,
    entryTime: "23:50:25",
    expirationMinutes: 3,
    justification: "MACD aponta tendência de alta | Média móvel cruzada com volume relevante",
  })

  const [sellSignalData, setSellSignalData] = useState({
    symbol: "ETH-BRL",
    price: 12500.0,
    variation1h: -0.75,
    confidence: 57,
    entryTime: "23:50:25",
    expirationMinutes: 3,
    justification: "Volume elevado com média de queda | Média móvel cruzada com volume relevante",
  })

  const [menuData, setMenuData] = useState({
    notificationsEnabled: true,
  })

  const [flashSignalData, setFlashSignalData] = useState({
    symbol: "Bitcoin",
    expirationMinutes: 5,
    action: "sell" as "buy" | "sell",
    entryTime: "10:20",
    gale1Time: "10:25",
    gale2Time: "10:30",
    maxGale: 2,
  })

  const [confirmationData, setConfirmationData] = useState({
    symbol: "BTC-BRL",
    action: "buy" as "buy" | "sell",
    price: 250000.0,
    time: "10:25:30",
    profit: 2.5,
    message: "Operação executada com sucesso! Aguarde o próximo sinal.",
  })

  const [errorData, setErrorData] = useState({
    symbol: "ETH-BRL",
    action: "sell" as "buy" | "sell",
    reason: "Preço fora do intervalo esperado",
    message: "Tente novamente quando o mercado estabilizar.",
  })

  const handleCopy = () => {
    toast({
      title: "Mensagem copiada!",
      description: "A mensagem foi copiada para a área de transferência.",
    })
  }

  const getActiveData = () => {
    switch (messageType) {
      case "buy":
        return buySignalData
      case "sell":
        return sellSignalData
      case "menu":
        return menuData
      case "flash":
        return flashSignalData
      case "confirmation":
        return confirmationData
      case "error":
        return errorData
      default:
        return buySignalData
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Visualização de Mensagens para Telegram</CardTitle>
          <CardDescription>
            Visualize e personalize os formatos de mensagem para o seu bot de trading no Telegram
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="buy" value={messageType} onValueChange={(value) => setMessageType(value as any)}>
            <TabsList className="grid grid-cols-3 md:grid-cols-6 mb-4">
              <TabsTrigger value="buy">Compra</TabsTrigger>
              <TabsTrigger value="sell">Venda</TabsTrigger>
              <TabsTrigger value="menu">Menu</TabsTrigger>
              <TabsTrigger value="flash">Flash</TabsTrigger>
              <TabsTrigger value="confirmation">Confirmação</TabsTrigger>
              <TabsTrigger value="error">Erro</TabsTrigger>
            </TabsList>

            <TabsContent value="buy" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="buy-symbol">Moeda</Label>
                  <Input
                    id="buy-symbol"
                    value={buySignalData.symbol}
                    onChange={(e) => setBuySignalData({ ...buySignalData, symbol: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="buy-price">Preço (R$)</Label>
                  <Input
                    id="buy-price"
                    type="number"
                    value={buySignalData.price}
                    onChange={(e) => setBuySignalData({ ...buySignalData, price: Number.parseFloat(e.target.value) })}
                  />
                </div>
                <div>
                  <Label htmlFor="buy-variation">Variação 1h (%)</Label>
                  <Input
                    id="buy-variation"
                    type="number"
                    step="0.01"
                    value={buySignalData.variation1h}
                    onChange={(e) =>
                      setBuySignalData({ ...buySignalData, variation1h: Number.parseFloat(e.target.value) })
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="buy-confidence">Confiabilidade (%)</Label>
                  <div className="pt-2">
                    <Slider
                      id="buy-confidence"
                      min={0}
                      max={100}
                      step={1}
                      value={[buySignalData.confidence]}
                      onValueChange={(value) => setBuySignalData({ ...buySignalData, confidence: value[0] })}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="buy-entry-time">Horário de Entrada</Label>
                  <Input
                    id="buy-entry-time"
                    value={buySignalData.entryTime}
                    onChange={(e) => setBuySignalData({ ...buySignalData, entryTime: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="buy-expiration">Expiração (minutos)</Label>
                  <Input
                    id="buy-expiration"
                    type="number"
                    value={buySignalData.expirationMinutes}
                    onChange={(e) =>
                      setBuySignalData({ ...buySignalData, expirationMinutes: Number.parseInt(e.target.value) })
                    }
                  />
                </div>
                <div className="col-span-1 md:col-span-2">
                  <Label htmlFor="buy-justification">Justificativa</Label>
                  <Input
                    id="buy-justification"
                    value={buySignalData.justification}
                    onChange={(e) => setBuySignalData({ ...buySignalData, justification: e.target.value })}
                  />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="sell" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="sell-symbol">Moeda</Label>
                  <Input
                    id="sell-symbol"
                    value={sellSignalData.symbol}
                    onChange={(e) => setSellSignalData({ ...sellSignalData, symbol: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="sell-price">Preço (R$)</Label>
                  <Input
                    id="sell-price"
                    type="number"
                    value={sellSignalData.price}
                    onChange={(e) => setSellSignalData({ ...sellSignalData, price: Number.parseFloat(e.target.value) })}
                  />
                </div>
                <div>
                  <Label htmlFor="sell-variation">Variação 1h (%)</Label>
                  <Input
                    id="sell-variation"
                    type="number"
                    step="0.01"
                    value={sellSignalData.variation1h}
                    onChange={(e) =>
                      setSellSignalData({ ...sellSignalData, variation1h: Number.parseFloat(e.target.value) })
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="sell-confidence">Confiabilidade (%)</Label>
                  <div className="pt-2">
                    <Slider
                      id="sell-confidence"
                      min={0}
                      max={100}
                      step={1}
                      value={[sellSignalData.confidence]}
                      onValueChange={(value) => setSellSignalData({ ...sellSignalData, confidence: value[0] })}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="sell-entry-time">Horário de Entrada</Label>
                  <Input
                    id="sell-entry-time"
                    value={sellSignalData.entryTime}
                    onChange={(e) => setSellSignalData({ ...sellSignalData, entryTime: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="sell-expiration">Expiração (minutos)</Label>
                  <Input
                    id="sell-expiration"
                    type="number"
                    value={sellSignalData.expirationMinutes}
                    onChange={(e) =>
                      setSellSignalData({ ...sellSignalData, expirationMinutes: Number.parseInt(e.target.value) })
                    }
                  />
                </div>
                <div className="col-span-1 md:col-span-2">
                  <Label htmlFor="sell-justification">Justificativa</Label>
                  <Input
                    id="sell-justification"
                    value={sellSignalData.justification}
                    onChange={(e) => setSellSignalData({ ...sellSignalData, justification: e.target.value })}
                  />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="menu" className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch
                  id="notifications"
                  checked={menuData.notificationsEnabled}
                  onCheckedChange={(checked) => setMenuData({ ...menuData, notificationsEnabled: checked })}
                />
                <Label htmlFor="notifications">Notificações ativadas</Label>
              </div>
            </TabsContent>

            <TabsContent value="flash" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="flash-symbol">Moeda</Label>
                  <Input
                    id="flash-symbol"
                    value={flashSignalData.symbol}
                    onChange={(e) => setFlashSignalData({ ...flashSignalData, symbol: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="flash-action">Ação</Label>
                  <Select
                    value={flashSignalData.action}
                    onValueChange={(value) =>
                      setFlashSignalData({ ...flashSignalData, action: value as "buy" | "sell" })
                    }
                  >
                    <SelectTrigger id="flash-action">
                      <SelectValue placeholder="Selecione a ação" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="buy">COMPRA</SelectItem>
                      <SelectItem value="sell">VENDA</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="flash-expiration">Expiração (minutos)</Label>
                  <Input
                    id="flash-expiration"
                    type="number"
                    value={flashSignalData.expirationMinutes}
                    onChange={(e) =>
                      setFlashSignalData({ ...flashSignalData, expirationMinutes: Number.parseInt(e.target.value) })
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="flash-entry-time">Horário de Entrada</Label>
                  <Input
                    id="flash-entry-time"
                    value={flashSignalData.entryTime}
                    onChange={(e) => setFlashSignalData({ ...flashSignalData, entryTime: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="flash-gale1">Gale 1</Label>
                  <Input
                    id="flash-gale1"
                    value={flashSignalData.gale1Time}
                    onChange={(e) => setFlashSignalData({ ...flashSignalData, gale1Time: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="flash-gale2">Gale 2</Label>
                  <Input
                    id="flash-gale2"
                    value={flashSignalData.gale2Time}
                    onChange={(e) => setFlashSignalData({ ...flashSignalData, gale2Time: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="flash-max-gale">Máximo de Gales</Label>
                  <Select
                    value={String(flashSignalData.maxGale)}
                    onValueChange={(value) =>
                      setFlashSignalData({ ...flashSignalData, maxGale: Number.parseInt(value) })
                    }
                  >
                    <SelectTrigger id="flash-max-gale">
                      <SelectValue placeholder="Selecione o máximo de gales" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1</SelectItem>
                      <SelectItem value="2">2</SelectItem>
                      <SelectItem value="3">3</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="confirmation" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="confirmation-symbol">Moeda</Label>
                  <Input
                    id="confirmation-symbol"
                    value={confirmationData.symbol}
                    onChange={(e) => setConfirmationData({ ...confirmationData, symbol: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="confirmation-action">Ação</Label>
                  <Select
                    value={confirmationData.action}
                    onValueChange={(value) =>
                      setConfirmationData({ ...confirmationData, action: value as "buy" | "sell" })
                    }
                  >
                    <SelectTrigger id="confirmation-action">
                      <SelectValue placeholder="Selecione a ação" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="buy">COMPRA</SelectItem>
                      <SelectItem value="sell">VENDA</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="confirmation-price">Preço (R$)</Label>
                  <Input
                    id="confirmation-price"
                    type="number"
                    value={confirmationData.price}
                    onChange={(e) =>
                      setConfirmationData({ ...confirmationData, price: Number.parseFloat(e.target.value) })
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="confirmation-time">Horário</Label>
                  <Input
                    id="confirmation-time"
                    value={confirmationData.time}
                    onChange={(e) => setConfirmationData({ ...confirmationData, time: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="confirmation-profit">Lucro (%)</Label>
                  <Input
                    id="confirmation-profit"
                    type="number"
                    step="0.01"
                    value={confirmationData.profit}
                    onChange={(e) =>
                      setConfirmationData({ ...confirmationData, profit: Number.parseFloat(e.target.value) })
                    }
                  />
                </div>
                <div className="col-span-1 md:col-span-2">
                  <Label htmlFor="confirmation-message">Mensagem</Label>
                  <Input
                    id="confirmation-message"
                    value={confirmationData.message}
                    onChange={(e) => setConfirmationData({ ...confirmationData, message: e.target.value })}
                  />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="error" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="error-symbol">Moeda</Label>
                  <Input
                    id="error-symbol"
                    value={errorData.symbol}
                    onChange={(e) => setErrorData({ ...errorData, symbol: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="error-action">Ação</Label>
                  <Select
                    value={errorData.action}
                    onValueChange={(value) => setErrorData({ ...errorData, action: value as "buy" | "sell" })}
                  >
                    <SelectTrigger id="error-action">
                      <SelectValue placeholder="Selecione a ação" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="buy">COMPRA</SelectItem>
                      <SelectItem value="sell">VENDA</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="error-reason">Motivo</Label>
                  <Input
                    id="error-reason"
                    value={errorData.reason}
                    onChange={(e) => setErrorData({ ...errorData, reason: e.target.value })}
                  />
                </div>
                <div className="col-span-1 md:col-span-2">
                  <Label htmlFor="error-message">Mensagem</Label>
                  <Input
                    id="error-message"
                    value={errorData.message}
                    onChange={(e) => setErrorData({ ...errorData, message: e.target.value })}
                  />
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <TelegramMessageFormatter type={messageType} data={getActiveData()} onCopy={handleCopy} />
    </div>
  )
}
