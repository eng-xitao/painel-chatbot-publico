"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { CoinSelector } from "@/components/coin-selector"
import { Badge } from "@/components/ui/badge"
import { Bell, BellOff, Clock, Trash2, Plus } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export function AlertsContent() {
  const { toast } = useToast()
  const [selectedCoin, setSelectedCoin] = useState("bitcoin")
  const [activeTab, setActiveTab] = useState("active")

  const [alerts, setAlerts] = useState([
    {
      id: 1,
      coin: "BTC",
      type: "price",
      condition: "above",
      value: 55000,
      createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      active: true,
      triggered: false,
    },
    {
      id: 2,
      coin: "ETH",
      type: "price",
      condition: "below",
      value: 2500,
      createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000),
      active: true,
      triggered: false,
    },
    {
      id: 3,
      coin: "BTC",
      type: "indicator",
      indicator: "rsi",
      condition: "below",
      value: 30,
      createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      active: true,
      triggered: false,
    },
  ])

  const [alertHistory, setAlertHistory] = useState([
    {
      id: 101,
      coin: "SOL",
      type: "price",
      condition: "above",
      value: 120,
      createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
      triggeredAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      price: 122.5,
    },
    {
      id: 102,
      coin: "BTC",
      type: "indicator",
      indicator: "macd",
      condition: "crosses_above",
      value: 0,
      createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      triggeredAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
      price: 48750.25,
    },
  ])

  // Estado para o formulário de novo alerta
  const [newAlert, setNewAlert] = useState({
    coin: selectedCoin,
    type: "price",
    indicator: "rsi",
    condition: "above",
    value: "",
    active: true,
  })

  // Manipuladores de eventos para o formulário
  const handleAlertChange = (field, value) => {
    setNewAlert({
      ...newAlert,
      [field]: value,
    })
  }

  const addAlert = () => {
    if (!newAlert.value) {
      toast({
        title: "Valor não informado",
        description: "Por favor, informe um valor para o alerta.",
        variant: "destructive",
      })
      return
    }

    const alert = {
      id: Date.now(),
      coin: newAlert.coin,
      type: newAlert.type,
      ...(newAlert.type === "indicator" && { indicator: newAlert.indicator }),
      condition: newAlert.condition,
      value: Number.parseFloat(newAlert.value),
      createdAt: new Date(),
      active: true,
      triggered: false,
    }

    setAlerts([...alerts, alert])

    // Resetar o formulário
    setNewAlert({
      coin: selectedCoin,
      type: "price",
      indicator: "rsi",
      condition: "above",
      value: "",
      active: true,
    })

    toast({
      title: "Alerta criado",
      description: "Seu alerta foi criado com sucesso.",
    })
  }

  const toggleAlertStatus = (id) => {
    setAlerts(alerts.map((alert) => (alert.id === id ? { ...alert, active: !alert.active } : alert)))
  }

  const deleteAlert = (id) => {
    setAlerts(alerts.filter((alert) => alert.id !== id))

    toast({
      title: "Alerta removido",
      description: "O alerta foi removido com sucesso.",
    })
  }

  // Função para formatar a condição do alerta
  const formatCondition = (condition) => {
    switch (condition) {
      case "above":
        return "acima de"
      case "below":
        return "abaixo de"
      case "crosses_above":
        return "cruza acima de"
      case "crosses_below":
        return "cruza abaixo de"
      default:
        return condition
    }
  }

  // Função para formatar o tipo de alerta
  const formatAlertType = (type, indicator) => {
    if (type === "price") return "Preço"
    if (type === "indicator") {
      switch (indicator) {
        case "rsi":
          return "RSI"
        case "macd":
          return "MACD"
        case "volume":
          return "Volume"
        default:
          return indicator?.toUpperCase() || "Indicador"
      }
    }
    return type
  }

  // Filtrar alertas ativos
  const activeAlerts = alerts.filter((alert) => alert.active)

  // Filtrar alertas inativos
  const inactiveAlerts = alerts.filter((alert) => !alert.active)

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div>
          <h2 className="text-3xl font-bold">Alertas</h2>
          <p className="text-muted-foreground">Gerenciar alertas de preço e indicadores</p>
        </div>
        <Button onClick={() => setActiveTab("new")}>
          <Plus className="h-4 w-4 mr-2" />
          Novo Alerta
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="active">
            <Bell className="h-4 w-4 mr-2" />
            Ativos ({activeAlerts.length})
          </TabsTrigger>
          <TabsTrigger value="inactive">
            <BellOff className="h-4 w-4 mr-2" />
            Inativos ({inactiveAlerts.length})
          </TabsTrigger>
          <TabsTrigger value="history">
            <Clock className="h-4 w-4 mr-2" />
            Histórico ({alertHistory.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="active" className="space-y-4">
          {activeAlerts.length > 0 ? (
            activeAlerts.map((alert) => (
              <Card key={alert.id}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg flex items-center">
                        {alert.coin}
                        <Badge variant="outline" className="ml-2">
                          {formatAlertType(alert.type, alert.indicator)}
                        </Badge>
                      </CardTitle>
                      <CardDescription>Criado em {alert.createdAt.toLocaleString()}</CardDescription>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch checked={alert.active} onCheckedChange={() => toggleAlertStatus(alert.id)} />
                      <Button variant="ghost" size="icon" onClick={() => deleteAlert(alert.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center text-lg font-medium">
                    <span className="text-muted-foreground mr-2">{formatCondition(alert.condition)}</span>
                    <span>{alert.type === "price" ? `$${alert.value.toLocaleString("pt-BR")}` : `${alert.value}`}</span>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-6 text-center">
                <Bell className="h-10 w-10 text-muted-foreground mb-2" />
                <h3 className="text-lg font-medium">Nenhum alerta ativo</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Você não tem alertas ativos no momento. Crie um novo alerta para começar.
                </p>
                <Button className="mt-4" onClick={() => setActiveTab("new")}>
                  <Plus className="h-4 w-4 mr-2" />
                  Novo Alerta
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="inactive" className="space-y-4">
          {inactiveAlerts.length > 0 ? (
            inactiveAlerts.map((alert) => (
              <Card key={alert.id}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg flex items-center">
                        {alert.coin}
                        <Badge variant="outline" className="ml-2">
                          {formatAlertType(alert.type, alert.indicator)}
                        </Badge>
                      </CardTitle>
                      <CardDescription>Criado em {alert.createdAt.toLocaleString()}</CardDescription>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch checked={alert.active} onCheckedChange={() => toggleAlertStatus(alert.id)} />
                      <Button variant="ghost" size="icon" onClick={() => deleteAlert(alert.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center text-lg font-medium">
                    <span className="text-muted-foreground mr-2">{formatCondition(alert.condition)}</span>
                    <span>{alert.type === "price" ? `$${alert.value.toLocaleString("pt-BR")}` : `${alert.value}`}</span>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-6 text-center">
                <BellOff className="h-10 w-10 text-muted-foreground mb-2" />
                <h3 className="text-lg font-medium">Nenhum alerta inativo</h3>
                <p className="text-sm text-muted-foreground mt-1">Você não tem alertas inativos no momento.</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          {alertHistory.length > 0 ? (
            alertHistory.map((alert) => (
              <Card key={alert.id}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg flex items-center">
                        {alert.coin}
                        <Badge variant="outline" className="ml-2">
                          {formatAlertType(alert.type, alert.indicator)}
                        </Badge>
                      </CardTitle>
                      <CardDescription>Disparado em {alert.triggeredAt.toLocaleString()}</CardDescription>
                    </div>
                    <Badge className="bg-green-500">Disparado</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center text-lg font-medium">
                    <span className="text-muted-foreground mr-2">{formatCondition(alert.condition)}</span>
                    <span>{alert.type === "price" ? `$${alert.value.toLocaleString("pt-BR")}` : `${alert.value}`}</span>
                  </div>
                  <div className="mt-2 text-sm text-muted-foreground">
                    Preço no momento do disparo: ${alert.price.toLocaleString("pt-BR")}
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-6 text-center">
                <Clock className="h-10 w-10 text-muted-foreground mb-2" />
                <h3 className="text-lg font-medium">Nenhum alerta no histórico</h3>
                <p className="text-sm text-muted-foreground mt-1">Nenhum dos seus alertas foi disparado ainda.</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="new">
          <Card>
            <CardHeader>
              <CardTitle>Novo Alerta</CardTitle>
              <CardDescription>Configure um novo alerta para monitorar preços ou indicadores</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="coin">Moeda</Label>
                  <CoinSelector selectedCoin={newAlert.coin} onSelectCoin={(coin) => handleAlertChange("coin", coin)} />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="alert-type">Tipo de Alerta</Label>
                  <Select value={newAlert.type} onValueChange={(value) => handleAlertChange("type", value)}>
                    <SelectTrigger id="alert-type">
                      <SelectValue placeholder="Selecione o tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="price">Preço</SelectItem>
                      <SelectItem value="indicator">Indicador</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {newAlert.type === "indicator" && (
                  <div className="space-y-2">
                    <Label htmlFor="indicator">Indicador</Label>
                    <Select value={newAlert.indicator} onValueChange={(value) => handleAlertChange("indicator", value)}>
                      <SelectTrigger id="indicator">
                        <SelectValue placeholder="Selecione o indicador" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="rsi">RSI</SelectItem>
                        <SelectItem value="macd">MACD</SelectItem>
                        <SelectItem value="volume">Volume</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="condition">Condição</Label>
                  <Select value={newAlert.condition} onValueChange={(value) => handleAlertChange("condition", value)}>
                    <SelectTrigger id="condition">
                      <SelectValue placeholder="Selecione a condição" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="above">Acima de</SelectItem>
                      <SelectItem value="below">Abaixo de</SelectItem>
                      <SelectItem value="crosses_above">Cruza acima de</SelectItem>
                      <SelectItem value="crosses_below">Cruza abaixo de</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="value">Valor</Label>
                  <Input
                    id="value"
                    type="number"
                    placeholder={newAlert.type === "price" ? "Ex: 50000" : "Ex: 30"}
                    value={newAlert.value}
                    onChange={(e) => handleAlertChange("value", e.target.value)}
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    id="active"
                    checked={newAlert.active}
                    onCheckedChange={(checked) => handleAlertChange("active", checked)}
                  />
                  <Label htmlFor="active">Ativar alerta imediatamente</Label>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => setActiveTab("active")}>
                Cancelar
              </Button>
              <Button onClick={addAlert}>Criar Alerta</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
