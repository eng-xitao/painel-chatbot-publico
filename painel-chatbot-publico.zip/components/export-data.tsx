"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Download, FileSpreadsheet, FileJson, Clock, BarChart } from "lucide-react"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface ExportDataProps {
  marketData: any[]
  simulationResults: any
  tradingAccount: any
}

export function ExportData({ marketData, simulationResults, tradingAccount }: ExportDataProps) {
  const [exportFormat, setExportFormat] = useState<"csv" | "json">("csv")
  const [isExporting, setIsExporting] = useState(false)
  const [exportOptions, setExportOptions] = useState({
    includeMarketData: true,
    includeSimulationResults: true,
    includeTradingHistory: true,
    dateRange: "all", // all, 7d, 30d, 90d
  })

  const handleExport = async () => {
    setIsExporting(true)

    try {
      // Preparar os dados para exportação
      const exportData: any = {}

      // Filtrar dados por período
      const filteredMarketData = filterDataByPeriod(marketData, exportOptions.dateRange)

      if (exportOptions.includeMarketData && filteredMarketData.length > 0) {
        exportData.marketData = filteredMarketData
      }

      if (exportOptions.includeSimulationResults && simulationResults) {
        exportData.simulationResults = {
          totalReturn: simulationResults.totalReturn,
          totalTrades: simulationResults.totalTrades,
          winningTrades: simulationResults.winningTrades,
          winRate: simulationResults.winRate,
          maxDrawdown: simulationResults.maxDrawdown,
          finalCapital: simulationResults.finalCapital,
          trades: filterDataByPeriod(simulationResults.trades, exportOptions.dateRange),
          equityCurve: filterDataByPeriod(simulationResults.equityCurve, exportOptions.dateRange),
        }
      }

      if (exportOptions.includeTradingHistory && tradingAccount) {
        exportData.tradingHistory = {
          openPositions: tradingAccount.openPositions,
          closedPositions: filterDataByPeriod(tradingAccount.closedPositions, exportOptions.dateRange),
          performance: tradingAccount.performance,
        }
      }

      // Converter para o formato selecionado e fazer download
      if (exportFormat === "csv") {
        downloadCSV(exportData)
      } else {
        downloadJSON(exportData)
      }
    } catch (error) {
      console.error("Erro ao exportar dados:", error)
    } finally {
      setIsExporting(false)
    }
  }

  const filterDataByPeriod = (data: any[], period: string) => {
    if (!data || !Array.isArray(data) || period === "all") return data

    const now = new Date()
    let cutoffDate: Date

    switch (period) {
      case "7d":
        cutoffDate = new Date(now.setDate(now.getDate() - 7))
        break
      case "30d":
        cutoffDate = new Date(now.setDate(now.getDate() - 30))
        break
      case "90d":
        cutoffDate = new Date(now.setDate(now.getDate() - 90))
        break
      default:
        return data
    }

    return data.filter((item) => {
      const itemDate = new Date(item.date || item.entryDate || item.timestamp || item.closeDate || 0)
      return itemDate >= cutoffDate
    })
  }

  const downloadCSV = (data: any) => {
    let csvContent = ""

    // Função para converter um array de objetos em CSV
    const objectToCSV = (data: any[], name: string) => {
      if (!data || data.length === 0) return ""

      const headers = Object.keys(data[0])
      const headerRow = headers.join(",")
      const rows = data.map((row) =>
        headers
          .map((header) => {
            let cell = row[header]
            // Formatar valores para CSV
            if (cell === null || cell === undefined) return ""
            if (typeof cell === "object") cell = JSON.stringify(cell)
            if (typeof cell === "string") cell = `"${cell.replace(/"/g, '""')}"`
            return cell
          })
          .join(","),
      )

      return `${name}\n${headerRow}\n${rows.join("\n")}\n\n`
    }

    // Adicionar cada seção ao CSV
    if (data.marketData) {
      csvContent += objectToCSV(data.marketData, "Market Data")
    }

    if (data.simulationResults) {
      // Adicionar métricas de simulação
      csvContent += "Simulation Results\n"
      csvContent += `Total Return,${data.simulationResults.totalReturn}\n`
      csvContent += `Total Trades,${data.simulationResults.totalTrades}\n`
      csvContent += `Winning Trades,${data.simulationResults.winningTrades}\n`
      csvContent += `Win Rate,${data.simulationResults.winRate}\n`
      csvContent += `Max Drawdown,${data.simulationResults.maxDrawdown}\n`
      csvContent += `Final Capital,${data.simulationResults.finalCapital}\n\n`

      // Adicionar trades
      if (data.simulationResults.trades) {
        csvContent += objectToCSV(data.simulationResults.trades, "Simulation Trades")
      }

      // Adicionar curva de capital
      if (data.simulationResults.equityCurve) {
        csvContent += objectToCSV(data.simulationResults.equityCurve, "Equity Curve")
      }
    }

    if (data.tradingHistory) {
      // Adicionar posições abertas
      if (data.tradingHistory.openPositions) {
        csvContent += objectToCSV(data.tradingHistory.openPositions, "Open Positions")
      }

      // Adicionar posições fechadas
      if (data.tradingHistory.closedPositions) {
        csvContent += objectToCSV(data.tradingHistory.closedPositions, "Closed Positions")
      }

      // Adicionar métricas de performance
      csvContent += "Trading Performance\n"
      for (const [key, value] of Object.entries(data.tradingHistory.performance)) {
        csvContent += `${key},${value}\n`
      }
    }

    // Criar e baixar o arquivo
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.setAttribute("href", url)
    link.setAttribute("download", `trading_data_${new Date().toISOString().split("T")[0]}.csv`)
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const downloadJSON = (data: any) => {
    const jsonString = JSON.stringify(data, null, 2)
    const blob = new Blob([jsonString], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.setAttribute("href", url)
    link.setAttribute("download", `trading_data_${new Date().toISOString().split("T")[0]}.json`)
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Exportar Dados</CardTitle>
        <CardDescription>Exporte dados de mercado, resultados de simulação e histórico de trading</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="options" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="options">Opções</TabsTrigger>
            <TabsTrigger value="format">Formato</TabsTrigger>
          </TabsList>

          <TabsContent value="options" className="space-y-4">
            <div className="space-y-4 pt-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="market-data"
                  checked={exportOptions.includeMarketData}
                  onCheckedChange={(checked) => setExportOptions({ ...exportOptions, includeMarketData: !!checked })}
                />
                <Label htmlFor="market-data" className="flex items-center">
                  <BarChart className="h-4 w-4 mr-2" />
                  Dados de mercado
                </Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="simulation-results"
                  checked={exportOptions.includeSimulationResults}
                  onCheckedChange={(checked) =>
                    setExportOptions({ ...exportOptions, includeSimulationResults: !!checked })
                  }
                />
                <Label htmlFor="simulation-results" className="flex items-center">
                  <Clock className="h-4 w-4 mr-2" />
                  Resultados de simulação
                </Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="trading-history"
                  checked={exportOptions.includeTradingHistory}
                  onCheckedChange={(checked) =>
                    setExportOptions({ ...exportOptions, includeTradingHistory: !!checked })
                  }
                />
                <Label htmlFor="trading-history" className="flex items-center">
                  <BarChart className="h-4 w-4 mr-2" />
                  Histórico de trading
                </Label>
              </div>

              <div className="space-y-2 pt-2">
                <Label htmlFor="date-range">Período de dados</Label>
                <Select
                  value={exportOptions.dateRange}
                  onValueChange={(value) => setExportOptions({ ...exportOptions, dateRange: value })}
                >
                  <SelectTrigger id="date-range">
                    <SelectValue placeholder="Selecione o período" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os dados</SelectItem>
                    <SelectItem value="7d">Últimos 7 dias</SelectItem>
                    <SelectItem value="30d">Últimos 30 dias</SelectItem>
                    <SelectItem value="90d">Últimos 90 dias</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="format" className="space-y-4">
            <div className="grid grid-cols-2 gap-4 pt-2">
              <div
                className={`border rounded-lg p-4 cursor-pointer ${
                  exportFormat === "csv" ? "border-primary bg-primary/5" : "border-border"
                }`}
                onClick={() => setExportFormat("csv")}
              >
                <div className="flex flex-col items-center justify-center text-center">
                  <FileSpreadsheet className="h-10 w-10 mb-2" />
                  <h3 className="font-medium">CSV</h3>
                  <p className="text-sm text-muted-foreground">Compatível com Excel e outras planilhas</p>
                </div>
              </div>

              <div
                className={`border rounded-lg p-4 cursor-pointer ${
                  exportFormat === "json" ? "border-primary bg-primary/5" : "border-border"
                }`}
                onClick={() => setExportFormat("json")}
              >
                <div className="flex flex-col items-center justify-center text-center">
                  <FileJson className="h-10 w-10 mb-2" />
                  <h3 className="font-medium">JSON</h3>
                  <p className="text-sm text-muted-foreground">Formato estruturado para análise programática</p>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter>
        <Button
          onClick={handleExport}
          disabled={
            isExporting ||
            (!exportOptions.includeMarketData &&
              !exportOptions.includeSimulationResults &&
              !exportOptions.includeTradingHistory)
          }
          className="w-full"
        >
          {isExporting ? (
            <>Exportando...</>
          ) : (
            <>
              <Download className="h-4 w-4 mr-2" />
              Exportar Dados
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}
