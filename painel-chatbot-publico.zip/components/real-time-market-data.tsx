"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { CoinSelectorReal } from "@/components/coin-selector-real"
import { XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, BarChart, Bar } from "recharts"
import { ArrowUpRight, ArrowDownRight, RefreshCw } from "lucide-react"
import type { TimeInterval } from "@/lib/exchange-service"
import { fetchMarketData } from "@/lib/trading-utils"

interface RealTimeMarketDataProps {
  defaultCoin?: string
  defaultInterval?: TimeInterval
  showControls?: boolean
  height?: number
  onDataUpdate?: (data: any[]) => void
}

export function RealTimeMarketData({
  defaultCoin = "BTC-USD",
  defaultInterval = "1d",
  showControls = true,
  height = 300,
  onDataUpdate,
}: RealTimeMarketDataProps) {
  const [selectedCoin, setSelectedCoin] = useState(defaultCoin)
  const [interval, setInterval] = useState<TimeInterval>(defaultInterval)
  const [marketData, setMarketData] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [priceChange, setPriceChange] = useState({ value: 0, percentage: 0 })
  const [currentPrice, setCurrentPrice] = useState(0)

  // Função para buscar dados de mercado
  const loadMarketData = async () => {
    setIsLoading(true)
    setError(null)

    try {
      const data = await fetchMarketData(selectedCoin, interval)
      setMarketData(data)

      if (data.length > 0) {
        // Calcular preço atual e variação
        const currentPrice = data[data.length - 1].price
        const previousPrice = data.length > 1 ? data[data.length - 2].price : currentPrice
        const priceChangeValue = currentPrice - previousPrice
        const priceChangePercentage = (priceChangeValue / previousPrice) * 100

        setCurrentPrice(currentPrice)
        setPriceChange({
          value: priceChangeValue,
          percentage: priceChangePercentage,
        })

        // Notificar componente pai sobre os dados atualizados
        if (onDataUpdate) {
          onDataUpdate(data)
        }
      }

      setLastUpdate(new Date())
    } catch (error) {
      console.error("Erro ao carregar dados de mercado:", error)
      setError("Falha ao carregar dados de mercado. Verifique suas configurações de API.")
    } finally {
      setIsLoading(false)
    }
  }

  // Carregar dados iniciais
  useEffect(() => {
    loadMarketData()

    // Configurar atualização automática a cada minuto para intervalos curtos
    // ou a cada hora para intervalos longos
    const updateInterval = ["1m", "5m", "15m", "30m"].includes(interval) ? 60 * 1000 : 60 * 60 * 1000
    const timer = setInterval(loadMarketData, updateInterval)

    return () => clearInterval(timer)
  }, [selectedCoin, interval])

  // Formatar dados para o gráfico
  const chartData = marketData.map((item) => ({
    date: new Date(item.date).toLocaleDateString(),
    price: item.price,
    volume: item.volume / 1000000, // Converter para milhões
  }))

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Dados de Mercado</CardTitle>
            <CardDescription>
              {lastUpdate ? `Última atualização: ${lastUpdate.toLocaleTimeString()}` : "Carregando dados..."}
            </CardDescription>
          </div>
          {showControls && (
            <div className="flex items-center space-x-2">
              <CoinSelectorReal selectedCoin={selectedCoin} onSelectCoin={setSelectedCoin} isLoading={isLoading} />
              <Select value={interval} onValueChange={(value) => setInterval(value as TimeInterval)}>
                <SelectTrigger className="w-[100px]">
                  <SelectValue placeholder="Intervalo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1m">1 minuto</SelectItem>
                  <SelectItem value="5m">5 minutos</SelectItem>
                  <SelectItem value="15m">15 minutos</SelectItem>
                  <SelectItem value="30m">30 minutos</SelectItem>
                  <SelectItem value="1h">1 hora</SelectItem>
                  <SelectItem value="4h">4 horas</SelectItem>
                  <SelectItem value="1d">1 dia</SelectItem>
                  <SelectItem value="1w">1 semana</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" size="icon" onClick={loadMarketData} disabled={isLoading}>
                <RefreshCw className={`h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
              </Button>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {error ? (
          <div className="flex flex-col items-center justify-center py-6 text-center">
            <p className="text-red-500 mb-2">{error}</p>
            <Button variant="outline" onClick={loadMarketData} disabled={isLoading}>
              {isLoading ? (
                <>
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  Tentando novamente...
                </>
              ) : (
                <>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Tentar novamente
                </>
              )}
            </Button>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div className="bg-muted p-4 rounded-md">
                <div className="text-sm text-muted-foreground">Preço Atual</div>
                <div className="text-2xl font-bold">
                  ${currentPrice.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
                <div
                  className={`flex items-center text-sm ${priceChange.percentage >= 0 ? "text-green-500" : "text-red-500"}`}
                >
                  {priceChange.percentage >= 0 ? (
                    <ArrowUpRight className="h-4 w-4 mr-1" />
                  ) : (
                    <ArrowDownRight className="h-4 w-4 mr-1" />
                  )}
                  <span>
                    {priceChange.percentage >= 0 ? "+" : ""}
                    {priceChange.percentage.toFixed(2)}%
                  </span>
                </div>
              </div>

              <div className="bg-muted p-4 rounded-md">
                <div className="text-sm text-muted-foreground">Volume 24h</div>
                <div className="text-2xl font-bold">
                  {marketData.length > 0
                    ? `$${(marketData[marketData.length - 1].volume / 1000000).toFixed(2)}M`
                    : "N/A"}
                </div>
              </div>

              <div className="bg-muted p-4 rounded-md">
                <div className="text-sm text-muted-foreground">Variação 7d</div>
                {marketData.length > 7 ? (
                  <>
                    <div className="text-2xl font-bold">
                      {(
                        (marketData[marketData.length - 1].price / marketData[marketData.length - 7].price - 1) *
                        100
                      ).toFixed(2)}
                      %
                    </div>
                    <div className="text-sm text-muted-foreground">
                      ${marketData[marketData.length - 7].price.toFixed(2)} → $
                      {marketData[marketData.length - 1].price.toFixed(2)}
                    </div>
                  </>
                ) : (
                  <div className="text-2xl font-bold">N/A</div>
                )}
              </div>
            </div>

            <Tabs defaultValue="price">
              <TabsList className="mb-4">
                <TabsTrigger value="price">Preço</TabsTrigger>
                <TabsTrigger value="volume">Volume</TabsTrigger>
              </TabsList>

              <TabsContent value="price">
                <div style={{ height: `${height}px` }}>
                  {isLoading && marketData.length === 0 ? (
                    <div className="flex justify-center items-center h-full">
                      <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
                    </div>
                  ) : chartData.length > 0 ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={chartData}>
                        <defs>
                          <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#8884d8" stopOpacity={0.8} />
                            <stop offset="95%" stopColor="#8884d8" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="date" />
                        <YAxis domain={["auto", "auto"]} />
                        <Tooltip />
                        <Area
                          type="monotone"
                          dataKey="price"
                          stroke="#8884d8"
                          fillOpacity={1}
                          fill="url(#colorPrice)"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="flex justify-center items-center h-full">
                      <p>Nenhum dado disponível</p>
                    </div>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="volume">
                <div style={{ height: `${height}px` }}>
                  {isLoading && marketData.length === 0 ? (
                    <div className="flex justify-center items-center h-full">
                      <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
                    </div>
                  ) : chartData.length > 0 ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="date" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="volume" fill="#8884d8" name="Volume (milhões USD)" />
                      </BarChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="flex justify-center items-center h-full">
                      <p>Nenhum dado disponível</p>
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </>
        )}
      </CardContent>
    </Card>
  )
}
