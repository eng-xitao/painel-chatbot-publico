"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Loader2, Send, MessageSquare, CheckCircle2 } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import Link from "next/link"

export function TelegramConfig() {
  const { toast } = useToast()
  const [isTesting, setIsTesting] = useState(false)
  const [config, setConfig] = useState({
    botToken: "",
    chatId: "",
    enableRealTime: true,
    enableDaily: true,
    enableWeekly: false,
    silentHoursStart: "22:00",
    silentHoursEnd: "08:00",
    enableSilentHours: false,
  })

  const handleChange = (e) => {
    const { name, value } = e.target
    setConfig((prev) => ({ ...prev, [name]: value }))
  }

  const handleSwitchChange = (name, checked) => {
    setConfig((prev) => ({ ...prev, [name]: checked }))
  }

  const handleTestNotification = async () => {
    if (!config.botToken || !config.chatId) {
      toast({
        title: "Erro",
        description: "Por favor, preencha o Token do Bot e o ID do Chat antes de testar.",
        variant: "destructive",
      })
      return
    }

    setIsTesting(true)

    // Simulando o envio de uma notificação de teste
    setTimeout(() => {
      setIsTesting(false)
      toast({
        title: "Sucesso",
        description: "Notificação de teste enviada com sucesso!",
      })
    }, 2000)
  }

  const handleSave = () => {
    toast({
      title: "Configurações salvas",
      description: "Suas configurações do Telegram foram salvas com sucesso.",
    })
  }

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="botToken">Token do Bot</Label>
        <Input
          id="botToken"
          name="botToken"
          placeholder="123456789:ABCdefGHIjklMNOpqrSTUvwxYZ"
          value={config.botToken}
          onChange={handleChange}
        />
        <p className="text-xs text-muted-foreground">Obtenha um token criando um bot no @BotFather</p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="chatId">ID do Chat</Label>
        <Input id="chatId" name="chatId" placeholder="123456789" value={config.chatId} onChange={handleChange} />
        <p className="text-xs text-muted-foreground">Envie uma mensagem para @userinfobot para obter seu ID</p>
      </div>

      <div className="pt-2">
        <h3 className="text-sm font-medium mb-3">Frequência de Notificações</h3>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label htmlFor="enableRealTime" className="cursor-pointer">
              Tempo real (sinais e alertas)
            </Label>
            <Switch
              id="enableRealTime"
              checked={config.enableRealTime}
              onCheckedChange={(checked) => handleSwitchChange("enableRealTime", checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <Label htmlFor="enableDaily" className="cursor-pointer">
              Resumo diário
            </Label>
            <Switch
              id="enableDaily"
              checked={config.enableDaily}
              onCheckedChange={(checked) => handleSwitchChange("enableDaily", checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <Label htmlFor="enableWeekly" className="cursor-pointer">
              Resumo semanal
            </Label>
            <Switch
              id="enableWeekly"
              checked={config.enableWeekly}
              onCheckedChange={(checked) => handleSwitchChange("enableWeekly", checked)}
            />
          </div>
        </div>
      </div>

      <div className="pt-2">
        <div className="flex items-center justify-between mb-3">
          <Label htmlFor="enableSilentHours" className="cursor-pointer text-sm font-medium">
            Horário silencioso
          </Label>
          <Switch
            id="enableSilentHours"
            checked={config.enableSilentHours}
            onCheckedChange={(checked) => handleSwitchChange("enableSilentHours", checked)}
          />
        </div>

        {config.enableSilentHours && (
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <Label htmlFor="silentHoursStart" className="text-xs">
                Início
              </Label>
              <Input
                id="silentHoursStart"
                name="silentHoursStart"
                type="time"
                value={config.silentHoursStart}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="silentHoursEnd" className="text-xs">
                Fim
              </Label>
              <Input
                id="silentHoursEnd"
                name="silentHoursEnd"
                type="time"
                value={config.silentHoursEnd}
                onChange={handleChange}
              />
            </div>
          </div>
        )}
      </div>

      <div className="flex flex-col sm:flex-row gap-2 pt-2">
        <Button onClick={handleTestNotification} variant="outline" disabled={isTesting} className="flex-1">
          {isTesting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Testando...
            </>
          ) : (
            <>
              <Send className="mr-2 h-4 w-4" />
              Testar Notificação
            </>
          )}
        </Button>
        <Button onClick={handleSave} className="flex-1">
          <CheckCircle2 className="mr-2 h-4 w-4" />
          Salvar Configurações
        </Button>
      </div>

      <div className="pt-4 border-t mt-4">
        <Button variant="link" asChild className="p-0 h-auto text-sm">
          <Link href="/verificar-notificacoes">
            <MessageSquare className="mr-2 h-4 w-4" />
            Verificar e diagnosticar notificações
          </Link>
        </Button>
      </div>
    </div>
  )
}
