"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { CoinSelector } from "@/components/coin-selector"
import { XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from "recharts"
import {
  Play,
  Pause,
  Settings,
  AlertTriangle,
  DollarSign,
  TrendingUp,
  BarChart3,
  ArrowUpRight,
  ArrowDownRight,
  Wallet,
  History,
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { simulateRealtimePrice } from "@/lib/trading-utils"

export function AutoTradingContent() {
  const { toast } = useToast()
  const [selectedCoin, setSelectedCoin] = useState("bitcoin")
  const [isLoading, setIsLoading] = useState(false)
  const [activeTab, setActiveTab] = useState("dashboard")

  // Estado para o trading automático
  const [autoTradingEnabled, setAutoTradingEnabled] = useState(false)
  const [currentPrice, setCurrentPrice] = useState(52380.45)
  const [priceHistory, setPriceHistory] = useState(
    Array(30)
      .fill(0)
      .map((_, i) => ({
        time: new Date(Date.now() - (30 - i) * 60 * 1000).toLocaleTimeString(),
        price: 50000 + Math.random() * 5000,
      })),
  )

  // Estado para as configurações de trading
  const [tradingSettings, setTradingSettings] = useState({
    strategy: "sma",
    shortPeriod: 7,
    longPeriod: 25,
    rsiPeriod: 14,
    rsiOverbought: 70,
    rsiOversold: 30,
    initialBalance: 10000,
    positionSize: 10, // Porcentagem do saldo
    maxOpenPositions: 3,
    stopLoss: 5,
    takeProfit: 10,
    trailingStop: false,
    trailingPercent: 2,
    rebalanceInterval: 24, // Em horas
    riskLevel: "medium", // low, medium, high
  })

  // Estado para a conta de trading
  const [tradingAccount, setTradingAccount] = useState({
    balance: 10000,
    equity: 10250.75,
    availableBalance: 7500,
    openPositions: [
      { id: 1, coin: "BTC", amount: 0.05, entryPrice: 51200, currentPrice: 52380.45, pnl: 59.02, pnlPercentage: 2.3 },
      { id: 2, coin: "ETH", amount: 1.2, entryPrice: 2750, currentPrice: 2890.12, pnl: 168.14, pnlPercentage: 5.1 },
    ],
    closedPositions: [
      {
        id: 101,
        coin: "SOL",
        amount: 2.5,
        entryPrice: 110,
        exitPrice: 125.5,
        pnl: 38.75,
        pnlPercentage: 14.1,
        openDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
        closeDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      },
      {
        id: 102,
        coin: "BTC",
        amount: 0.03,
        entryPrice: 48000,
        exitPrice: 47500,
        pnl: -15,
        pnlPercentage: -1.04,
        openDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
        closeDate: new Date(Date.now() - 9 * 24 * 60 * 60 * 1000),
      },
    ],
    performance: {
      totalTrades: 15,
      winningTrades: 9,
      losingTrades: 6,
      winRate: 60,
      totalProfit: 850.75,
      totalLoss: 600,
      netProfit: 250.75,
      maxDrawdown: 8.5,
    },
  })

  // Estado para o último sinal
  const [lastSignal, setLastSignal] = useState({
    signal: "buy",
    reason: "SMA 7 cruzou acima de SMA 25",
    timestamp: new Date(Date.now() - 30 * 60 * 1000),
  })

  // Estado para os logs de trading
  const [tradingLogs, setTradingLogs] = useState([
    {
      id: 1,
      type: "signal",
      message: "Sinal de COMPRA detectado: SMA 7 cruzou acima de SMA 25",
      timestamp: new Date(Date.now() - 35 * 60 * 1000),
    },
    {
      id: 2,
      type: "order",
      message: "Ordem de COMPRA executada: 0.05 BTC a $51200",
      timestamp: new Date(Date.now() - 34 * 60 * 1000),
    },
    {
      id: 3,
      type: "signal",
      message: "Sinal de COMPRA detectado: RSI saiu da zona de sobrevenda (32.5)",
      timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000),
    },
    {
      id: 4,
      type: "order",
      message: "Ordem de COMPRA executada: 1.2 ETH a $2750",
      timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000),
    },
  ])

  // Manipuladores de eventos para as configurações
  const handleSettingChange = (field, value) => {
    setTradingSettings({
      ...tradingSettings,
      [field]: field === "strategy" || field === "riskLevel" || field === "trailingStop" ? value : Number(value),
    })
  }

  // Função para iniciar/parar o trading automático
  const toggleAutoTrading = () => {
    if (autoTradingEnabled) {
      setAutoTradingEnabled(false)

      toast({
        title: "Trading automático desativado",
        description: "O sistema de trading automático foi desativado.",
      })
    } else {
      setAutoTradingEnabled(true)

      toast({
        title: "Trading automático ativado",
        description: "O sistema de trading automático foi ativado e está monitorando o mercado.",
      })
    }
  }

  // Simular atualização de preço em tempo real
  useEffect(() => {
    if (!autoTradingEnabled) return

    const interval = setInterval(() => {
      // Simular novo preço
      const newPrice = simulateRealtimePrice(currentPrice)
      setCurrentPrice(newPrice)

      // Atualizar histórico de preços
      setPriceHistory((prev) => [...prev.slice(1), { time: new Date().toLocaleTimeString(), price: newPrice }])

      // Atualizar preços das posições abertas
      setTradingAccount((prev) => ({
        ...prev,
        openPositions: prev.openPositions.map((position) => {
          const newPositionPrice =
            position.coin === "BTC" ? newPrice : position.currentPrice * (1 + (Math.random() * 0.01 - 0.005))
          const pnl = (newPositionPrice - position.entryPrice) * position.amount
          const pnlPercentage = ((newPositionPrice - position.entryPrice) / position.entryPrice) * 100

          return {
            ...position,
            currentPrice: newPositionPrice,
            pnl,
            pnlPercentage,
          }
        }),
        equity:
          prev.balance +
          prev.openPositions.reduce((sum, position) => {
            const newPositionPrice =
              position.coin === "BTC" ? newPrice : position.currentPrice * (1 + (Math.random() * 0.01 - 0.005))
            const pnl = (newPositionPrice - position.entryPrice) * position.amount
            return sum + pnl
          }, 0),
      }))

      // Gerar sinal de trading aleatoriamente (para demonstração)
      if (Math.random() < 0.05) {
        // 5% de chance a cada intervalo
        const signalType = Math.random() > 0.5 ? "buy" : "sell"
        const reasons = [
          "SMA 7 cruzou acima de SMA 25",
          "RSI saiu da zona de sobrevenda (32.5)",
          "MACD cruzou acima da linha de sinal",
          "Preço cruzou acima da banda inferior de Bollinger",
          "RSI saiu da zona de sobrecompra (72.8)",
          "MACD cruzou abaixo da linha de sinal",
          "Preço cruzou abaixo da banda superior de Bollinger",
        ]
        const reason = reasons[Math.floor(Math.random() * reasons.length)]

        setLastSignal({
          signal: signalType,
          reason,
          timestamp: new Date(),
        })

        // Adicionar ao log
        setTradingLogs((prev) => [
          {
            id: Date.now(),
            type: "signal",
            message: `Sinal de ${signalType === "buy" ? "COMPRA" : "VENDA"} detectado: ${reason}`,
            timestamp: new Date(),
          },
          ...prev,
        ])

        // Simular execução de ordem (50% de chance)
        if (Math.random() > 0.5) {
          setTimeout(() => {
            const amount = signalType === "buy" ? (Math.random() * 0.1).toFixed(3) : 0

            // Adicionar ao log
            setTradingLogs((prev) => [
              {
                id: Date.now(),
                type: "order",
                message: `Ordem de ${signalType === "buy" ? "COMPRA" : "VENDA"} executada: ${amount} BTC a $${newPrice.toFixed(2)}`,
                timestamp: new Date(),
              },
              ...prev,
            ])

            // Atualizar posições se for compra
            if (signalType === "buy" && amount > 0) {
              setTradingAccount((prev) => {
                const newPosition = {
                  id: Date.now(),
                  coin: "BTC",
                  amount: Number.parseFloat(amount),
                  entryPrice: newPrice,
                  currentPrice: newPrice,
                  pnl: 0,
                  pnlPercentage: 0,
                }

                return {
                  ...prev,
                  openPositions: [...prev.openPositions, newPosition],
                  availableBalance: prev.availableBalance - newPrice * Number.parseFloat(amount),
                }
              })
            }
          }, 1000) // Simular um pequeno atraso na execução
        }
      }
    }, 5000) // Atualizar a cada 5 segundos

    return () => clearInterval(interval)
  }, [autoTradingEnabled, currentPrice])

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div>
          <h2 className="text-3xl font-bold">Auto Trading</h2>
          <p className="text-muted-foreground">Configurar operações automáticas</p>
        </div>
        <div className="flex items-center space-x-2">
          <CoinSelector selectedCoin={selectedCoin} onSelectCoin={setSelectedCoin} isLoading={isLoading} />
          <Button onClick={toggleAutoTrading} variant={autoTradingEnabled ? "destructive" : "default"}>
            {autoTradingEnabled ? (
              <>
                <Pause className="h-4 w-4 mr-2" />
                Parar Trading
              </>
            ) : (
              <>
                <Play className="h-4 w-4 mr-2" />
                Iniciar Trading
              </>
            )}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Preço Atual</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ${currentPrice.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div
              className={`flex items-center text-sm ${currentPrice > priceHistory[priceHistory.length - 2]?.price ? "text-green-500" : "text-red-500"}`}
            >
              {currentPrice > priceHistory[priceHistory.length - 2]?.price ? (
                <ArrowUpRight className="h-4 w-4 mr-1" />
              ) : (
                <ArrowDownRight className="h-4 w-4 mr-1" />
              )}
              <span>
                {(
                  ((currentPrice - priceHistory[priceHistory.length - 2]?.price) /
                    priceHistory[priceHistory.length - 2]?.price) *
                  100
                ).toFixed(2)}
                %
              </span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Saldo Disponível</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              $
              {tradingAccount.availableBalance.toLocaleString("pt-BR", {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2,
              })}
            </div>
            <div className="text-sm text-muted-foreground">
              {((tradingAccount.availableBalance / tradingAccount.balance) * 100).toFixed(0)}% do saldo total
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Posições Abertas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{tradingAccount.openPositions.length}</div>
            <div className="text-sm text-muted-foreground">
              Valor: $
              {tradingAccount.openPositions
                .reduce((sum, pos) => sum + pos.currentPrice * pos.amount, 0)
                .toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">P&L Total</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              $
              {tradingAccount.performance.netProfit.toLocaleString("pt-BR", {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2,
              })}
            </div>
            <div className={`text-sm ${tradingAccount.performance.netProfit >= 0 ? "text-green-500" : "text-red-500"}`}>
              {((tradingAccount.performance.netProfit / tradingAccount.balance) * 100).toFixed(2)}% do capital
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="dashboard">
            <BarChart3 className="h-4 w-4 mr-2" />
            Dashboard
          </TabsTrigger>
          <TabsTrigger value="positions">
            <Wallet className="h-4 w-4 mr-2" />
            Posições
          </TabsTrigger>
          <TabsTrigger value="settings">
            <Settings className="h-4 w-4 mr-2" />
            Configurações
          </TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Gráfico de Preço</CardTitle>
                <CardDescription>Preço em tempo real</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={priceHistory}>
                      <defs>
                        <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#8884d8" stopOpacity={0.8} />
                          <stop offset="95%" stopColor="#8884d8" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="time" />
                      <YAxis domain={["auto", "auto"]} />
                      <Tooltip />
                      <Area type="monotone" dataKey="price" stroke="#8884d8" fillOpacity={1} fill="url(#colorPrice)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Último Sinal</CardTitle>
                <CardDescription>Último sinal de trading gerado</CardDescription>
              </CardHeader>
              <CardContent>
                {lastSignal ? (
                  <div className="space-y-4">
                    <div className="flex items-center space-x-2">
                      <Badge className={lastSignal.signal === "buy" ? "bg-green-500" : "bg-red-500"}>
                        {lastSignal.signal === "buy" ? "COMPRA" : "VENDA"}
                      </Badge>
                      <span className="text-sm text-muted-foreground">
                        {new Date(lastSignal.timestamp).toLocaleTimeString()}
                      </span>
                    </div>

                    <p className="text-sm">{lastSignal.reason}</p>

                    <div className="pt-4 border-t">
                      <h4 className="font-medium mb-2">Status do Trading</h4>
                      <div className="flex items-center space-x-2">
                        <div
                          className={`h-3 w-3 rounded-full ${autoTradingEnabled ? "bg-green-500" : "bg-red-500"}`}
                        ></div>
                        <span>{autoTradingEnabled ? "Ativo" : "Inativo"}</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-6 text-center">
                    <TrendingUp className="h-10 w-10 text-muted-foreground mb-2" />
                    <h3 className="text-lg font-medium">Nenhum sinal gerado</h3>
                    <p className="text-sm text-muted-foreground mt-1">Nenhum sinal de trading foi gerado ainda.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Logs de Trading</CardTitle>
              <CardDescription>Histórico de atividades recentes</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 max-h-[300px] overflow-y-auto">
                {tradingLogs.map((log) => (
                  <div key={log.id} className="flex items-start space-x-3 border-b pb-3 last:border-0">
                    <div
                      className={`p-2 rounded-full ${log.type === "signal" ? "bg-blue-100 dark:bg-blue-900" : log.type === "order" ? "bg-green-100 dark:bg-green-900" : "bg-red-100 dark:bg-red-900"}`}
                    >
                      {log.type === "signal" ? (
                        <TrendingUp className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                      ) : log.type === "order" ? (
                        <DollarSign className="h-4 w-4 text-green-600 dark:text-green-400" />
                      ) : (
                        <AlertTriangle className="h-4 w-4 text-red-600 dark:text-red-400" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between">
                        <h4 className="font-medium">
                          {log.type === "signal" ? "Sinal" : log.type === "order" ? "Ordem" : "Erro"}
                        </h4>
                        <span className="text-xs text-muted-foreground">
                          {new Date(log.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                      <p className="text-sm">{log.message}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                <History className="h-4 w-4 mr-2" />
                Ver Histórico Completo
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="positions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Posições Abertas</CardTitle>
              <CardDescription>Suas posições de trading atuais</CardDescription>
            </CardHeader>
            <CardContent>
              {tradingAccount.openPositions.length > 0 ? (
                <div className="space-y-4">
                  {tradingAccount.openPositions.map((position) => (
                    <div key={position.id} className="flex items-center justify-between border-b pb-3 last:border-0">
                      <div className="flex items-center space-x-3">
                        <div className="p-2 rounded-full bg-blue-100 dark:bg-blue-900">
                          <Wallet className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                        </div>
                        <div>
                          <h4 className="font-medium">{position.coin}</h4>
                          <p className="text-sm text-muted-foreground">{position.amount} unidades</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div
                          className={`font-medium ${position.pnl >= 0 ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"}`}
                        >
                          ${position.pnl.toFixed(2)} ({position.pnlPercentage >= 0 ? "+" : ""}
                          {position.pnlPercentage.toFixed(2)}%)
                        </div>
                        <p className="text-sm text-muted-foreground">
                          $
                          {position.entryPrice.toLocaleString("pt-BR", {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                          })}{" "}
                          → $
                          {position.currentPrice.toLocaleString("pt-BR", {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                          })}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-6 text-center">
                  <Wallet className="h-10 w-10 text-muted-foreground mb-2" />
                  <h3 className="text-lg font-medium">Nenhuma posição aberta</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Você não tem posições de trading abertas no momento.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Posições Fechadas</CardTitle>
              <CardDescription>Histórico de posições encerradas</CardDescription>
            </CardHeader>
            <CardContent>
              {tradingAccount.closedPositions.length > 0 ? (
                <div className="space-y-4">
                  {tradingAccount.closedPositions.map((position) => (
                    <div key={position.id} className="flex items-center justify-between border-b pb-3 last:border-0">
                      <div className="flex items-center space-x-3">
                        <div
                          className={`p-2 rounded-full ${position.pnl >= 0 ? "bg-green-100 dark:bg-green-900" : "bg-red-100 dark:bg-red-900"}`}
                        >
                          {position.pnl >= 0 ? (
                            <ArrowUpRight className="h-4 w-4 text-green-600 dark:text-green-400" />
                          ) : (
                            <ArrowDownRight className="h-4 w-4 text-red-600 dark:text-red-400" />
                          )}
                        </div>
                        <div>
                          <h4 className="font-medium">{position.coin}</h4>
                          <p className="text-sm text-muted-foreground">{position.amount} unidades</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div
                          className={`font-medium ${position.pnl >= 0 ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"}`}
                        >
                          ${position.pnl.toFixed(2)} ({position.pnlPercentage >= 0 ? "+" : ""}
                          {position.pnlPercentage.toFixed(2)}%)
                        </div>
                        <p className="text-sm text-muted-foreground">
                          $
                          {position.entryPrice.toLocaleString("pt-BR", {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                          })}{" "}
                          → $
                          {position.exitPrice.toLocaleString("pt-BR", {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                          })}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(position.closeDate).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-6 text-center">
                  <History className="h-10 w-10 text-muted-foreground mb-2" />
                  <h3 className="text-lg font-medium">Nenhuma posição fechada</h3>
                  <p className="text-sm text-muted-foreground mt-1">Você não tem histórico de posições fechadas.</p>
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                <History className="h-4 w-4 mr-2" />
                Ver Histórico Completo
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Configurações de Trading</CardTitle>
              <CardDescription>Configure os parâmetros para o trading automático</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-4">Estratégia</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="strategy">Tipo de Estratégia</Label>
                    <Select
                      value={tradingSettings.strategy}
                      onValueChange={(value) => handleSettingChange("strategy", value)}
                    >
                      <SelectTrigger id="strategy">
                        <SelectValue placeholder="Selecione o tipo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sma">SMA Crossover</SelectItem>
                        <SelectItem value="rsi">RSI Overbought/Oversold</SelectItem>
                        <SelectItem value="macd">MACD Crossover</SelectItem>
                        <SelectItem value="bollinger">Bollinger Bands</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {tradingSettings.strategy === "sma" && (
                    <>
                      <div className="space-y-2">
                        <Label htmlFor="short-period">Período Curto</Label>
                        <Input
                          id="short-period"
                          type="number"
                          min="1"
                          max="50"
                          value={tradingSettings.shortPeriod}
                          onChange={(e) => handleSettingChange("shortPeriod", e.target.value)}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="long-period">Período Longo</Label>
                        <Input
                          id="long-period"
                          type="number"
                          min="5"
                          max="200"
                          value={tradingSettings.longPeriod}
                          onChange={(e) => handleSettingChange("longPeriod", e.target.value)}
                        />
                      </div>
                    </>
                  )}

                  {tradingSettings.strategy === "rsi" && (
                    <>
                      <div className="space-y-2">
                        <Label htmlFor="rsi-period">Período RSI</Label>
                        <Input
                          id="rsi-period"
                          type="number"
                          min="1"
                          max="50"
                          value={tradingSettings.rsiPeriod}
                          onChange={(e) => handleSettingChange("rsiPeriod", e.target.value)}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="rsi-overbought">Nível de Sobrecompra</Label>
                        <Input
                          id="rsi-overbought"
                          type="number"
                          min="50"
                          max="100"
                          value={tradingSettings.rsiOverbought}
                          onChange={(e) => handleSettingChange("rsiOverbought", e.target.value)}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="rsi-oversold">Nível de Sobrevenda</Label>
                        <Input
                          id="rsi-oversold"
                          type="number"
                          min="0"
                          max="50"
                          value={tradingSettings.rsiOversold}
                          onChange={(e) => handleSettingChange("rsiOversold", e.target.value)}
                        />
                      </div>
                    </>
                  )}
                </div>
              </div>

              <div className="border-t pt-6">
                <h3 className="text-lg font-medium mb-4">Gerenciamento de Capital</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="initial-balance">Capital Inicial ($)</Label>
                    <Input
                      id="initial-balance"
                      type="number"
                      min="100"
                      value={tradingSettings.initialBalance}
                      onChange={(e) => handleSettingChange("initialBalance", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="position-size">Tamanho da Posição (%)</Label>
                    <Input
                      id="position-size"
                      type="number"
                      min="1"
                      max="100"
                      value={tradingSettings.positionSize}
                      onChange={(e) => handleSettingChange("positionSize", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="max-positions">Máximo de Posições Abertas</Label>
                    <Input
                      id="max-positions"
                      type="number"
                      min="1"
                      max="10"
                      value={tradingSettings.maxOpenPositions}
                      onChange={(e) => handleSettingChange("maxOpenPositions", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="risk-level">Nível de Risco</Label>
                    <Select
                      value={tradingSettings.riskLevel}
                      onValueChange={(value) => handleSettingChange("riskLevel", value)}
                    >
                      <SelectTrigger id="risk-level">
                        <SelectValue placeholder="Selecione o nível" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Baixo</SelectItem>
                        <SelectItem value="medium">Médio</SelectItem>
                        <SelectItem value="high">Alto</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <div className="border-t pt-6">
                <h3 className="text-lg font-medium mb-4">Gerenciamento de Risco</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="stop-loss">Stop Loss (%)</Label>
                    <Input
                      id="stop-loss"
                      type="number"
                      min="0.1"
                      max="50"
                      step="0.1"
                      value={tradingSettings.stopLoss}
                      onChange={(e) => handleSettingChange("stopLoss", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="take-profit">Take Profit (%)</Label>
                    <Input
                      id="take-profit"
                      type="number"
                      min="0.1"
                      max="100"
                      step="0.1"
                      value={tradingSettings.takeProfit}
                      onChange={(e) => handleSettingChange("takeProfit", e.target.value)}
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <Switch
                      id="trailing-stop"
                      checked={tradingSettings.trailingStop}
                      onCheckedChange={(checked) => handleSettingChange("trailingStop", checked)}
                    />
                    <Label htmlFor="trailing-stop">Usar Trailing Stop</Label>
                  </div>

                  {tradingSettings.trailingStop && (
                    <div className="space-y-2">
                      <Label htmlFor="trailing-percent">Trailing Stop (%)</Label>
                      <Input
                        id="trailing-percent"
                        type="number"
                        min="0.1"
                        max="20"
                        step="0.1"
                        value={tradingSettings.trailingPercent}
                        onChange={(e) => handleSettingChange("trailingPercent", e.target.value)}
                      />
                    </div>
                  )}

                  <div className="space-y-2">
                    <Label htmlFor="rebalance-interval">Intervalo de Rebalanceamento (horas)</Label>
                    <Input
                      id="rebalance-interval"
                      type="number"
                      min="1"
                      max="168"
                      value={tradingSettings.rebalanceInterval}
                      onChange={(e) => handleSettingChange("rebalanceInterval", e.target.value)}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full">Salvar Configurações</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
