"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Loader2, Send, CheckCircle2, XCircle, AlertTriangle, RefreshCw, Clock } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  sendTelegramNotification,
  formatSignalMessage,
  formatAlertMessage,
  formatOrderMessage,
  formatFlashSignal,
  formatMainMenu,
} from "@/lib/notification-service"

// Tipos para o histórico de notificações
interface NotificationHistoryItem {
  id: string
  timestamp: Date
  type: "telegram" | "discord" | "email" | "app"
  messageType: "signal" | "alert" | "order" | "flash" | "menu" | "test"
  status: "success" | "failed" | "pending"
  message: string
  error?: string
}

// Configuração do Telegram para testes
interface TelegramConfig {
  botToken: string
  chatId: string
}

export function NotificationTester() {
  const { toast } = useToast()
  const [isSending, setIsSending] = useState(false)
  const [telegramConfig, setTelegramConfig] = useState<TelegramConfig>({
    botToken: "",
    chatId: "",
  })
  const [testMessage, setTestMessage] = useState("")
  const [messageType, setMessageType] = useState<string>("test")
  const [notificationHistory, setNotificationHistory] = useState<NotificationHistoryItem[]>([])
  const [diagnosticResults, setDiagnosticResults] = useState<{
    configValid: boolean
    internetConnection: boolean
    telegramApiAccessible: boolean
    lastError: string | null
  }>({
    configValid: false,
    internetConnection: true,
    telegramApiAccessible: false,
    lastError: null,
  })
  const [isRunningDiagnostics, setIsRunningDiagnostics] = useState(false)

  // Carregar configurações salvas ao iniciar
  useEffect(() => {
    const savedConfig = localStorage.getItem("telegramConfig")
    if (savedConfig) {
      try {
        setTelegramConfig(JSON.parse(savedConfig))
      } catch (e) {
        console.error("Erro ao carregar configuração do Telegram:", e)
      }
    }

    const savedHistory = localStorage.getItem("notificationHistory")
    if (savedHistory) {
      try {
        const history = JSON.parse(savedHistory)
        // Converter strings de data para objetos Date
        const parsedHistory = history.map((item: any) => ({
          ...item,
          timestamp: new Date(item.timestamp),
        }))
        setNotificationHistory(parsedHistory)
      } catch (e) {
        console.error("Erro ao carregar histórico de notificações:", e)
      }
    }
  }, [])

  // Salvar configurações quando alteradas
  useEffect(() => {
    localStorage.setItem("telegramConfig", JSON.stringify(telegramConfig))
  }, [telegramConfig])

  // Salvar histórico quando alterado
  useEffect(() => {
    localStorage.setItem("notificationHistory", JSON.stringify(notificationHistory))
  }, [notificationHistory])

  // Verificar se a configuração é válida
  useEffect(() => {
    setDiagnosticResults((prev) => ({
      ...prev,
      configValid: Boolean(telegramConfig.botToken && telegramConfig.chatId),
    }))
  }, [telegramConfig])

  // Função para gerar uma mensagem de exemplo com base no tipo
  const generateExampleMessage = () => {
    switch (messageType) {
      case "signal":
        return formatSignalMessage(
          "buy",
          "BTC-BRL",
          250000,
          "MACD aponta tendência de alta | Média móvel cruzada com volume relevante",
        )
      case "alert":
        return formatAlertMessage(
          {
            type: "price",
            condition: "above",
            value: 250000,
          },
          250000,
        )
      case "order":
        return formatOrderMessage("buy", "BTC-BRL", 250000, 0.05)
      case "flash":
        return formatFlashSignal("BTC-BRL", "buy", "23:50:25", 3, "23:51:25", "23:52:25", 2)
      case "menu":
        return formatMainMenu(true)
      case "test":
      default:
        return "🤖 *Teste de Notificação*\n\nEsta é uma mensagem de teste do seu robô de trading FlexInvest. Se você está vendo esta mensagem, suas notificações estão configuradas corretamente!"
    }
  }

  // Atualizar a mensagem de teste quando o tipo mudar
  useEffect(() => {
    setTestMessage(generateExampleMessage())
  }, [messageType])

  // Função para enviar uma notificação de teste
  const sendTestNotification = async () => {
    if (!telegramConfig.botToken || !telegramConfig.chatId) {
      toast({
        title: "Configuração incompleta",
        description: "Por favor, preencha o Token do Bot e o ID do Chat antes de testar.",
        variant: "destructive",
      })
      return
    }

    setIsSending(true)

    // Criar um ID único para esta notificação
    const notificationId = `notification_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`

    // Adicionar ao histórico como pendente
    const newHistoryItem: NotificationHistoryItem = {
      id: notificationId,
      timestamp: new Date(),
      type: "telegram",
      messageType: messageType as any,
      status: "pending",
      message: testMessage,
    }

    setNotificationHistory((prev) => [newHistoryItem, ...prev])

    try {
      const success = await sendTelegramNotification(telegramConfig.botToken, telegramConfig.chatId, testMessage)

      // Atualizar o status no histórico
      setNotificationHistory((prev) =>
        prev.map((item) =>
          item.id === notificationId
            ? {
                ...item,
                status: success ? "success" : "failed",
                error: success ? undefined : "Falha ao enviar notificação",
              }
            : item,
        ),
      )

      if (success) {
        toast({
          title: "Notificação enviada",
          description: "A mensagem de teste foi enviada com sucesso para o Telegram.",
        })
      } else {
        toast({
          title: "Falha no envio",
          description: "Não foi possível enviar a mensagem. Verifique as configurações e tente novamente.",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Erro ao enviar notificação:", error)

      // Atualizar o histórico com o erro
      setNotificationHistory((prev) =>
        prev.map((item) =>
          item.id === notificationId
            ? {
                ...item,
                status: "failed",
                error: error instanceof Error ? error.message : "Erro desconhecido",
              }
            : item,
        ),
      )

      toast({
        title: "Erro",
        description: `Ocorreu um erro ao enviar a notificação: ${
          error instanceof Error ? error.message : "Erro desconhecido"
        }`,
        variant: "destructive",
      })
    } finally {
      setIsSending(false)
    }
  }

  // Função para executar diagnósticos
  const runDiagnostics = async () => {
    setIsRunningDiagnostics(true)
    setDiagnosticResults({
      configValid: Boolean(telegramConfig.botToken && telegramConfig.chatId),
      internetConnection: true,
      telegramApiAccessible: false,
      lastError: null,
    })

    // Verificar conexão com a internet
    try {
      const internetCheck = await fetch("https://www.google.com", { mode: "no-cors" })
      setDiagnosticResults((prev) => ({
        ...prev,
        internetConnection: true,
      }))
    } catch (error) {
      setDiagnosticResults((prev) => ({
        ...prev,
        internetConnection: false,
        lastError: "Não foi possível conectar à internet",
      }))
      setIsRunningDiagnostics(false)
      return
    }

    // Verificar acesso à API do Telegram
    if (telegramConfig.botToken) {
      try {
        const response = await fetch(`https://api.telegram.org/bot${telegramConfig.botToken}/getMe`)
        const data = await response.json()

        if (data.ok) {
          setDiagnosticResults((prev) => ({
            ...prev,
            telegramApiAccessible: true,
          }))
        } else {
          setDiagnosticResults((prev) => ({
            ...prev,
            telegramApiAccessible: false,
            lastError: `Erro na API do Telegram: ${data.description}`,
          }))
        }
      } catch (error) {
        setDiagnosticResults((prev) => ({
          ...prev,
          telegramApiAccessible: false,
          lastError: error instanceof Error ? error.message : "Erro ao acessar a API do Telegram",
        }))
      }
    }

    setIsRunningDiagnostics(false)
  }

  // Função para limpar o histórico
  const clearHistory = () => {
    if (confirm("Tem certeza que deseja limpar todo o histórico de notificações?")) {
      setNotificationHistory([])
      toast({
        title: "Histórico limpo",
        description: "O histórico de notificações foi limpo com sucesso.",
      })
    }
  }

  // Função para formatar a data
  const formatDate = (date: Date) => {
    return date.toLocaleString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    })
  }

  // Função para reenviar uma notificação
  const resendNotification = async (item: NotificationHistoryItem) => {
    if (!telegramConfig.botToken || !telegramConfig.chatId) {
      toast({
        title: "Configuração incompleta",
        description: "Por favor, preencha o Token do Bot e o ID do Chat antes de reenviar.",
        variant: "destructive",
      })
      return
    }

    setIsSending(true)

    // Criar um novo ID para esta notificação
    const notificationId = `notification_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`

    // Adicionar ao histórico como pendente
    const newHistoryItem: NotificationHistoryItem = {
      id: notificationId,
      timestamp: new Date(),
      type: "telegram",
      messageType: item.messageType,
      status: "pending",
      message: item.message,
    }

    setNotificationHistory((prev) => [newHistoryItem, ...prev])

    try {
      const success = await sendTelegramNotification(telegramConfig.botToken, telegramConfig.chatId, item.message)

      // Atualizar o status no histórico
      setNotificationHistory((prev) =>
        prev.map((historyItem) =>
          historyItem.id === notificationId
            ? {
                ...historyItem,
                status: success ? "success" : "failed",
                error: success ? undefined : "Falha ao reenviar notificação",
              }
            : historyItem,
        ),
      )

      if (success) {
        toast({
          title: "Notificação reenviada",
          description: "A mensagem foi reenviada com sucesso para o Telegram.",
        })
      } else {
        toast({
          title: "Falha no reenvio",
          description: "Não foi possível reenviar a mensagem. Verifique as configurações e tente novamente.",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Erro ao reenviar notificação:", error)

      // Atualizar o histórico com o erro
      setNotificationHistory((prev) =>
        prev.map((historyItem) =>
          historyItem.id === notificationId
            ? {
                ...historyItem,
                status: "failed",
                error: error instanceof Error ? error.message : "Erro desconhecido",
              }
            : historyItem,
        ),
      )

      toast({
        title: "Erro",
        description: `Ocorreu um erro ao reenviar a notificação: ${
          error instanceof Error ? error.message : "Erro desconhecido"
        }`,
        variant: "destructive",
      })
    } finally {
      setIsSending(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Verificador de Notificações</CardTitle>
          <CardDescription>Teste e verifique se as notificações estão sendo enviadas corretamente</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="test">
            <TabsList className="mb-4">
              <TabsTrigger value="test">Testar Envio</TabsTrigger>
              <TabsTrigger value="history">Histórico</TabsTrigger>
              <TabsTrigger value="diagnostics">Diagnóstico</TabsTrigger>
            </TabsList>

            <TabsContent value="test" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="botToken">Token do Bot</Label>
                    <Input
                      id="botToken"
                      placeholder="123456789:ABCdefGHIjklMNOpqrSTUvwxYZ"
                      value={telegramConfig.botToken}
                      onChange={(e) => setTelegramConfig({ ...telegramConfig, botToken: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="chatId">ID do Chat</Label>
                    <Input
                      id="chatId"
                      placeholder="123456789"
                      value={telegramConfig.chatId}
                      onChange={(e) => setTelegramConfig({ ...telegramConfig, chatId: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="messageType">Tipo de Mensagem</Label>
                    <Select value={messageType} onValueChange={setMessageType}>
                      <SelectTrigger id="messageType">
                        <SelectValue placeholder="Selecione o tipo de mensagem" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="test">Mensagem de Teste</SelectItem>
                        <SelectItem value="signal">Sinal de Trading</SelectItem>
                        <SelectItem value="alert">Alerta de Preço</SelectItem>
                        <SelectItem value="order">Confirmação de Ordem</SelectItem>
                        <SelectItem value="flash">Sinal Flash</SelectItem>
                        <SelectItem value="menu">Menu Principal</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Button
                    onClick={sendTestNotification}
                    disabled={isSending || !telegramConfig.botToken || !telegramConfig.chatId}
                    className="w-full"
                  >
                    {isSending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Enviando...
                      </>
                    ) : (
                      <>
                        <Send className="mr-2 h-4 w-4" />
                        Enviar Notificação de Teste
                      </>
                    )}
                  </Button>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="testMessage">Mensagem de Teste</Label>
                  <Textarea
                    id="testMessage"
                    placeholder="Digite a mensagem de teste..."
                    value={testMessage}
                    onChange={(e) => setTestMessage(e.target.value)}
                    className="h-[200px] font-mono text-sm"
                  />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="history">
              {notificationHistory.length > 0 ? (
                <>
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-medium">Histórico de Notificações</h3>
                    <Button variant="outline" size="sm" onClick={clearHistory}>
                      Limpar Histórico
                    </Button>
                  </div>
                  <div className="border rounded-md">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Data/Hora</TableHead>
                          <TableHead>Tipo</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Ações</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {notificationHistory.map((item) => (
                          <TableRow key={item.id}>
                            <TableCell>{formatDate(item.timestamp)}</TableCell>
                            <TableCell>
                              <Badge
                                variant="outline"
                                className={
                                  item.messageType === "signal"
                                    ? "bg-green-100"
                                    : item.messageType === "alert"
                                      ? "bg-yellow-100"
                                      : item.messageType === "order"
                                        ? "bg-blue-100"
                                        : item.messageType === "flash"
                                          ? "bg-orange-100"
                                          : "bg-gray-100"
                                }
                              >
                                {item.messageType === "signal"
                                  ? "Sinal"
                                  : item.messageType === "alert"
                                    ? "Alerta"
                                    : item.messageType === "order"
                                      ? "Ordem"
                                      : item.messageType === "flash"
                                        ? "Flash"
                                        : item.messageType === "menu"
                                          ? "Menu"
                                          : "Teste"}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              {item.status === "success" ? (
                                <div className="flex items-center text-green-600">
                                  <CheckCircle2 className="h-4 w-4 mr-1" />
                                  <span>Sucesso</span>
                                </div>
                              ) : item.status === "failed" ? (
                                <div className="flex items-center text-red-600">
                                  <XCircle className="h-4 w-4 mr-1" />
                                  <span>Falha</span>
                                </div>
                              ) : (
                                <div className="flex items-center text-yellow-600">
                                  <Clock className="h-4 w-4 mr-1 animate-spin" />
                                  <span>Pendente</span>
                                </div>
                              )}
                            </TableCell>
                            <TableCell>
                              <div className="flex space-x-2">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => resendNotification(item)}
                                  disabled={isSending}
                                >
                                  <RefreshCw className="h-3 w-3 mr-1" />
                                  Reenviar
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </>
              ) : (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">Nenhuma notificação enviada ainda.</p>
                </div>
              )}
            </TabsContent>

            <TabsContent value="diagnostics" className="space-y-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium">Diagnóstico do Sistema de Notificações</h3>
                <Button variant="outline" size="sm" onClick={runDiagnostics} disabled={isRunningDiagnostics}>
                  {isRunningDiagnostics ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Executando...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Executar Diagnóstico
                    </>
                  )}
                </Button>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardContent className="pt-6">
                      <div className="flex flex-col items-center text-center">
                        {diagnosticResults.configValid ? (
                          <CheckCircle2 className="h-8 w-8 text-green-500 mb-2" />
                        ) : (
                          <XCircle className="h-8 w-8 text-red-500 mb-2" />
                        )}
                        <h3 className="font-medium">Configuração</h3>
                        <p className="text-sm text-muted-foreground">
                          {diagnosticResults.configValid
                            ? "Token e Chat ID configurados"
                            : "Token ou Chat ID não configurados"}
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="pt-6">
                      <div className="flex flex-col items-center text-center">
                        {diagnosticResults.internetConnection ? (
                          <CheckCircle2 className="h-8 w-8 text-green-500 mb-2" />
                        ) : (
                          <XCircle className="h-8 w-8 text-red-500 mb-2" />
                        )}
                        <h3 className="font-medium">Conexão com Internet</h3>
                        <p className="text-sm text-muted-foreground">
                          {diagnosticResults.internetConnection ? "Conectado à internet" : "Sem conexão com a internet"}
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="pt-6">
                      <div className="flex flex-col items-center text-center">
                        {diagnosticResults.telegramApiAccessible ? (
                          <CheckCircle2 className="h-8 w-8 text-green-500 mb-2" />
                        ) : diagnosticResults.configValid ? (
                          <XCircle className="h-8 w-8 text-red-500 mb-2" />
                        ) : (
                          <AlertTriangle className="h-8 w-8 text-yellow-500 mb-2" />
                        )}
                        <h3 className="font-medium">API do Telegram</h3>
                        <p className="text-sm text-muted-foreground">
                          {diagnosticResults.telegramApiAccessible
                            ? "API acessível e token válido"
                            : !diagnosticResults.configValid
                              ? "Configure o token para verificar"
                              : "Não foi possível acessar a API"}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {diagnosticResults.lastError && (
                  <Alert variant="destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>Erro detectado</AlertTitle>
                    <AlertDescription>{diagnosticResults.lastError}</AlertDescription>
                  </Alert>
                )}

                <div className="space-y-4 mt-6">
                  <h4 className="font-medium">Solução de Problemas Comuns</h4>
                  <div className="space-y-2">
                    <details className="border rounded-md p-2">
                      <summary className="font-medium cursor-pointer">O bot não responde às minhas mensagens</summary>
                      <div className="mt-2 text-sm space-y-2">
                        <p>1. Verifique se você iniciou uma conversa com o bot enviando /start</p>
                        <p>2. Certifique-se de que o bot não está bloqueado ou desativado</p>
                        <p>3. Confirme se o token do bot está correto e não expirou</p>
                      </div>
                    </details>

                    <details className="border rounded-md p-2">
                      <summary className="font-medium cursor-pointer">
                        Erro "Forbidden: bot was blocked by the user"
                      </summary>
                      <div className="mt-2 text-sm space-y-2">
                        <p>1. O usuário bloqueou o bot no Telegram</p>
                        <p>2. Peça ao usuário para desbloquear o bot e enviar /start novamente</p>
                      </div>
                    </details>

                    <details className="border rounded-md p-2">
                      <summary className="font-medium cursor-pointer">Erro "Bad Request: chat not found"</summary>
                      <div className="mt-2 text-sm space-y-2">
                        <p>1. O ID do chat está incorreto</p>
                        <p>2. Envie uma mensagem para @userinfobot para obter seu ID correto</p>
                        <p>3. Para grupos, o ID deve começar com um sinal de menos (-)</p>
                      </div>
                    </details>

                    <details className="border rounded-md p-2">
                      <summary className="font-medium cursor-pointer">Erro "Unauthorized"</summary>
                      <div className="mt-2 text-sm space-y-2">
                        <p>1. O token do bot está incorreto ou inválido</p>
                        <p>2. Crie um novo bot com @BotFather e obtenha um novo token</p>
                      </div>
                    </details>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter className="flex justify-between">
          <p className="text-xs text-muted-foreground">As notificações são enviadas via API oficial do Telegram</p>
        </CardFooter>
      </Card>
    </div>
  )
}
