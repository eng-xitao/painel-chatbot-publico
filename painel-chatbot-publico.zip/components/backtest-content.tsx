"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { CoinSelector } from "@/components/coin-selector"
import { XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, BarChart, Bar } from "recharts"
import { Play, Download, Save, BarChart3, ArrowRight, Plus } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { fetchMarketData, runBacktest } from "@/lib/trading-utils"

export function BacktestContent() {
  const { toast } = useToast()
  const [selectedCoin, setSelectedCoin] = useState("bitcoin")
  const [isLoading, setIsLoading] = useState(false)
  const [isSimulating, setIsSimulating] = useState(false)
  const [activeTab, setActiveTab] = useState("strategy")

  // Estado para a estratégia
  const [strategy, setStrategy] = useState({
    name: "Estratégia SMA Crossover",
    type: "sma",
    shortPeriod: 7,
    longPeriod: 25,
    rsiPeriod: 14,
    rsiOverbought: 70,
    rsiOversold: 30,
    macdFastPeriod: 12,
    macdSlowPeriod: 26,
    macdSignalPeriod: 9,
    bbPeriod: 20,
    bbDeviation: 2,
    stopLoss: 5,
    takeProfit: 10,
    trailingStop: false,
    trailingPercent: 2,
  })

  // Estado para os parâmetros de simulação
  const [simulation, setSimulation] = useState({
    initialCapital: 10000,
    positionSize: 10, // Porcentagem do capital
    startDate: "2023-01-01",
    endDate: new Date().toISOString().split("T")[0], // Data atual
    fees: 0.1, // Porcentagem
    slippage: 0.05, // Porcentagem
  })

  // Estado para os resultados da simulação
  const [results, setResults] = useState(null)

  // Manipuladores de eventos para a estratégia
  const handleStrategyChange = (field, value) => {
    setStrategy({
      ...strategy,
      [field]: field === "type" || field === "name" || field === "trailingStop" ? value : Number(value),
    })
  }

  // Manipuladores de eventos para a simulação
  const handleSimulationChange = (field, value) => {
    setSimulation({
      ...simulation,
      [field]:
        field === "initialCapital" || field === "positionSize" || field === "fees" || field === "slippage"
          ? Number(value)
          : value,
    })
  }

  // Função para iniciar a simulação
  const startSimulation = async () => {
    setIsSimulating(true)

    try {
      // Buscar dados de mercado
      const marketData = await fetchMarketData(selectedCoin)

      // Executar backtest
      const backtestResults = await runBacktest(marketData, {
        ...strategy,
        ...simulation,
      })

      setResults(backtestResults)
      setActiveTab("results")

      toast({
        title: "Simulação concluída",
        description: "Os resultados da simulação estão disponíveis.",
      })
    } catch (error) {
      console.error("Erro na simulação:", error)

      toast({
        title: "Erro na simulação",
        description: "Ocorreu um erro ao executar a simulação.",
        variant: "destructive",
      })
    } finally {
      setIsSimulating(false)
    }
  }

  // Função para salvar a estratégia
  const saveStrategy = () => {
    toast({
      title: "Estratégia salva",
      description: "Sua estratégia foi salva com sucesso.",
    })
  }

  // Função para exportar resultados
  const exportResults = () => {
    if (!results) return

    // Criar um objeto para download
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(results, null, 2))
    const downloadAnchorNode = document.createElement("a")
    downloadAnchorNode.setAttribute("href", dataStr)
    downloadAnchorNode.setAttribute(
      "download",
      `backtest_${selectedCoin}_${new Date().toISOString().split("T")[0]}.json`,
    )
    document.body.appendChild(downloadAnchorNode)
    downloadAnchorNode.click()
    downloadAnchorNode.remove()

    toast({
      title: "Resultados exportados",
      description: "Os resultados foram exportados com sucesso.",
    })
  }

  // Dados simulados para o gráfico de equidade
  const equityCurveData =
    results?.equityCurve ||
    Array(30)
      .fill(0)
      .map((_, i) => ({
        date: new Date(Date.now() - (30 - i) * 24 * 60 * 60 * 1000).toLocaleDateString(),
        equity: 10000 * (1 + i * 0.01),
      }))

  // Dados simulados para o gráfico de trades
  const tradesData = results?.trades || [
    { id: 1, type: "buy", profit: 5.2, date: "01/01/2023" },
    { id: 2, type: "sell", profit: -2.1, date: "15/01/2023" },
    { id: 3, type: "buy", profit: 7.8, date: "01/02/2023" },
    { id: 4, type: "buy", profit: 3.5, date: "15/02/2023" },
    { id: 5, type: "sell", profit: -1.5, date: "01/03/2023" },
  ]

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div>
          <h2 className="text-3xl font-bold">Backtest</h2>
          <p className="text-muted-foreground">Testar estratégias com dados históricos</p>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline" onClick={saveStrategy}>
            <Save className="h-4 w-4 mr-2" />
            Salvar Estratégia
          </Button>
          <Button onClick={startSimulation} disabled={isSimulating}>
            {isSimulating ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Simulando...
              </>
            ) : (
              <>
                <Play className="h-4 w-4 mr-2" />
                Iniciar Simulação
              </>
            )}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="md:col-span-3">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Configurações de Backtest</CardTitle>
              <CardDescription>Configure os parâmetros para testar sua estratégia</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="strategy">Estratégia</TabsTrigger>
                  <TabsTrigger value="simulation">Simulação</TabsTrigger>
                </TabsList>

                <TabsContent value="strategy" className="space-y-4 pt-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="strategy-name">Nome da Estratégia</Label>
                      <Input
                        id="strategy-name"
                        value={strategy.name}
                        onChange={(e) => handleStrategyChange("name", e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="strategy-type">Tipo de Estratégia</Label>
                      <Select value={strategy.type} onValueChange={(value) => handleStrategyChange("type", value)}>
                        <SelectTrigger id="strategy-type">
                          <SelectValue placeholder="Selecione o tipo" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="sma">SMA Crossover</SelectItem>
                          <SelectItem value="rsi">RSI Overbought/Oversold</SelectItem>
                          <SelectItem value="macd">MACD Crossover</SelectItem>
                          <SelectItem value="bollinger">Bollinger Bands</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {strategy.type === "sma" && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="short-period">Período Curto</Label>
                        <Input
                          id="short-period"
                          type="number"
                          min="1"
                          max="50"
                          value={strategy.shortPeriod}
                          onChange={(e) => handleStrategyChange("shortPeriod", e.target.value)}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="long-period">Período Longo</Label>
                        <Input
                          id="long-period"
                          type="number"
                          min="5"
                          max="200"
                          value={strategy.longPeriod}
                          onChange={(e) => handleStrategyChange("longPeriod", e.target.value)}
                        />
                      </div>
                    </div>
                  )}

                  {strategy.type === "rsi" && (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="rsi-period">Período RSI</Label>
                        <Input
                          id="rsi-period"
                          type="number"
                          min="1"
                          max="50"
                          value={strategy.rsiPeriod}
                          onChange={(e) => handleStrategyChange("rsiPeriod", e.target.value)}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="rsi-overbought">Nível de Sobrecompra</Label>
                        <Input
                          id="rsi-overbought"
                          type="number"
                          min="50"
                          max="100"
                          value={strategy.rsiOverbought}
                          onChange={(e) => handleStrategyChange("rsiOverbought", e.target.value)}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="rsi-oversold">Nível de Sobrevenda</Label>
                        <Input
                          id="rsi-oversold"
                          type="number"
                          min="0"
                          max="50"
                          value={strategy.rsiOversold}
                          onChange={(e) => handleStrategyChange("rsiOversold", e.target.value)}
                        />
                      </div>
                    </div>
                  )}

                  {strategy.type === "macd" && (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="macd-fast">Período Rápido</Label>
                        <Input
                          id="macd-fast"
                          type="number"
                          min="1"
                          max="50"
                          value={strategy.macdFastPeriod}
                          onChange={(e) => handleStrategyChange("macdFastPeriod", e.target.value)}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="macd-slow">Período Lento</Label>
                        <Input
                          id="macd-slow"
                          type="number"
                          min="5"
                          max="100"
                          value={strategy.macdSlowPeriod}
                          onChange={(e) => handleStrategyChange("macdSlowPeriod", e.target.value)}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="macd-signal">Período de Sinal</Label>
                        <Input
                          id="macd-signal"
                          type="number"
                          min="1"
                          max="50"
                          value={strategy.macdSignalPeriod}
                          onChange={(e) => handleStrategyChange("macdSignalPeriod", e.target.value)}
                        />
                      </div>
                    </div>
                  )}

                  {strategy.type === "bollinger" && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="bb-period">Período</Label>
                        <Input
                          id="bb-period"
                          type="number"
                          min="5"
                          max="50"
                          value={strategy.bbPeriod}
                          onChange={(e) => handleStrategyChange("bbPeriod", e.target.value)}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="bb-deviation">Desvio Padrão</Label>
                        <Input
                          id="bb-deviation"
                          type="number"
                          min="0.5"
                          max="4"
                          step="0.1"
                          value={strategy.bbDeviation}
                          onChange={(e) => handleStrategyChange("bbDeviation", e.target.value)}
                        />
                      </div>
                    </div>
                  )}

                  <div className="border-t pt-4">
                    <h3 className="text-lg font-medium mb-2">Gerenciamento de Risco</h3>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="stop-loss">Stop Loss (%)</Label>
                        <Input
                          id="stop-loss"
                          type="number"
                          min="0.1"
                          max="50"
                          step="0.1"
                          value={strategy.stopLoss}
                          onChange={(e) => handleStrategyChange("stopLoss", e.target.value)}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="take-profit">Take Profit (%)</Label>
                        <Input
                          id="take-profit"
                          type="number"
                          min="0.1"
                          max="100"
                          step="0.1"
                          value={strategy.takeProfit}
                          onChange={(e) => handleStrategyChange("takeProfit", e.target.value)}
                        />
                      </div>

                      <div className="flex items-center space-x-2">
                        <Switch
                          id="trailing-stop"
                          checked={strategy.trailingStop}
                          onCheckedChange={(checked) => handleStrategyChange("trailingStop", checked)}
                        />
                        <Label htmlFor="trailing-stop">Usar Trailing Stop</Label>
                      </div>

                      {strategy.trailingStop && (
                        <div className="space-y-2">
                          <Label htmlFor="trailing-percent">Trailing Stop (%)</Label>
                          <Input
                            id="trailing-percent"
                            type="number"
                            min="0.1"
                            max="20"
                            step="0.1"
                            value={strategy.trailingPercent}
                            onChange={(e) => handleStrategyChange("trailingPercent", e.target.value)}
                          />
                        </div>
                      )}
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="simulation" className="space-y-4 pt-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="coin">Moeda</Label>
                      <CoinSelector selectedCoin={selectedCoin} onSelectCoin={setSelectedCoin} isLoading={isLoading} />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="initial-capital">Capital Inicial ($)</Label>
                      <Input
                        id="initial-capital"
                        type="number"
                        min="100"
                        value={simulation.initialCapital}
                        onChange={(e) => handleSimulationChange("initialCapital", e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="position-size">Tamanho da Posição (%)</Label>
                      <Input
                        id="position-size"
                        type="number"
                        min="1"
                        max="100"
                        value={simulation.positionSize}
                        onChange={(e) => handleSimulationChange("positionSize", e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="start-date">Data de Início</Label>
                      <Input
                        id="start-date"
                        type="date"
                        value={simulation.startDate}
                        onChange={(e) => handleSimulationChange("startDate", e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="end-date">Data de Fim</Label>
                      <Input
                        id="end-date"
                        type="date"
                        value={simulation.endDate}
                        onChange={(e) => handleSimulationChange("endDate", e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="fees">Taxas (%)</Label>
                      <Input
                        id="fees"
                        type="number"
                        min="0"
                        max="5"
                        step="0.01"
                        value={simulation.fees}
                        onChange={(e) => handleSimulationChange("fees", e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="slippage">Slippage (%)</Label>
                      <Input
                        id="slippage"
                        type="number"
                        min="0"
                        max="5"
                        step="0.01"
                        value={simulation.slippage}
                        onChange={(e) => handleSimulationChange("slippage", e.target.value)}
                      />
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="results" className="space-y-4 pt-4">
                  {results ? (
                    <>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-sm font-medium">Retorno Total</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="text-2xl font-bold">{results.totalReturn.toFixed(2)}%</div>
                            <div className="text-sm text-muted-foreground">
                              ${((simulation.initialCapital * results.totalReturn) / 100).toFixed(2)}
                            </div>
                          </CardContent>
                        </Card>

                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-sm font-medium">Taxa de Acerto</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="text-2xl font-bold">{results.winRate.toFixed(2)}%</div>
                            <div className="text-sm text-muted-foreground">
                              {results.winningTrades} de {results.totalTrades} trades
                            </div>
                          </CardContent>
                        </Card>

                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-sm font-medium">Drawdown Máximo</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="text-2xl font-bold">{results.maxDrawdown.toFixed(2)}%</div>
                            <div className="text-sm text-muted-foreground">
                              ${((simulation.initialCapital * results.maxDrawdown) / 100).toFixed(2)}
                            </div>
                          </CardContent>
                        </Card>

                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-sm font-medium">Capital Final</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="text-2xl font-bold">${results.finalCapital.toFixed(2)}</div>
                            <div className="text-sm text-muted-foreground">
                              {((results.finalCapital / simulation.initialCapital - 1) * 100).toFixed(2)}% de
                              crescimento
                            </div>
                          </CardContent>
                        </Card>
                      </div>

                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                        <Card>
                          <CardHeader>
                            <CardTitle>Curva de Capital</CardTitle>
                            <CardDescription>Evolução do capital ao longo do tempo</CardDescription>
                          </CardHeader>
                          <CardContent>
                            <div className="h-[300px]">
                              <ResponsiveContainer width="100%" height="100%">
                                <AreaChart data={equityCurveData}>
                                  <defs>
                                    <linearGradient id="colorEquity" x1="0" y1="0" x2="0" y2="1">
                                      <stop offset="5%" stopColor="#8884d8" stopOpacity={0.8} />
                                      <stop offset="95%" stopColor="#8884d8" stopOpacity={0} />
                                    </linearGradient>
                                  </defs>
                                  <CartesianGrid strokeDasharray="3 3" />
                                  <XAxis dataKey="date" />
                                  <YAxis />
                                  <Tooltip />
                                  <Area
                                    type="monotone"
                                    dataKey="equity"
                                    stroke="#8884d8"
                                    fillOpacity={1}
                                    fill="url(#colorEquity)"
                                  />
                                </AreaChart>
                              </ResponsiveContainer>
                            </div>
                          </CardContent>
                        </Card>

                        <Card>
                          <CardHeader>
                            <CardTitle>Distribuição de Trades</CardTitle>
                            <CardDescription>Lucros e perdas por trade</CardDescription>
                          </CardHeader>
                          <CardContent>
                            <div className="h-[300px]">
                              <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={tradesData}>
                                  <CartesianGrid strokeDasharray="3 3" />
                                  <XAxis dataKey="date" />
                                  <YAxis />
                                  <Tooltip />
                                  <Bar
                                    dataKey="profit"
                                    fill={(data) => (data.profit >= 0 ? "#4ade80" : "#f87171")}
                                    name="Lucro/Perda (%)"
                                  />
                                </BarChart>
                              </ResponsiveContainer>
                            </div>
                          </CardContent>
                        </Card>
                      </div>

                      <div className="flex justify-end">
                        <Button variant="outline" onClick={exportResults}>
                          <Download className="h-4 w-4 mr-2" />
                          Exportar Resultados
                        </Button>
                      </div>
                    </>
                  ) : (
                    <div className="flex flex-col items-center justify-center py-12 text-center">
                      <BarChart3 className="h-16 w-16 text-muted-foreground mb-4" />
                      <h3 className="text-lg font-medium">Nenhum resultado disponível</h3>
                      <p className="text-sm text-muted-foreground mt-2 max-w-md">
                        Execute uma simulação para ver os resultados do backtest. Configure sua estratégia e parâmetros
                        de simulação e clique em "Iniciar Simulação".
                      </p>
                      <Button className="mt-4" onClick={() => setActiveTab("strategy")}>
                        Configurar Estratégia
                      </Button>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Estratégias Salvas</CardTitle>
              <CardDescription>Suas estratégias personalizadas</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between p-2 bg-muted rounded-md">
                  <div>
                    <h4 className="font-medium">SMA Crossover</h4>
                    <p className="text-xs text-muted-foreground">7/25 períodos</p>
                  </div>
                  <Button variant="ghost" size="sm">
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </div>

                <div className="flex items-center justify-between p-2 bg-muted rounded-md">
                  <div>
                    <h4 className="font-medium">RSI Bounce</h4>
                    <p className="text-xs text-muted-foreground">RSI 14 (30/70)</p>
                  </div>
                  <Button variant="ghost" size="sm">
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </div>

                <div className="flex items-center justify-between p-2 bg-muted rounded-md">
                  <div>
                    <h4 className="font-medium">MACD Trend</h4>
                    <p className="text-xs text-muted-foreground">12/26/9 períodos</p>
                  </div>
                  <Button variant="ghost" size="sm">
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                <Plus className="h-4 w-4 mr-2" />
                Nova Estratégia
              </Button>
            </CardFooter>
          </Card>

          <Card className="mt-4">
            <CardHeader>
              <CardTitle>Resultados Recentes</CardTitle>
              <CardDescription>Histórico de backtests</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between p-2 bg-muted rounded-md">
                  <div>
                    <h4 className="font-medium">BTC - SMA Crossover</h4>
                    <p className="text-xs text-muted-foreground">+18.5% | 65% win rate</p>
                  </div>
                  <Button variant="ghost" size="sm">
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </div>

                <div className="flex items-center justify-between p-2 bg-muted rounded-md">
                  <div>
                    <h4 className="font-medium">ETH - RSI Strategy</h4>
                    <p className="text-xs text-muted-foreground">+12.3% | 58% win rate</p>
                  </div>
                  <Button variant="ghost" size="sm">
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </div>

                <div className="flex items-center justify-between p-2 bg-muted rounded-md">
                  <div>
                    <h4 className="font-medium">SOL - MACD Strategy</h4>
                    <p className="text-xs text-muted-foreground">+22.7% | 62% win rate</p>
                  </div>
                  <Button variant="ghost" size="sm">
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
