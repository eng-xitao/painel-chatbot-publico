"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

interface PerformanceDashboardProps {
  tradingAccount: any
  simulationResults: any
}

export function PerformanceDashboard({ tradingAccount, simulationResults }: PerformanceDashboardProps) {
  const [timeframe, setTimeframe] = useState("all")

  // Preparar dados para os gráficos
  const prepareEquityCurveData = () => {
    if (!tradingAccount || !tradingAccount.closedPositions || tradingAccount.closedPositions.length === 0) {
      return []
    }

    // Ordenar posições fechadas por data
    const sortedPositions = [...tradingAccount.closedPositions].sort(
      (a, b) => new Date(a.closeDate).getTime() - new Date(b.closeDate).getTime(),
    )

    // Criar pontos para a curva de capital
    let runningBalance = tradingAccount.balance - tradingAccount.performance.netProfit
    const equityCurve = [{ date: new Date(sortedPositions[0].entryDate).toLocaleDateString(), balance: runningBalance }]

    sortedPositions.forEach((position) => {
      runningBalance += position.pnl
      equityCurve.push({
        date: new Date(position.closeDate).toLocaleDateString(),
        balance: runningBalance,
      })
    })

    return equityCurve
  }

  const prepareProfitLossData = () => {
    if (!tradingAccount || !tradingAccount.closedPositions || tradingAccount.closedPositions.length === 0) {
      return []
    }

    // Agrupar resultados por dia
    const dailyResults = tradingAccount.closedPositions.reduce((acc, position) => {
      const date = new Date(position.closeDate).toLocaleDateString()
      if (!acc[date]) {
        acc[date] = { profit: 0, loss: 0 }
      }

      if (position.pnl >= 0) {
        acc[date].profit += position.pnl
      } else {
        acc[date].loss += Math.abs(position.pnl)
      }

      return acc
    }, {})

    // Converter para array para o gráfico
    return Object.entries(dailyResults).map(([date, values]: [string, any]) => ({
      date,
      profit: Number.parseFloat(values.profit.toFixed(2)),
      loss: Number.parseFloat(values.loss.toFixed(2)),
    }))
  }

  const prepareWinLossRatioData = () => {
    if (!tradingAccount || !tradingAccount.performance) {
      return []
    }

    return [
      { name: "Ganhos", value: tradingAccount.performance.winningTrades },
      { name: "Perdas", value: tradingAccount.performance.losingTrades },
    ]
  }

  const prepareStrategyComparisonData = () => {
    // Dados simulados para comparação de estratégias
    // Em uma implementação real, isso viria de múltiplos backtests
    return [
      { name: "SMA", winRate: 58, returnPct: 12.5, trades: 45 },
      { name: "RSI", winRate: 62, returnPct: 15.2, trades: 38 },
      { name: "MACD", winRate: 55, returnPct: 10.8, trades: 52 },
      { name: "Bollinger", winRate: 60, returnPct: 14.3, trades: 40 },
      { name: "Volume", winRate: 57, returnPct: 11.7, trades: 42 },
    ]
  }

  const equityCurveData = prepareEquityCurveData()
  const profitLossData = prepareProfitLossData()
  const winLossRatioData = prepareWinLossRatioData()
  const strategyComparisonData = prepareStrategyComparisonData()

  // Cores para os gráficos
  const COLORS = ["#4ade80", "#f87171", "#60a5fa", "#fbbf24", "#a78bfa"]

  // Calcular métricas de desempenho
  const calculateSharpeRatio = () => {
    // Implementação simplificada da Razão de Sharpe
    // Em uma implementação real, você calcularia o retorno médio e o desvio padrão
    if (!tradingAccount || !tradingAccount.performance) return 0

    const riskFreeRate = 0.02 // 2% ao ano
    const returns = tradingAccount.closedPositions.map((p) => p.pnlPercent / 100)

    if (returns.length === 0) return 0

    const avgReturn = returns.reduce((sum, r) => sum + r, 0) / returns.length
    const stdDev = Math.sqrt(returns.reduce((sum, r) => sum + Math.pow(r - avgReturn, 2), 0) / returns.length)

    return stdDev === 0 ? 0 : ((avgReturn - riskFreeRate) / stdDev).toFixed(2)
  }

  const calculateMaxDrawdown = () => {
    if (!tradingAccount || !tradingAccount.performance) return "0%"
    return `${tradingAccount.performance.maxDrawdown.toFixed(2)}%`
  }

  const calculateROI = () => {
    if (!tradingAccount || !tradingAccount.performance) return "0%"

    const initialBalance = tradingAccount.balance - tradingAccount.performance.netProfit
    const roi = (tradingAccount.performance.netProfit / initialBalance) * 100

    return `${roi.toFixed(2)}%`
  }

  const calculateWinRate = () => {
    if (!tradingAccount || !tradingAccount.performance) return "0%"
    return `${tradingAccount.performance.winRate.toFixed(2)}%`
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-semibold">Dashboard de Desempenho</h2>
        <Select value={timeframe} onValueChange={setTimeframe}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Período" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todo o período</SelectItem>
            <SelectItem value="7d">Últimos 7 dias</SelectItem>
            <SelectItem value="30d">Últimos 30 dias</SelectItem>
            <SelectItem value="90d">Últimos 90 dias</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">ROI</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{calculateROI()}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Taxa de Acerto</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{calculateWinRate()}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Drawdown Máximo</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{calculateMaxDrawdown()}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Razão de Sharpe</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{calculateSharpeRatio()}</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="equity" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="equity">Curva de Capital</TabsTrigger>
          <TabsTrigger value="profit-loss">Lucros e Perdas</TabsTrigger>
          <TabsTrigger value="win-loss">Taxa de Acerto</TabsTrigger>
          <TabsTrigger value="strategies">Comparação</TabsTrigger>
        </TabsList>

        <TabsContent value="equity">
          <Card>
            <CardHeader>
              <CardTitle>Curva de Capital</CardTitle>
              <CardDescription>Evolução do capital ao longo do tempo</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                {equityCurveData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={equityCurveData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="balance" stroke="#4ade80" activeDot={{ r: 8 }} name="Saldo" />
                    </LineChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center justify-center h-full">
                    <p className="text-muted-foreground">Sem dados disponíveis</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="profit-loss">
          <Card>
            <CardHeader>
              <CardTitle>Lucros e Perdas Diários</CardTitle>
              <CardDescription>Distribuição de lucros e perdas por dia</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                {profitLossData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={profitLossData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="profit" fill="#4ade80" name="Lucro" />
                      <Bar dataKey="loss" fill="#f87171" name="Perda" />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center justify-center h-full">
                    <p className="text-muted-foreground">Sem dados disponíveis</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="win-loss">
          <Card>
            <CardHeader>
              <CardTitle>Proporção de Ganhos e Perdas</CardTitle>
              <CardDescription>Distribuição de trades vencedores e perdedores</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                {winLossRatioData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={winLossRatioData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={150}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {winLossRatioData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center justify-center h-full">
                    <p className="text-muted-foreground">Sem dados disponíveis</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="strategies">
          <Card>
            <CardHeader>
              <CardTitle>Comparação de Estratégias</CardTitle>
              <CardDescription>Desempenho comparativo entre diferentes estratégias</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={strategyComparisonData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="winRate" fill="#4ade80" name="Taxa de Acerto (%)" />
                    <Bar dataKey="returnPct" fill="#60a5fa" name="Retorno (%)" />
                    <Bar dataKey="trades" fill="#a78bfa" name="Número de Trades" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
