# Painel Chatbot

Projeto do painel web do bot FlexInvest, pronto para deploy no Vercel.
