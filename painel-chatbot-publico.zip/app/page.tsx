"use client"

import { useState, useEffect, useRef } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Settings, Play, Bell, MessageSquare, BarChart3 } from "lucide-react"
import {
  fetchMarketData,
  runBacktest,
  checkAlertConditions,
  calculateSMA,
  calculateEMA,
  calculateRSI,
  calculateMACD,
  calculateBollingerBands,
  findSwingHighLow,
  calculateFibonacciLevels,
  calculateOBV,
  calculateVPT,
  calculateCMF,
  generateTradingSignal,
  executeOrder,
  simulateRealtimePrice,
  checkStopLossTakeProfit,
  calculateVolumeOscillator,
} from "@/lib/trading-utils"
import { useToast } from "@/hooks/use-toast"
import {
  sendNotification,
  formatSignalMessage,
  formatOrderMessage,
  formatErrorMessage,
} from "@/lib/notification-service"
import Link from "next/link"
import { DashboardContent } from "@/components/dashboard-content"
import { AlertsContent } from "@/components/alerts-content"
import { BacktestContent } from "@/components/backtest-content"
import { AutoTradingContent } from "@/components/auto-trading-content"
import { MainLayout } from "@/components/main-layout"

export default function TradingBot() {
  const [activeTab, setActiveTab] = useState("dashboard")
  const [marketData, setMarketData] = useState([])
  const [selectedCoin, setSelectedCoin] = useState("bitcoin")
  const [isLoading, setIsLoading] = useState(true)
  const [strategy, setStrategy] = useState({
    type: "sma",
    shortPeriod: 7,
    longPeriod: 25,
    stopLoss: 5,
    takeProfit: 10,
    bbPeriod: 20,
    bbDeviation: 2,
    fibLevels: [0.236, 0.382, 0.5, 0.618, 0.786],
    fibRetracement: "auto",
    volumePeriod: 20,
    pricePeriod: 20,
    volumeThreshold: 2.0,
    obvPeriod: 20,
    vptPeriod: 20,
    cmfPeriod: 20,
  })
  const [simulationResults, setSimulationResults] = useState(null)
  const [isSimulating, setIsSimulating] = useState(false)

  const [alerts, setAlerts] = useState([])
  const [alertHistory, setAlertHistory] = useState([])
  const [notificationSound, setNotificationSound] = useState(true)
  const alertAudioRef = useRef(null)
  const { toast } = useToast()

  // Estado para controlar os indicadores técnicos no gráfico
  const [chartIndicators, setChartIndicators] = useState({
    sma: { enabled: false, periods: [7, 25, 99] },
    ema: { enabled: false, periods: [9, 21] },
    bollinger: { enabled: false, period: 20, deviation: 2 },
    rsi: { enabled: false, period: 14 },
    macd: { enabled: false, fastPeriod: 12, slowPeriod: 26, signalPeriod: 9 },
    fibonacci: { enabled: false, levels: [0.236, 0.382, 0.5, 0.618, 0.786] },
    volume: { enabled: false },
    obv: { enabled: false },
    vpt: { enabled: false },
    cmf: { enabled: false, period: 20 },
    volumeOscillator: { enabled: false, shortPeriod: 5, longPeriod: 20 },
  })

  // Estado para armazenar os dados calculados dos indicadores
  const [indicatorData, setIndicatorData] = useState({
    sma: {},
    ema: {},
    bollinger: null,
    rsi: null,
    macd: null,
    fibonacci: null,
    obv: null,
    vpt: null,
    cmf: null,
    volumeOscillator: null,
  })

  // Estado para controlar o período de visualização do gráfico
  const [chartPeriod, setChartPeriod] = useState(30)

  // Estados para o trading automático
  const [autoTradingEnabled, setAutoTradingEnabled] = useState(false)
  const [tradingSettings, setTradingSettings] = useState({
    initialBalance: 10000,
    positionSize: 10, // Porcentagem do saldo a ser usado em cada operação
    maxOpenPositions: 3,
    trailingStopLoss: false,
    trailingPercent: 2,
    rebalanceInterval: 24, // Em horas
    riskLevel: "medium", // low, medium, high
  })
  const [tradingAccount, setTradingAccount] = useState({
    balance: 10000,
    equity: 10000,
    availableBalance: 10000,
    openPositions: [],
    closedPositions: [],
    performance: {
      totalTrades: 0,
      winningTrades: 0,
      losingTrades: 0,
      winRate: 0,
      totalProfit: 0,
      totalLoss: 0,
      netProfit: 0,
      maxDrawdown: 0,
    },
  })
  const [lastSignal, setLastSignal] = useState({ signal: null, reason: "", timestamp: null })
  const [isProcessingOrder, setIsProcessingOrder] = useState(false)
  const [currentPrice, setCurrentPrice] = useState(0)
  const [tradingLogs, setTradingLogs] = useState([])

  // Referência para o intervalo de atualização do trading automático
  const autoTradingIntervalRef = useRef(null)

  // Adicione este estado no componente TradingBot
  const [notificationConfig, setNotificationConfig] = useState({
    enabled: false,
    channels: ["telegram"],
    telegram: {
      botToken: "",
      chatId: "",
    },
    discord: {
      webhookUrl: "",
      enabled: false,
    },
  })

  // Adicione este estado no componente TradingBot
  const [discordConfig, setDiscordConfig] = useState({
    enabled: false,
    webhookUrl: "",
  })

  useEffect(() => {
    const loadMarketData = async () => {
      setIsLoading(true)
      try {
        const data = await fetchMarketData(selectedCoin)
        setMarketData(data)
        if (data.length > 0) {
          setCurrentPrice(data[data.length - 1].price)
        }
      } catch (error) {
        console.error("Erro ao carregar dados:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadMarketData()
    // Atualiza a cada 5 minutos
    const interval = setInterval(loadMarketData, 5 * 60 * 1000)
    return () => clearInterval(interval)
  }, [selectedCoin])

  // Calcular indicadores quando os dados de mercado ou configurações de indicadores mudam
  useEffect(() => {
    if (marketData.length === 0) return

    const newIndicatorData = { ...indicatorData }

    // Calcular SMAs
    if (chartIndicators.sma.enabled) {
      chartIndicators.sma.periods.forEach((period) => {
        const smaData = calculateSMA(marketData, period)
        newIndicatorData.sma[period] = smaData
      })
    }

    // Calcular EMAs
    if (chartIndicators.ema.enabled) {
      chartIndicators.ema.periods.forEach((period) => {
        const emaData = calculateEMA(
          marketData.map((d) => d.price),
          period,
        )
        newIndicatorData.ema[period] = emaData
      })
    }

    // Calcular Bollinger Bands
    if (chartIndicators.bollinger.enabled) {
      newIndicatorData.bollinger = calculateBollingerBands(
        marketData,
        chartIndicators.bollinger.period,
        chartIndicators.bollinger.deviation,
      )
    }

    // Calcular RSI
    if (chartIndicators.rsi.enabled) {
      newIndicatorData.rsi = calculateRSI(marketData, chartIndicators.rsi.period)
    }

    // Calcular MACD
    if (chartIndicators.macd.enabled) {
      newIndicatorData.macd = calculateMACD(
        marketData,
        chartIndicators.macd.fastPeriod,
        chartIndicators.macd.slowPeriod,
        chartIndicators.macd.signalPeriod,
      )
    }

    // Calcular níveis de Fibonacci
    if (chartIndicators.fibonacci.enabled) {
      const swingPoints = findSwingHighLow(marketData)
      newIndicatorData.fibonacci = calculateFibonacciLevels(
        swingPoints.high,
        swingPoints.low,
        chartIndicators.fibonacci.levels,
      )
    }

    // Calcular OBV
    if (chartIndicators.obv.enabled) {
      newIndicatorData.obv = calculateOBV(marketData)
    }

    // Calcular VPT
    if (chartIndicators.vpt.enabled) {
      newIndicatorData.vpt = calculateVPT(marketData)
    }

    // Calcular CMF
    if (chartIndicators.cmf.enabled) {
      newIndicatorData.cmf = calculateCMF(marketData, chartIndicators.cmf.period)
    }

    // Calcular Volume Oscillator
    if (chartIndicators.volumeOscillator.enabled) {
      newIndicatorData.volumeOscillator = calculateVolumeOscillator(
        marketData,
        chartIndicators.volumeOscillator.shortPeriod,
        chartIndicators.volumeOscillator.longPeriod,
      )
    }

    setIndicatorData(newIndicatorData)
  }, [marketData, chartIndicators])

  const handleStrategyChange = (field, value) => {
    setStrategy({
      ...strategy,
      [field]: field === "type" ? value : Number(value),
    })
  }

  const startSimulation = async () => {
    setIsSimulating(true)
    try {
      const results = await runBacktest(marketData, strategy)
      setSimulationResults(results)
    } catch (error) {
      console.error("Erro na simulação:", error)
    } finally {
      setIsSimulating(false)
    }
  }

  const addAlert = (newAlert) => {
    const alertWithId = {
      ...newAlert,
      id: Date.now().toString(),
      createdAt: new Date(),
      triggered: false,
    }
    setAlerts((prev) => [...prev, alertWithId])
  }

  const removeAlert = (alertId) => {
    setAlerts((prev) => prev.filter((alert) => alert.id !== alertId))
  }

  const playAlertSound = () => {
    if (notificationSound && alertAudioRef.current) {
      alertAudioRef.current.currentTime = 0
      alertAudioRef.current.play().catch((e) => console.error("Erro ao tocar som:", e))
    }
  }

  // Verificar alertas quando os dados de mercado são atualizados
  useEffect(() => {
    if (marketData.length === 0 || alerts.length === 0) return

    const currentPrice = marketData[marketData.length - 1].price
    const triggeredAlerts = checkAlertConditions(alerts, currentPrice, marketData)

    if (triggeredAlerts.length > 0) {
      // Atualizar alertas disparados
      setAlerts((prev) =>
        prev.map((alert) => {
          const triggered = triggeredAlerts.find((a) => a.id === alert.id)
          return triggered ? { ...alert, triggered: true } : alert
        }),
      )

      // Adicionar ao histórico
      const newHistoryItems = triggeredAlerts.map((alert) => ({
        ...alert,
        triggeredAt: new Date(),
        price: currentPrice,
      }))

      setAlertHistory((prev) => [...newHistoryItems, ...prev])

      // Mostrar notificações
      triggeredAlerts.forEach((alert) => {
        toast({
          title: "Alerta de Trading",
          description: `${alert.type === "price" ? "Preço" : "Indicador"} ${alert.condition} ${alert.value} ${alert.type === "price" ? "$" : ""}`,
          variant: "default",
        })
      })

      // Modifique a função que verifica alertas para enviar notificações
      // Adicione este código após detectar alertas disparados:
      if (true) {
        const message = `Implementei um sistema completo para criar e visualizar mensagens de trading no formato do Telegram, baseado nos exemplos que você compartilhou. Aqui está o que foi criado:

1. **Formatador de Mensagens do Telegram**: Um componente que formata diferentes tipos de mensagens (compra, venda, menu, flash, confirmação, erro) no estilo do Telegram.

2. **Editor de Mensagens**: Uma interface para personalizar e visualizar os diferentes formatos de mensagem, permitindo ajustar todos os parâmetros.

3. **Simulador de Interface do Telegram**: Uma simulação visual da interface do Telegram para testar como as mensagens aparecerão para os usuários.

4. **Serviço de Notificações Aprimorado**: Atualizei o serviço de notificações para suportar os novos formatos de mensagem.

Para acessar e testar os novos formatos de mensagem, você pode navegar para a rota \`/telegram-messages\` no seu aplicativo.`
        console.log(message)
      }
    }
  }, [marketData, alerts, toast])

  // Lógica para habilitar/desabilitar o trading automático
  const toggleAutoTrading = () => {
    setAutoTradingEnabled((prev) => !prev)
  }

  // Iniciar/parar o trading automático com base no estado
  useEffect(() => {
    if (autoTradingEnabled) {
      startAutoTrading()
    } else {
      stopAutoTrading()
    }
  }, [autoTradingEnabled])

  // Função para iniciar o trading automático
  const startAutoTrading = () => {
    // Verificar se já existe um intervalo rodando
    if (autoTradingIntervalRef.current) return

    // Executar a lógica de trading a cada intervalo
    autoTradingIntervalRef.current = setInterval(async () => {
      if (isProcessingOrder) return // Evitar sobreposição de ordens

      setIsProcessingOrder(true)
      try {
        // Simular preço em tempo real
        const simulatedPrice = simulateRealtimePrice(currentPrice)
        setCurrentPrice(simulatedPrice)

        // Gerar sinal de trading
        const { signal, reason } = generateTradingSignal(
          marketData,
          strategy,
          indicatorData,
          tradingAccount,
          tradingSettings,
        )

        // Registrar o último sinal gerado
        setLastSignal({ signal, reason, timestamp: new Date() })

        if (signal) {
          // Formatar a mensagem do sinal
          const signalMessage = formatSignalMessage(signal, selectedCoin, simulatedPrice, reason)

          // Enviar notificação do sinal
          sendNotification(notificationConfig, "Sinal de Trading", signalMessage)

          // Executar ordem
          const orderResult = executeOrder(signal, simulatedPrice, tradingAccount, tradingSettings)

          if (orderResult) {
            const { newPosition, updatedAccount, order } = orderResult

            // Atualizar a conta de trading
            setTradingAccount(updatedAccount)

            // Formatar a mensagem da ordem
            const orderMessage = formatOrderMessage(order.type, selectedCoin, order.price, order.quantity)

            // Enviar notificação da ordem
            sendNotification(notificationConfig, "Confirmação de Ordem", orderMessage)

            // Adicionar log de trading
            setTradingLogs((prevLogs) => [
              ...prevLogs,
              {
                timestamp: new Date(),
                type: "order",
                message: orderMessage,
              },
            ])

            // Se uma nova posição foi aberta, adicionar ao array de posições abertas
            if (newPosition) {
              setTradingAccount((prevAccount) => ({
                ...prevAccount,
                openPositions: [...prevAccount.openPositions, newPosition],
              }))
            }
          }
        }
      } catch (error) {
        console.error("Erro no trading automático:", error)

        // Formatar a mensagem de erro
        const errorMessage = formatErrorMessage(error.message)

        // Enviar notificação de erro
        sendNotification(notificationConfig, "Erro no Trading", errorMessage)

        // Adicionar log de trading
        setTradingLogs((prevLogs) => [
          ...prevLogs,
          {
            timestamp: new Date(),
            type: "error",
            message: errorMessage,
          },
        ])
      } finally {
        setIsProcessingOrder(false)
      }
    }, 15 * 1000) // Executar a cada 15 segundos
  }

  // Função para parar o trading automático
  const stopAutoTrading = () => {
    if (autoTradingIntervalRef.current) {
      clearInterval(autoTradingIntervalRef.current)
      autoTradingIntervalRef.current = null
    }
  }

  // Lógica para verificar stop loss e take profit
  useEffect(() => {
    if (marketData.length === 0 || tradingAccount.openPositions.length === 0) return

    const updatedPositions = tradingAccount.openPositions.map((position) => {
      const currentPrice = marketData[marketData.length - 1].price
      const slTpCheck = checkStopLossTakeProfit(position, currentPrice, tradingSettings)

      if (slTpCheck.closePosition) {
        // Simular o fechamento da posição
        const profit = (currentPrice - position.entryPrice) * position.quantity * position.direction
        const updatedAccount = {
          ...tradingAccount,
          balance: tradingAccount.balance + profit,
          equity: tradingAccount.equity + profit,
          availableBalance: tradingAccount.availableBalance + profit,
          openPositions: tradingAccount.openPositions.filter((p) => p.id !== position.id),
          closedPositions: [
            ...tradingAccount.closedPositions,
            { ...position, closePrice: currentPrice, profit, closeReason: slTpCheck.reason },
          ],
        }

        // Atualizar a conta de trading
        setTradingAccount(updatedAccount)

        // Formatar a mensagem de fechamento de posição
        const closeMessage = `Posição em ${selectedCoin} fechada com ${profit > 0 ? "lucro" : "prejuízo"} de $${profit.toFixed(2)} devido a ${slTpCheck.reason}.`

        // Enviar notificação de fechamento de posição
        sendNotification(notificationConfig, "Fechamento de Posição", closeMessage)

        // Adicionar log de trading
        setTradingLogs((prevLogs) => [
          ...prevLogs,
          {
            timestamp: new Date(),
            type: "position_closed",
            message: closeMessage,
          },
        ])

        return null // Remover a posição fechada
      }

      return position // Manter a posição aberta
    })

    // Atualizar as posições abertas, removendo as posições fechadas
    setTradingAccount((prevAccount) => ({
      ...prevAccount,
      openPositions: updatedPositions.filter(Boolean),
    }))
  }, [marketData, tradingAccount, tradingSettings, notificationConfig, selectedCoin])

  // Lógica para rebalancear o portfólio
  useEffect(() => {
    if (!autoTradingEnabled || tradingSettings.rebalanceInterval <= 0) return

    const rebalance = async () => {
      // Implementar a lógica de rebalanceamento aqui
      // Isso pode envolver o fechamento de posições existentes e a abertura de novas posições
      // com base em uma nova análise de mercado e nas configurações de risco
      console.log("Rebalanceando o portfólio...")
    }

    // Agendar o rebalanceamento a cada X horas
    const rebalanceInterval = tradingSettings.rebalanceInterval * 60 * 60 * 1000
    const rebalanceTimer = setInterval(rebalance, rebalanceInterval)

    return () => clearInterval(rebalanceTimer)
  }, [autoTradingEnabled, tradingSettings])

  return (
    <MainLayout>
      <div className="container mx-auto py-6">
        <h1 className="text-3xl font-bold mb-6 text-center">Trading Bot</h1>

        <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="dashboard">
              <BarChart3 className="h-4 w-4 mr-2" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="alertas">
              <Bell className="h-4 w-4 mr-2" />
              Alertas
            </TabsTrigger>
            <TabsTrigger value="backtest">
              <Play className="h-4 w-4 mr-2" />
              Backtest
            </TabsTrigger>
            <TabsTrigger value="auto-trading">
              <Play className="h-4 w-4 mr-2" />
              Auto Trading
            </TabsTrigger>
            <TabsTrigger value="configuracoes">
              <Settings className="h-4 w-4 mr-2" />
              Configurações
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="mt-5">
            <DashboardContent />
          </TabsContent>

          <TabsContent value="alertas" className="mt-5">
            <AlertsContent />
          </TabsContent>

          <TabsContent value="backtest" className="mt-5">
            <BacktestContent />
          </TabsContent>

          <TabsContent value="auto-trading" className="mt-5">
            <AutoTradingContent />
          </TabsContent>

          <TabsContent value="configuracoes" className="mt-5">
            <div className="space-y-4">
              <div>
                <h2 className="text-3xl font-bold">Configurações</h2>
                <p className="text-muted-foreground">Configurações gerais do sistema</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border">
                  <h3 className="text-lg font-medium mb-2">Telegram</h3>
                  <p className="text-muted-foreground mb-4">Configure seu bot do Telegram para receber alertas</p>
                  <Link href="/telegram-messages">
                    <button className="flex items-center px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600">
                      <MessageSquare className="h-4 w-4 mr-2" />
                      Visualizar Formatos de Mensagem
                    </button>
                  </Link>
                </div>

                <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border">
                  <h3 className="text-lg font-medium mb-2">Outros Canais</h3>
                  <p className="text-muted-foreground mb-4">Configurar notificações adicionais</p>
                  <p>Mais opções de notificação serão adicionadas em breve.</p>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  )
}
