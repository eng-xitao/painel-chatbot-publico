import { MainLayout } from "@/components/main-layout"
import { NotificationTester } from "@/components/notification-tester"

export default function VerificarNotificacoesPage() {
  return (
    <MainLayout>
      <div className="container mx-auto py-6">
        <h1 className="text-3xl font-bold mb-2">Verificar Notificações</h1>
        <p className="text-muted-foreground mb-6">
          Teste e verifique se as notificações estão sendo enviadas corretamente
        </p>

        <NotificationTester />
      </div>
    </MainLayout>
  )
}
