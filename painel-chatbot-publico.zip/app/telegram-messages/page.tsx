import { MainLayout } from "@/components/main-layout"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TelegramMessageFormatter } from "@/components/telegram-message-formatter"
import { TelegramInterfaceSimulator } from "@/components/telegram-interface-simulator"

export default function TelegramMessagesPage() {
  return (
    <MainLayout>
      <div className="container mx-auto py-6">
        <h1 className="text-3xl font-bold mb-6">Mensagens para Telegram</h1>

        <Tabs defaultValue="editor">
          <TabsList className="mb-4">
            <TabsTrigger value="editor">Editor de Mensagens</TabsTrigger>
            <TabsTrigger value="simulator">Simulador de Interface</TabsTrigger>
          </TabsList>

          <TabsContent value="editor">
            <TelegramMessageFormatter />
          </TabsContent>

          <TabsContent value="simulator">
            <TelegramInterfaceSimulator />
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  )
}
