import { fetchExchangeMarketData, type TimeInterval, exchangeManager } from "@/lib/exchange-service"

// Função para buscar dados de mercado de uma API real
export async function fetchMarketData(coinId: string, interval: TimeInterval = "1d", limit = 90) {
  try {
    // Verificar se temos exchanges configuradas
    if (exchangeManager.listExchanges().length > 0) {
      // Buscar dados da exchange configurada
      return await fetchExchangeMarketData(coinId, interval, limit)
    } else {
      console.warn("Nenhuma exchange configurada. Usando dados simulados.")
      // Usar a implementação existente como fallback
      return generateMockData(coinId)
    }
  } catch (error) {
    console.error("Erro ao buscar dados de mercado:", error)
    // Usar a implementação existente como fallback
    return generateMockData(coinId)
  }
}

// Manter a função existente como fallback
function generateMockData(coinId: string) {
  // Código existente da função generateMockData
  // ...
}
