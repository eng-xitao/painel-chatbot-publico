// Tipos de exchanges suportadas
export type ExchangeType = "binance" | "coinbase" | "kraken" | "kucoin" | "ftx"

// Configuração da API
export interface ApiConfig {
  exchange: ExchangeType
  apiKey: string
  apiSecret: string
  testnet?: boolean
}

// Intervalo de tempo para os dados
export type TimeInterval = "1m" | "5m" | "15m" | "30m" | "1h" | "4h" | "1d" | "1w" | "1M"

// Formato de dados de mercado
export interface MarketData {
  date: number // timestamp
  open: number
  high: number
  close: number
  low: number
  volume: number
  price: number // alias para close, para compatibilidade com código existente
}

// Formato de dados de ticker
export interface TickerData {
  symbol: string
  price: number
  volume: number
  change24h: number
  changePercent24h: number
  high24h: number
  low24h: number
  timestamp: number
}

// Formato de dados de orderbook
export interface OrderBookData {
  bids: [number, number][] // [preço, quantidade]
  asks: [number, number][] // [preço, quantidade]
  timestamp: number
}

// Classe base para exchanges
export abstract class Exchange {
  protected apiKey: string
  protected apiSecret: string
  protected testnet: boolean

  constructor(config: ApiConfig) {
    this.apiKey = config.apiKey
    this.apiSecret = config.apiSecret
    this.testnet = config.testnet || false
  }

  // Métodos abstratos que cada exchange deve implementar
  abstract getMarketData(symbol: string, interval: TimeInterval, limit: number): Promise<MarketData[]>
  abstract getTicker(symbol: string): Promise<TickerData>
  abstract getOrderBook(symbol: string, limit?: number): Promise<OrderBookData>
  abstract getSymbols(): Promise<string[]>
  abstract testConnection(): Promise<boolean>
}

// Implementação para Binance
export class BinanceExchange extends Exchange {
  private baseUrl: string

  constructor(config: ApiConfig) {
    super(config)
    this.baseUrl = this.testnet ? "https://testnet.binance.vision/api" : "https://api.binance.com/api"
  }

  private async makeRequest(endpoint: string, params: Record<string, any> = {}, method = "GET"): Promise<any> {
    try {
      const url = new URL(`${this.baseUrl}${endpoint}`)

      // Adicionar parâmetros à URL para requisições GET
      if (method === "GET" && Object.keys(params).length > 0) {
        Object.keys(params).forEach((key) => {
          url.searchParams.append(key, params[key])
        })
      }

      const headers: HeadersInit = {
        "X-MBX-APIKEY": this.apiKey,
      }

      const options: RequestInit = {
        method,
        headers,
      }

      // Adicionar corpo para requisições não-GET
      if (method !== "GET" && Object.keys(params).length > 0) {
        options.body = JSON.stringify(params)
        headers["Content-Type"] = "application/json"
      }

      const response = await fetch(url.toString(), options)

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(`Binance API error: ${errorData.msg || response.statusText}`)
      }

      return await response.json()
    } catch (error) {
      console.error("Erro na requisição à API da Binance:", error)
      throw error
    }
  }

  async getMarketData(symbol: string, interval: TimeInterval, limit = 100): Promise<MarketData[]> {
    try {
      const formattedSymbol = symbol.replace("-", "")
      const data = await this.makeRequest("/v3/klines", {
        symbol: formattedSymbol,
        interval,
        limit,
      })

      return data.map((item: any[]) => ({
        date: item[0], // timestamp de abertura
        open: Number.parseFloat(item[1]),
        high: Number.parseFloat(item[2]),
        low: Number.parseFloat(item[3]),
        close: Number.parseFloat(item[4]),
        volume: Number.parseFloat(item[5]),
        price: Number.parseFloat(item[4]), // alias para close
      }))
    } catch (error) {
      console.error(`Erro ao buscar dados de mercado para ${symbol}:`, error)
      throw error
    }
  }

  async getTicker(symbol: string): Promise<TickerData> {
    try {
      const formattedSymbol = symbol.replace("-", "")
      const data = await this.makeRequest("/v3/ticker/24hr", { symbol: formattedSymbol })

      return {
        symbol,
        price: Number.parseFloat(data.lastPrice),
        volume: Number.parseFloat(data.volume),
        change24h: Number.parseFloat(data.priceChange),
        changePercent24h: Number.parseFloat(data.priceChangePercent),
        high24h: Number.parseFloat(data.highPrice),
        low24h: Number.parseFloat(data.lowPrice),
        timestamp: Date.now(),
      }
    } catch (error) {
      console.error(`Erro ao buscar ticker para ${symbol}:`, error)
      throw error
    }
  }

  async getOrderBook(symbol: string, limit = 20): Promise<OrderBookData> {
    try {
      const formattedSymbol = symbol.replace("-", "")
      const data = await this.makeRequest("/v3/depth", {
        symbol: formattedSymbol,
        limit,
      })

      return {
        bids: data.bids.map((item: string[]) => [Number.parseFloat(item[0]), Number.parseFloat(item[1])]),
        asks: data.asks.map((item: string[]) => [Number.parseFloat(item[0]), Number.parseFloat(item[1])]),
        timestamp: Date.now(),
      }
    } catch (error) {
      console.error(`Erro ao buscar orderbook para ${symbol}:`, error)
      throw error
    }
  }

  async getSymbols(): Promise<string[]> {
    try {
      const data = await this.makeRequest("/v3/exchangeInfo")
      return data.symbols
        .filter((item: any) => item.status === "TRADING")
        .map((item: any) => `${item.baseAsset}-${item.quoteAsset}`)
    } catch (error) {
      console.error("Erro ao buscar símbolos disponíveis:", error)
      throw error
    }
  }

  async testConnection(): Promise<boolean> {
    try {
      await this.makeRequest("/v3/ping")
      return true
    } catch (error) {
      console.error("Erro ao testar conexão com a Binance:", error)
      return false
    }
  }
}

// Implementação para Coinbase
export class CoinbaseExchange extends Exchange {
  private baseUrl: string

  constructor(config: ApiConfig) {
    super(config)
    this.baseUrl = "https://api.exchange.coinbase.com"
  }

  private async makeRequest(endpoint: string, params: Record<string, any> = {}, method = "GET"): Promise<any> {
    try {
      const url = new URL(`${this.baseUrl}${endpoint}`)

      // Adicionar parâmetros à URL para requisições GET
      if (method === "GET" && Object.keys(params).length > 0) {
        Object.keys(params).forEach((key) => {
          url.searchParams.append(key, params[key])
        })
      }

      const headers: HeadersInit = {}

      // Adicionar autenticação se apiKey e apiSecret estiverem disponíveis
      if (this.apiKey && this.apiSecret) {
        // Implementação simplificada - em produção, seria necessário implementar
        // a assinatura HMAC conforme documentação da Coinbase
        headers["CB-ACCESS-KEY"] = this.apiKey
      }

      const options: RequestInit = {
        method,
        headers,
      }

      // Adicionar corpo para requisições não-GET
      if (method !== "GET" && Object.keys(params).length > 0) {
        options.body = JSON.stringify(params)
        headers["Content-Type"] = "application/json"
      }

      const response = await fetch(url.toString(), options)

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(`Coinbase API error: ${errorData.message || response.statusText}`)
      }

      return await response.json()
    } catch (error) {
      console.error("Erro na requisição à API da Coinbase:", error)
      throw error
    }
  }

  async getMarketData(symbol: string, interval: TimeInterval, limit = 100): Promise<MarketData[]> {
    try {
      // Converter intervalo para formato da Coinbase
      const granularity = this.convertIntervalToSeconds(interval)
      const formattedSymbol = symbol.replace("-", "-")

      const data = await this.makeRequest(`/products/${formattedSymbol}/candles`, {
        granularity,
      })

      // Coinbase retorna dados em ordem inversa (mais recente primeiro)
      return data
        .reverse()
        .slice(0, limit)
        .map((item: any[]) => ({
          date: item[0] * 1000, // timestamp em segundos para milissegundos
          low: item[1],
          high: item[2],
          open: item[3],
          close: item[4],
          volume: item[5],
          price: item[4], // alias para close
        }))
    } catch (error) {
      console.error(`Erro ao buscar dados de mercado para ${symbol}:`, error)
      throw error
    }
  }

  private convertIntervalToSeconds(interval: TimeInterval): number {
    const map: Record<TimeInterval, number> = {
      "1m": 60,
      "5m": 300,
      "15m": 900,
      "30m": 1800,
      "1h": 3600,
      "4h": 14400,
      "1d": 86400,
      "1w": 604800,
      "1M": 2592000,
    }
    return map[interval]
  }

  async getTicker(symbol: string): Promise<TickerData> {
    try {
      const formattedSymbol = symbol.replace("-", "-")
      const data = await this.makeRequest(`/products/${formattedSymbol}/ticker`)
      const stats = await this.makeRequest(`/products/${formattedSymbol}/stats`)

      return {
        symbol,
        price: Number.parseFloat(data.price),
        volume: Number.parseFloat(data.volume),
        change24h: Number.parseFloat(stats.open) - Number.parseFloat(data.price),
        changePercent24h: (Number.parseFloat(data.price) / Number.parseFloat(stats.open) - 1) * 100,
        high24h: Number.parseFloat(stats.high),
        low24h: Number.parseFloat(stats.low),
        timestamp: new Date(data.time).getTime(),
      }
    } catch (error) {
      console.error(`Erro ao buscar ticker para ${symbol}:`, error)
      throw error
    }
  }

  async getOrderBook(symbol: string, limit = 20): Promise<OrderBookData> {
    try {
      const formattedSymbol = symbol.replace("-", "-")
      const level = limit <= 50 ? 2 : 3 // Nível 2 para até 50 ordens, nível 3 para mais

      const data = await this.makeRequest(`/products/${formattedSymbol}/book`, {
        level,
      })

      return {
        bids: data.bids
          .slice(0, limit)
          .map((item: string[]) => [Number.parseFloat(item[0]), Number.parseFloat(item[1])]),
        asks: data.asks
          .slice(0, limit)
          .map((item: string[]) => [Number.parseFloat(item[0]), Number.parseFloat(item[1])]),
        timestamp: Date.now(),
      }
    } catch (error) {
      console.error(`Erro ao buscar orderbook para ${symbol}:`, error)
      throw error
    }
  }

  async getSymbols(): Promise<string[]> {
    try {
      const data = await this.makeRequest("/products")
      return data.map((item: any) => `${item.base_currency}-${item.quote_currency}`)
    } catch (error) {
      console.error("Erro ao buscar símbolos disponíveis:", error)
      throw error
    }
  }

  async testConnection(): Promise<boolean> {
    try {
      await this.makeRequest("/products")
      return true
    } catch (error) {
      console.error("Erro ao testar conexão com a Coinbase:", error)
      return false
    }
  }
}

// Implementação para Kraken (simplificada)
export class KrakenExchange extends Exchange {
  private baseUrl: string

  constructor(config: ApiConfig) {
    super(config)
    this.baseUrl = "https://api.kraken.com"
  }

  async getMarketData(symbol: string, interval: TimeInterval, limit = 100): Promise<MarketData[]> {
    // Implementação simplificada
    try {
      const response = await fetch(
        `${this.baseUrl}/0/public/OHLC?pair=${symbol}&interval=${this.convertInterval(interval)}`,
      )
      const data = await response.json()

      if (data.error && data.error.length > 0) {
        throw new Error(`Kraken API error: ${data.error.join(", ")}`)
      }

      // Kraken retorna dados em um objeto com o símbolo como chave
      const symbolKey = Object.keys(data.result).find((key) => key !== "last")
      if (!symbolKey) {
        throw new Error("Símbolo não encontrado na resposta")
      }

      return data.result[symbolKey].slice(0, limit).map((item: any[]) => ({
        date: item[0] * 1000, // timestamp em segundos para milissegundos
        open: Number.parseFloat(item[1]),
        high: Number.parseFloat(item[2]),
        low: Number.parseFloat(item[3]),
        close: Number.parseFloat(item[4]),
        volume: Number.parseFloat(item[6]),
        price: Number.parseFloat(item[4]), // alias para close
      }))
    } catch (error) {
      console.error(`Erro ao buscar dados de mercado para ${symbol}:`, error)
      throw error
    }
  }

  private convertInterval(interval: TimeInterval): number {
    const map: Record<TimeInterval, number> = {
      "1m": 1,
      "5m": 5,
      "15m": 15,
      "30m": 30,
      "1h": 60,
      "4h": 240,
      "1d": 1440,
      "1w": 10080,
      "1M": 21600,
    }
    return map[interval]
  }

  async getTicker(symbol: string): Promise<TickerData> {
    // Implementação simplificada
    try {
      const response = await fetch(`${this.baseUrl}/0/public/Ticker?pair=${symbol}`)
      const data = await response.json()

      if (data.error && data.error.length > 0) {
        throw new Error(`Kraken API error: ${data.error.join(", ")}`)
      }

      const symbolKey = Object.keys(data.result)[0]
      const ticker = data.result[symbolKey]

      return {
        symbol,
        price: Number.parseFloat(ticker.c[0]),
        volume: Number.parseFloat(ticker.v[1]),
        change24h: 0, // Kraken não fornece diretamente
        changePercent24h: 0, // Kraken não fornece diretamente
        high24h: Number.parseFloat(ticker.h[1]),
        low24h: Number.parseFloat(ticker.l[1]),
        timestamp: Date.now(),
      }
    } catch (error) {
      console.error(`Erro ao buscar ticker para ${symbol}:`, error)
      throw error
    }
  }

  async getOrderBook(symbol: string, limit = 20): Promise<OrderBookData> {
    // Implementação simplificada
    try {
      const response = await fetch(`${this.baseUrl}/0/public/Depth?pair=${symbol}&count=${limit}`)
      const data = await response.json()

      if (data.error && data.error.length > 0) {
        throw new Error(`Kraken API error: ${data.error.join(", ")}`)
      }

      const symbolKey = Object.keys(data.result)[0]
      const orderbook = data.result[symbolKey]

      return {
        bids: orderbook.bids.map((item: string[]) => [Number.parseFloat(item[0]), Number.parseFloat(item[1])]),
        asks: orderbook.asks.map((item: string[]) => [Number.parseFloat(item[0]), Number.parseFloat(item[1])]),
        timestamp: Date.now(),
      }
    } catch (error) {
      console.error(`Erro ao buscar orderbook para ${symbol}:`, error)
      throw error
    }
  }

  async getSymbols(): Promise<string[]> {
    // Implementação simplificada
    try {
      const response = await fetch(`${this.baseUrl}/0/public/AssetPairs`)
      const data = await response.json()

      if (data.error && data.error.length > 0) {
        throw new Error(`Kraken API error: ${data.error.join(", ")}`)
      }

      return Object.keys(data.result).map((key) => {
        const pair = data.result[key]
        return `${pair.base}-${pair.quote}`
      })
    } catch (error) {
      console.error("Erro ao buscar símbolos disponíveis:", error)
      throw error
    }
  }

  async testConnection(): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}/0/public/Time`)
      const data = await response.json()
      return data.error.length === 0
    } catch (error) {
      console.error("Erro ao testar conexão com a Kraken:", error)
      return false
    }
  }
}

// Factory para criar instâncias de exchanges
export function createExchange(config: ApiConfig): Exchange {
  switch (config.exchange) {
    case "binance":
      return new BinanceExchange(config)
    case "coinbase":
      return new CoinbaseExchange(config)
    case "kraken":
      return new KrakenExchange(config)
    default:
      throw new Error(`Exchange não suportada: ${config.exchange}`)
  }
}

// Classe para gerenciar múltiplas exchanges
export class ExchangeManager {
  private exchanges: Map<string, Exchange> = new Map()
  private defaultExchange: string | null = null

  // Adicionar uma exchange
  addExchange(name: string, config: ApiConfig): void {
    try {
      const exchange = createExchange(config)
      this.exchanges.set(name, exchange)

      // Se for a primeira exchange, definir como padrão
      if (this.exchanges.size === 1) {
        this.defaultExchange = name
      }
    } catch (error) {
      console.error(`Erro ao adicionar exchange ${name}:`, error)
      throw error
    }
  }

  // Remover uma exchange
  removeExchange(name: string): void {
    this.exchanges.delete(name)

    // Se a exchange padrão foi removida, atualizar
    if (this.defaultExchange === name) {
      this.defaultExchange = this.exchanges.size > 0 ? Array.from(this.exchanges.keys())[0] : null
    }
  }

  // Definir exchange padrão
  setDefaultExchange(name: string): void {
    if (!this.exchanges.has(name)) {
      throw new Error(`Exchange ${name} não encontrada`)
    }
    this.defaultExchange = name
  }

  // Obter uma exchange específica
  getExchange(name?: string): Exchange {
    const exchangeName = name || this.defaultExchange

    if (!exchangeName) {
      throw new Error("Nenhuma exchange configurada")
    }

    const exchange = this.exchanges.get(exchangeName)

    if (!exchange) {
      throw new Error(`Exchange ${exchangeName} não encontrada`)
    }

    return exchange
  }

  // Listar todas as exchanges configuradas
  listExchanges(): string[] {
    return Array.from(this.exchanges.keys())
  }

  // Verificar se uma exchange está configurada
  hasExchange(name: string): boolean {
    return this.exchanges.has(name)
  }

  // Testar conexão com todas as exchanges
  async testAllConnections(): Promise<Record<string, boolean>> {
    const results: Record<string, boolean> = {}

    for (const [name, exchange] of this.exchanges.entries()) {
      try {
        results[name] = await exchange.testConnection()
      } catch (error) {
        results[name] = false
      }
    }

    return results
  }
}

// Instância global do gerenciador de exchanges
export const exchangeManager = new ExchangeManager()

// Função para buscar dados de mercado de qualquer exchange
export async function fetchExchangeMarketData(
  symbol: string,
  interval: TimeInterval = "1d",
  limit = 90,
  exchangeName?: string,
): Promise<MarketData[]> {
  try {
    const exchange = exchangeManager.getExchange(exchangeName)
    return await exchange.getMarketData(symbol, interval, limit)
  } catch (error) {
    console.error(`Erro ao buscar dados de mercado para ${symbol}:`, error)

    // Fallback para dados simulados em caso de erro
    console.warn("Usando dados simulados como fallback")
    return generateMockMarketData(symbol, limit)
  }
}

// Função para gerar dados simulados (fallback)
function generateMockMarketData(symbol: string, limit = 90): MarketData[] {
  // Preços base para diferentes criptomoedas (valores aproximados)
  const basePrices: Record<string, number> = {
    "BTC-USD": 50000,
    "ETH-USD": 3000,
    "USDT-USD": 1,
    "BNB-USD": 400,
    "XRP-USD": 0.5,
    "SOL-USD": 100,
    "ADA-USD": 1.2,
    "DOGE-USD": 0.1,
    "DOT-USD": 20,
    "MATIC-USD": 1.5,
    "LTC-USD": 150,
    "SHIB-USD": 0.00001,
    "AVAX-USD": 30,
    "LINK-USD": 15,
    "UNI-USD": 10,
    "XLM-USD": 0.3,
    "ATOM-USD": 12,
    "XMR-USD": 180,
    "ETC-USD": 25,
    "FIL-USD": 5,
  }

  // Usar o preço base específico ou um valor padrão
  const basePrice = basePrices[symbol] || 10

  const volatility = 0.03 // 3% de volatilidade diária
  const now = Date.now()
  const oneDayMs = 24 * 60 * 60 * 1000

  let currentPrice = basePrice
  const data: MarketData[] = []

  for (let i = 0; i < limit; i++) {
    const date = now - (limit - i) * oneDayMs

    // Simular movimento de preço com tendência aleatória
    const change = (Math.random() - 0.5) * 2 * volatility
    currentPrice = currentPrice * (1 + change)

    // Adicionar alguma sazonalidade semanal
    if (i % 7 === 0) {
      currentPrice = currentPrice * (1 + (Math.random() - 0.3) * 0.05)
    }

    // Calcular high, low, open com base no close
    const dailyVolatility = volatility * 0.5
    const high = currentPrice * (1 + Math.random() * dailyVolatility)
    const low = currentPrice * (1 - Math.random() * dailyVolatility)
    const open = low + Math.random() * (high - low)

    // Simular volume
    const volume = basePrice * currentPrice * (Math.random() * 5000 + 1000)

    data.push({
      date,
      open,
      high,
      low,
      close: currentPrice,
      price: currentPrice,
      volume,
    })
  }

  return data
}
