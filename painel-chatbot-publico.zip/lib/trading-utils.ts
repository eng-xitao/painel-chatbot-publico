// Funções utilitárias para o robô de trading

// Função para buscar dados de mercado de uma API gratuita
export async function fetchMarketData(coinId: string) {
  try {
    // Usando a API gratuita do CoinGecko
    const response = await fetch(
      `https://api.coingecko.com/api/v3/coins/${coinId}/market_chart?vs_currency=usd&days=90&interval=daily`,
    )

    if (!response.ok) {
      throw new Error(`Erro ao buscar dados: ${response.status}`)
    }

    const data = await response.json()

    // Formatar os dados para uso no gráfico
    return data.prices.map((item: [number, number], index: number) => {
      const timestamp = item[0]
      const price = item[1]

      // Adicionar volume se disponível
      const volume = data.total_volumes[index] ? data.total_volumes[index][1] : 0

      return {
        date: timestamp,
        price,
        volume,
      }
    })
  } catch (error) {
    console.error("Erro ao buscar dados de mercado:", error)

    // Retornar dados simulados em caso de erro ou limite de API
    return generateMockData(coinId)
  }
}

// Função para gerar dados simulados caso a API falhe
function generateMockData(coinId: string) {
  // Preços base para diferentes criptomoedas (valores aproximados)
  const basePrices = {
    bitcoin: 50000,
    ethereum: 3000,
    tether: 1,
    binancecoin: 400,
    ripple: 0.5,
    solana: 100,
    cardano: 1.2,
    dogecoin: 0.1,
    polkadot: 20,
    "matic-network": 1.5,
    litecoin: 150,
    "shiba-inu": 0.00001,
    "avalanche-2": 30,
    chainlink: 15,
    uniswap: 10,
    stellar: 0.3,
    cosmos: 12,
    monero: 180,
    "ethereum-classic": 25,
    filecoin: 5,
    "hedera-hashgraph": 0.08,
    "internet-computer": 8,
    near: 4,
    vechain: 0.03,
    algorand: 0.5,
    tezos: 2,
    "the-sandbox": 0.7,
    decentraland: 0.8,
    aave: 100,
    eos: 1.2,
  }

  // Usar o preço base específico ou um valor padrão
  const basePrice = basePrices[coinId] || 10

  const volatility = 0.03 // 3% de volatilidade diária
  const days = 90
  const now = Date.now()
  const oneDayMs = 24 * 60 * 60 * 1000

  let currentPrice = basePrice
  const data = []

  for (let i = 0; i < days; i++) {
    const date = now - (days - i) * oneDayMs

    // Simular movimento de preço com tendência aleatória
    const change = (Math.random() - 0.5) * 2 * volatility
    currentPrice = currentPrice * (1 + change)

    // Adicionar alguma sazonalidade semanal
    if (i % 7 === 0) {
      currentPrice = currentPrice * (1 + (Math.random() - 0.3) * 0.05)
    }

    // Simular volume
    const volume = basePrice * currentPrice * (Math.random() * 5000 + 1000)

    data.push({
      date,
      price: currentPrice,
      volume,
    })
  }

  return data
}

// Função para calcular médias móveis
export function calculateSMA(data: any[], period: number) {
  const result = []

  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) {
      result.push(null)
      continue
    }

    let sum = 0
    for (let j = 0; j < period; j++) {
      sum += data[i - j].price
    }

    result.push(sum / period)
  }

  return result
}

// Função para calcular RSI
export function calculateRSI(data: any[], period: number) {
  const result = []
  const gains = []
  const losses = []

  // Primeiro, calcular ganhos e perdas
  for (let i = 1; i < data.length; i++) {
    const change = data[i].price - data[i - 1].price
    gains.push(change > 0 ? change : 0)
    losses.push(change < 0 ? Math.abs(change) : 0)

    if (i < period) {
      result.push(null)
      continue
    }

    // Calcular médias de ganhos e perdas
    let avgGain = 0
    let avgLoss = 0

    for (let j = 0; j < period; j++) {
      avgGain += gains[i - j - 1]
      avgLoss += losses[i - j - 1]
    }

    avgGain /= period
    avgLoss /= period

    // Evitar divisão por zero
    if (avgLoss === 0) {
      result.push(100)
    } else {
      const rs = avgGain / avgLoss
      const rsi = 100 - 100 / (1 + rs)
      result.push(rsi)
    }
  }

  return result
}

// Função para calcular MACD
export function calculateMACD(data: any[], fastPeriod: number, slowPeriod: number, signalPeriod: number) {
  const fastEMA = calculateEMA(
    data.map((d) => d.price),
    fastPeriod,
  )
  const slowEMA = calculateEMA(
    data.map((d) => d.price),
    slowPeriod,
  )

  const macdLine = []

  // Calcular linha MACD (diferença entre EMAs)
  for (let i = 0; i < data.length; i++) {
    if (i < slowPeriod - 1) {
      macdLine.push(null)
    } else {
      macdLine.push(fastEMA[i] - slowEMA[i])
    }
  }

  // Calcular linha de sinal (EMA da linha MACD)
  const signalLine = calculateEMA(
    macdLine.filter((val) => val !== null),
    signalPeriod,
  )

  // Preencher valores nulos no início
  const fullSignalLine = Array(slowPeriod + signalPeriod - 2)
    .fill(null)
    .concat(signalLine)

  // Calcular histograma (diferença entre MACD e linha de sinal)
  const histogram = []
  for (let i = 0; i < data.length; i++) {
    if (i < slowPeriod + signalPeriod - 2) {
      histogram.push(null)
    } else {
      histogram.push(macdLine[i] - fullSignalLine[i])
    }
  }

  return {
    macdLine,
    signalLine: fullSignalLine,
    histogram,
  }
}

// Função auxiliar para calcular EMA
export function calculateEMA(data: number[], period: number) {
  const result = []
  const multiplier = 2 / (period + 1)

  // Inicializar com SMA
  let sum = 0
  for (let i = 0; i < period; i++) {
    sum += data[i]
  }

  let ema = sum / period
  result.push(ema)

  // Calcular EMA para o restante dos dados
  for (let i = period; i < data.length; i++) {
    ema = (data[i] - ema) * multiplier + ema
    result.push(ema)
  }

  // Preencher valores nulos no início
  return Array(period - 1)
    .fill(null)
    .concat(result)
}

// Função para calcular desvio padrão
function calculateStandardDeviation(data: number[], mean: number, period: number) {
  let sum = 0
  for (let i = 0; i < period; i++) {
    sum += Math.pow(data[i] - mean, 2)
  }
  return Math.sqrt(sum / period)
}

// Função para calcular Bollinger Bands
export function calculateBollingerBands(data: any[], period: number, deviation: number) {
  const result = []

  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) {
      result.push({
        middle: null,
        upper: null,
        lower: null,
      })
      continue
    }

    // Calcular SMA (linha do meio)
    let sum = 0
    const priceSlice = data.slice(i - period + 1, i + 1).map((d) => d.price)
    for (let j = 0; j < period; j++) {
      sum += priceSlice[j]
    }
    const middle = sum / period

    // Calcular desvio padrão
    const stdDev = calculateStandardDeviation(priceSlice, middle, period)

    // Calcular bandas superior e inferior
    const upper = middle + stdDev * deviation
    const lower = middle - stdDev * deviation

    result.push({
      middle,
      upper,
      lower,
    })
  }

  return result
}

// Função para identificar pontos de alta e baixa para Fibonacci
export function findSwingHighLow(data: any[], lookback = 10) {
  if (data.length < lookback * 2) {
    // Não há dados suficientes
    return {
      high: data[data.length - 1].price,
      highIndex: data.length - 1,
      low: data[0].price,
      lowIndex: 0,
    }
  }

  let high = Number.NEGATIVE_INFINITY
  let low = Number.POSITIVE_INFINITY
  let highIndex = 0
  let lowIndex = 0

  // Encontrar máximos e mínimos nos dados recentes
  for (let i = data.length - lookback; i < data.length; i++) {
    if (data[i].price > high) {
      high = data[i].price
      highIndex = i
    }
    if (data[i].price < low) {
      low = data[i].price
      lowIndex = i
    }
  }

  return { high, highIndex, low, lowIndex }
}

// Função para calcular níveis de Fibonacci
export function calculateFibonacciLevels(high: number, low: number, levels: number[]) {
  const range = high - low
  return levels.map((level) => ({
    level,
    price: high - range * level,
  }))
}

// Função para calcular Volume Moving Average (VMA)
export function calculateVMA(data: any[], period: number) {
  const result = []

  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) {
      result.push(null)
      continue
    }

    let sum = 0
    for (let j = 0; j < period; j++) {
      sum += data[i - j].volume
    }

    result.push(sum / period)
  }

  return result
}

// Função para calcular On-Balance Volume (OBV)
export function calculateOBV(data: any[]) {
  const result = []
  let obv = 0

  for (let i = 0; i < data.length; i++) {
    if (i === 0) {
      result.push(obv)
      continue
    }

    const currentPrice = data[i].price
    const previousPrice = data[i - 1].price
    const currentVolume = data[i].volume

    if (currentPrice > previousPrice) {
      // Preço subiu, adicionar volume
      obv += currentVolume
    } else if (currentPrice < previousPrice) {
      // Preço caiu, subtrair volume
      obv -= currentVolume
    }
    // Se o preço não mudou, o OBV permanece o mesmo

    result.push(obv)
  }

  return result
}

// Função para calcular Volume Price Trend (VPT)
export function calculateVPT(data: any[]) {
  const result = []
  let vpt = 0

  for (let i = 0; i < data.length; i++) {
    if (i === 0) {
      result.push(vpt)
      continue
    }

    const currentPrice = data[i].price
    const previousPrice = data[i - 1].price
    const currentVolume = data[i].volume

    // Calcular a variação percentual do preço
    const priceChange = (currentPrice - previousPrice) / previousPrice

    // Calcular o VPT
    vpt += currentVolume * priceChange
    result.push(vpt)
  }

  return result
}

// Função para calcular Volume Oscillator
export function calculateVolumeOscillator(data: any[], shortPeriod: number, longPeriod: number) {
  const shortVMA = calculateVMA(data, shortPeriod)
  const longVMA = calculateVMA(data, longPeriod)
  const result = []

  for (let i = 0; i < data.length; i++) {
    if (i < longPeriod - 1) {
      result.push(null)
      continue
    }

    // Calcular a diferença percentual entre as médias móveis de volume
    const shortValue = shortVMA[i]
    const longValue = longVMA[i]
    const percentDiff = ((shortValue - longValue) / longValue) * 100
    result.push(percentDiff)
  }

  return result
}

// Função para calcular Volume Breakout
export function calculateVolumeBreakout(data: any[], volumePeriod: number, pricePeriod: number, threshold: number) {
  const volumeMA = calculateVMA(data, volumePeriod)
  const priceMA = calculateSMA(data, pricePeriod)
  const result = []

  for (let i = 0; i < data.length; i++) {
    if (i < Math.max(volumePeriod, pricePeriod) - 1) {
      result.push(null)
      continue
    }

    const currentVolume = data[i].volume
    const avgVolume = volumeMA[i]
    const currentPrice = data[i].price
    const avgPrice = priceMA[i]

    // Verificar se o volume atual é significativamente maior que a média
    const volumeRatio = currentVolume / avgVolume
    const priceAboveMA = currentPrice > avgPrice

    // Sinal de breakout: volume acima do threshold e preço acima da média
    if (volumeRatio > threshold && priceAboveMA) {
      result.push(1) // Sinal de compra
    } else if (volumeRatio > threshold && !priceAboveMA) {
      result.push(-1) // Sinal de venda
    } else {
      result.push(0) // Sem sinal
    }
  }

  return result
}

// Função para calcular Chaikin Money Flow (CMF)
export function calculateCMF(data: any[], period: number) {
  const result = []

  for (let i = 0; i < data.length; i++) {
    if (i < period) {
      result.push(null)
      continue
    }

    let sumMoneyFlowVolume = 0
    let sumVolume = 0

    for (let j = i - period + 1; j <= i; j++) {
      const high = data[j].price * 1.005 // Simulando high (0.5% acima do preço)
      const low = data[j].price * 0.995 // Simulando low (0.5% abaixo do preço)
      const close = data[j].price
      const volume = data[j].volume

      // Calcular Money Flow Multiplier
      const mfMultiplier = (close - low - (high - close)) / (high - low)

      // Calcular Money Flow Volume
      const mfVolume = mfMultiplier * volume

      sumMoneyFlowVolume += mfVolume
      sumVolume += volume
    }

    // Calcular Chaikin Money Flow
    const cmf = sumVolume !== 0 ? sumMoneyFlowVolume / sumVolume : 0
    result.push(cmf)
  }

  return result
}

// Função para executar backtest da estratégia
export async function runBacktest(marketData: any[], strategy: any) {
  // Simular um atraso para dar feedback visual ao usuário
  await new Promise((resolve) => setTimeout(resolve, 1500))

  if (!marketData || marketData.length < 30) {
    throw new Error("Dados de mercado insuficientes para backtest")
  }

  const initialCapital = 1000 // Capital inicial em USD
  let capital = initialCapital
  let inPosition = false
  let entryPrice = 0
  let entryDate = null

  const trades = []
  const equityCurve = [{ date: marketData[0].date, equity: capital }]

  const signals = []

  // Calcular indicadores com base na estratégia selecionada
  if (strategy.type === "sma") {
    // Código existente para SMA
    const shortSMA = calculateSMA(marketData, strategy.shortPeriod)
    const longSMA = calculateSMA(marketData, strategy.longPeriod)

    // Gerar sinais de compra/venda baseados no cruzamento de médias
    for (let i = 0; i < marketData.length; i++) {
      if (i < strategy.longPeriod) {
        signals.push(null)
        continue
      }

      const shortAboveLong = shortSMA[i] > longSMA[i]
      const shortBelowLong = shortSMA[i] < longSMA[i]
      const prevShortAboveLong = shortSMA[i - 1] > longSMA[i - 1]
      const prevShortBelowLong = shortSMA[i - 1] < longSMA[i - 1]

      // Sinal de compra: média curta cruza para cima da média longa
      if (shortAboveLong && prevShortBelowLong) {
        signals.push("buy")
      }
      // Sinal de venda: média curta cruza para baixo da média longa
      else if (shortBelowLong && prevShortAboveLong) {
        signals.push("sell")
      } else {
        signals.push(null)
      }
    }
  } else if (strategy.type === "rsi") {
    // Código existente para RSI
    const rsi = calculateRSI(marketData, strategy.shortPeriod)

    // Gerar sinais baseados no RSI
    for (let i = 0; i < marketData.length; i++) {
      if (i < strategy.shortPeriod) {
        signals.push(null)
        continue
      }

      // Sinal de compra: RSI cruza abaixo de 30 (sobrevendido)
      if (rsi[i] < 30 && rsi[i - 1] >= 30) {
        signals.push("buy")
      }
      // Sinal de venda: RSI cruza acima de 70 (sobrecomprado)
      else if (rsi[i] > 70 && rsi[i - 1] <= 70) {
        signals.push("sell")
      } else {
        signals.push(null)
      }
    }
  } else if (strategy.type === "macd") {
    // Código existente para MACD
    const signalPeriod = strategy.signalPeriod || 9
    const macd = calculateMACD(marketData, strategy.shortPeriod, strategy.longPeriod, signalPeriod)

    // Gerar sinais baseados no MACD
    for (let i = 0; i < marketData.length; i++) {
      if (i < strategy.longPeriod + signalPeriod - 1) {
        signals.push(null)
        continue
      }

      // Verificar cruzamento da linha MACD com a linha de sinal
      const macdAboveSignal = macd.macdLine[i] > macd.signalLine[i]
      const macdBelowSignal = macd.macdLine[i] < macd.signalLine[i]
      const prevMacdAboveSignal = macd.macdLine[i - 1] > macd.signalLine[i - 1]
      const prevMacdBelowSignal = macd.macdLine[i - 1] < macd.signalLine[i - 1]

      // Sinal de compra: MACD cruza para cima da linha de sinal
      if (macdAboveSignal && prevMacdBelowSignal) {
        signals.push("buy")
      }
      // Sinal de venda: MACD cruza para baixo da linha de sinal
      else if (macdBelowSignal && prevMacdAboveSignal) {
        signals.push("sell")
      } else {
        signals.push(null)
      }
    }
  } else if (strategy.type === "bollinger") {
    // Implementação da estratégia de Bollinger Bands
    const period = strategy.bbPeriod || 20
    const deviation = strategy.bbDeviation || 2
    const bands = calculateBollingerBands(marketData, period, deviation)

    // Gerar sinais baseados nas Bollinger Bands
    for (let i = 0; i < marketData.length; i++) {
      if (i < period) {
        signals.push(null)
        continue
      }

      const price = marketData[i].price
      const prevPrice = marketData[i - 1].price
      const band = bands[i]
      const prevBand = bands[i - 1]

      // Sinal de compra: preço cruza para cima da banda inferior
      if (prevPrice <= prevBand.lower && price > band.lower) {
        signals.push("buy")
      }
      // Sinal de venda: preço cruza para baixo da banda superior
      else if (prevPrice >= prevBand.upper && price < band.upper) {
        signals.push("sell")
      }
      // Sinal de venda: preço toca na banda do meio vindo de baixo
      else if (prevPrice < prevBand.middle && price >= band.middle && inPosition) {
        signals.push("sell")
      } else {
        signals.push(null)
      }
    }
  } else if (strategy.type === "fibonacci") {
    // Implementação da estratégia de Fibonacci
    let high, low

    if (strategy.fibRetracement === "manual" && strategy.fibHigh && strategy.fibLow) {
      high = Number.parseFloat(strategy.fibHigh)
      low = Number.parseFloat(strategy.fibLow)
    } else {
      // Modo automático: encontrar pontos de alta e baixa recentes
      const swingPoints = findSwingHighLow(marketData)
      high = swingPoints.high
      low = swingPoints.low
    }

    // Calcular níveis de Fibonacci
    const fibLevels = calculateFibonacciLevels(high, low, strategy.fibLevels)

    // Gerar sinais baseados nos níveis de Fibonacci
    for (let i = 0; i < marketData.length; i++) {
      if (i < 1) {
        signals.push(null)
        continue
      }

      const price = marketData[i].price
      const prevPrice = marketData[i - 1].price

      // Verificar se o preço cruza algum nível de Fibonacci
      let signal = null

      for (const fib of fibLevels) {
        // Sinal de compra: preço cruza para cima de um nível de Fibonacci
        if (prevPrice < fib.price && price >= fib.price && !inPosition) {
          signal = "buy"
          break
        }
        // Sinal de venda: preço cruza para baixo de um nível de Fibonacci
        else if (prevPrice > fib.price && price <= fib.price && inPosition) {
          signal = "sell"
          break
        }
      }

      signals.push(signal)
    }
  } else if (strategy.type === "volume_breakout") {
    // Implementação da estratégia de Volume Breakout
    const volumePeriod = strategy.volumePeriod || 20
    const pricePeriod = strategy.pricePeriod || 20
    const threshold = strategy.volumeThreshold || 2.0

    const breakoutSignals = calculateVolumeBreakout(marketData, volumePeriod, pricePeriod, threshold)

    // Gerar sinais baseados no Volume Breakout
    for (let i = 0; i < marketData.length; i++) {
      if (i < Math.max(volumePeriod, pricePeriod)) {
        signals.push(null)
        continue
      }

      if (breakoutSignals[i] === 1) {
        signals.push("buy")
      } else if (breakoutSignals[i] === -1) {
        signals.push("sell")
      } else {
        signals.push(null)
      }
    }
  } else if (strategy.type === "obv") {
    // Implementação da estratégia de On-Balance Volume (OBV)
    const obvPeriod = strategy.obvPeriod || 20
    const obv = calculateOBV(marketData)
    const obvMA = calculateEMA(obv, obvPeriod)

    // Gerar sinais baseados no OBV
    for (let i = 0; i < marketData.length; i++) {
      if (i < obvPeriod || i < 1) {
        signals.push(null)
        continue
      }

      const currentOBV = obv[i]
      const previousOBV = obv[i - 1]
      const currentOBVMA = obvMA[i]
      const previousOBVMA = obvMA[i - 1]

      // Sinal de compra: OBV cruza para cima da sua média móvel
      if (previousOBV < previousOBVMA && currentOBV > currentOBVMA) {
        signals.push("buy")
      }
      // Sinal de venda: OBV cruza para baixo da sua média móvel
      else if (previousOBV > previousOBVMA && currentOBV < currentOBVMA) {
        signals.push("sell")
      } else {
        signals.push(null)
      }
    }
  } else if (strategy.type === "vpt") {
    // Implementação da estratégia de Volume Price Trend (VPT)
    const vptPeriod = strategy.vptPeriod || 20
    const vpt = calculateVPT(marketData)
    const vptMA = calculateEMA(vpt, vptPeriod)

    // Gerar sinais baseados no VPT
    for (let i = 0; i < marketData.length; i++) {
      if (i < vptPeriod || i < 1) {
        signals.push(null)
        continue
      }

      const currentVPT = vpt[i]
      const previousVPT = vpt[i - 1]
      const currentVPTMA = vptMA[i]
      const previousVPTMA = vptMA[i - 1]

      // Sinal de compra: VPT cruza para cima da sua média móvel
      if (previousVPT < previousVPTMA && currentVPT > currentVPTMA) {
        signals.push("buy")
      }
      // Sinal de venda: VPT cruza para baixo da sua média móvel
      else if (previousVPT > previousVPTMA && currentVPT < currentVPTMA) {
        signals.push("sell")
      } else {
        signals.push(null)
      }
    }
  } else if (strategy.type === "cmf") {
    // Implementação da estratégia de Chaikin Money Flow (CMF)
    const cmfPeriod = strategy.cmfPeriod || 20
    const cmf = calculateCMF(marketData, cmfPeriod)

    // Gerar sinais baseados no CMF
    for (let i = 0; i < marketData.length; i++) {
      if (i < cmfPeriod || i < 1) {
        signals.push(null)
        continue
      }

      const currentCMF = cmf[i]
      const previousCMF = cmf[i - 1]

      // Sinal de compra: CMF cruza de negativo para positivo
      if (previousCMF < 0 && currentCMF > 0) {
        signals.push("buy")
      }
      // Sinal de venda: CMF cruza de positivo para negativo
      else if (previousCMF > 0 && currentCMF < 0) {
        signals.push("sell")
      } else {
        signals.push(null)
      }
    }
  }

  // Resto do código existente para executar a simulação...
  // Executar a simulação com os sinais gerados
  let maxCapital = initialCapital
  let maxDrawdown = 0

  for (let i = 1; i < marketData.length; i++) {
    const currentPrice = marketData[i].price
    const signal = signals[i]

    // Verificar stop loss e take profit se estiver em posição
    if (inPosition) {
      const priceDiff = ((currentPrice - entryPrice) / entryPrice) * 100

      // Stop loss atingido
      if (priceDiff <= -strategy.stopLoss) {
        const profit = -strategy.stopLoss / 100
        capital = capital * (1 + profit)

        trades.push({
          type: "buy",
          entryDate,
          entryPrice,
          exitDate: marketData[i].date,
          exitPrice: entryPrice * (1 - strategy.stopLoss / 100),
          profit: -strategy.stopLoss,
          reason: "stop_loss",
        })

        inPosition = false
      }
      // Take profit atingido
      else if (priceDiff >= strategy.takeProfit) {
        const profit = strategy.takeProfit / 100
        capital = capital * (1 + profit)

        trades.push({
          type: "buy",
          entryDate,
          entryPrice,
          exitDate: marketData[i].date,
          exitPrice: entryPrice * (1 + strategy.takeProfit / 100),
          profit: strategy.takeProfit,
          reason: "take_profit",
        })

        inPosition = false
      }
      // Sinal de venda
      else if (signal === "sell") {
        const profit = (currentPrice - entryPrice) / entryPrice
        capital = capital * (1 + profit)

        trades.push({
          type: "buy",
          entryDate,
          entryPrice,
          exitDate: marketData[i].date,
          exitPrice: currentPrice,
          profit: profit * 100,
          reason: "signal",
        })

        inPosition = false
      }
    }
    // Não está em posição e recebeu sinal de compra
    else if (signal === "buy") {
      inPosition = true
      entryPrice = currentPrice
      entryDate = marketData[i].date
    }

    // Atualizar curva de capital
    equityCurve.push({
      date: marketData[i].date,
      equity: capital,
    })

    // Atualizar máximo capital e drawdown
    if (capital > maxCapital) {
      maxCapital = capital
    } else {
      const drawdown = ((maxCapital - capital) / maxCapital) * 100
      if (drawdown > maxDrawdown) {
        maxDrawdown = drawdown
      }
    }
  }

  // Fechar posição no final do período se ainda estiver aberta
  if (inPosition) {
    const lastPrice = marketData[marketData.length - 1].price
    const profit = (lastPrice - entryPrice) / entryPrice
    capital = capital * (1 + profit)

    trades.push({
      type: "buy",
      entryDate,
      entryPrice,
      exitDate: marketData[marketData.length - 1].date,
      exitPrice: lastPrice,
      profit: profit * 100,
      reason: "end_of_period",
    })
  }

  // Calcular estatísticas
  const totalReturn = ((capital - initialCapital) / initialCapital) * 100
  const winningTrades = trades.filter((trade) => trade.profit > 0).length
  const winRate = (winningTrades / trades.length) * 100 || 0

  return {
    totalReturn,
    totalTrades: trades.length,
    winningTrades,
    winRate,
    maxDrawdown,
    finalCapital: capital,
    trades,
    equityCurve,
  }
}

// Função para verificar condições de alerta
export function checkAlertConditions(alerts, currentPrice, marketData) {
  if (!alerts || alerts.length === 0 || !marketData || marketData.length < 2) {
    return []
  }

  const previousPrice = marketData[marketData.length - 2].price
  const triggeredAlerts = []

  alerts.forEach((alert) => {
    // Pular alertas já disparados
    if (alert.triggered) return

    // Verificar condições de preço
    if (alert.type === "price") {
      switch (alert.condition) {
        case "above":
          if (currentPrice > alert.value) {
            triggeredAlerts.push(alert)
          }
          break
        case "below":
          if (currentPrice < alert.value) {
            triggeredAlerts.push(alert)
          }
          break
        case "crosses_above":
          if (previousPrice <= alert.value && currentPrice > alert.value) {
            triggeredAlerts.push(alert)
          }
          break
        case "crosses_below":
          if (previousPrice >= alert.value && currentPrice < alert.value) {
            triggeredAlerts.push(alert)
          }
          break
      }
    }
    // Verificar condições de indicador
    else if (alert.type === "indicator") {
      // Implementação simplificada para RSI
      if (marketData.length >= 14) {
        const rsi = calculateRSI(marketData, 14)
        const currentRSI = rsi[rsi.length - 1]
        const previousRSI = rsi[rsi.length - 2]

        switch (alert.condition) {
          case "above":
            if (currentRSI > alert.value) {
              triggeredAlerts.push(alert)
            }
            break
          case "below":
            if (currentRSI < alert.value) {
              triggeredAlerts.push(alert)
            }
            break
          case "crosses_above":
            if (previousRSI <= alert.value && currentRSI > alert.value) {
              triggeredAlerts.push(alert)
            }
            break
          case "crosses_below":
            if (previousRSI >= alert.value && currentRSI < alert.value) {
              triggeredAlerts.push(alert)
            }
            break
        }
      }
    }
    // Verificar condições de sinal
    else if (alert.type === "signal") {
      // Implementação para sinais de estratégia
      // Aqui você pode adicionar lógica para verificar sinais da sua estratégia
      // Por exemplo, cruzamento de médias móveis, etc.

      // Exemplo simplificado para demonstração:
      if (marketData.length >= 25) {
        const shortSMA = calculateSMA(marketData, 7)
        const longSMA = calculateSMA(marketData, 25)

        const currentShortAboveLong = shortSMA[shortSMA.length - 1] > longSMA[longSMA.length - 1]
        const prevShortAboveLong = shortSMA[shortSMA.length - 2] > longSMA[longSMA.length - 2]

        // Sinal de compra: média curta cruza para cima da média longa
        if (!prevShortAboveLong && currentShortAboveLong && alert.condition === "crosses_above") {
          triggeredAlerts.push(alert)
        }
        // Sinal de venda: média curta cruza para baixo da média longa
        else if (prevShortAboveLong && !currentShortAboveLong && alert.condition === "crosses_below") {
          triggeredAlerts.push(alert)
        }
      }
    }
    // Verificar condições de volume
    else if (alert.type === "volume") {
      if (marketData.length >= 20) {
        const volumeMA = calculateVMA(marketData, 20)
        const currentVolume = marketData[marketData.length - 1].volume
        const avgVolume = volumeMA[volumeMA.length - 1]
        const volumeRatio = currentVolume / avgVolume

        switch (alert.condition) {
          case "above":
            if (volumeRatio > alert.value) {
              triggeredAlerts.push(alert)
            }
            break
          case "below":
            if (volumeRatio < alert.value) {
              triggeredAlerts.push(alert)
            }
            break
        }
      }
    }
  })

  return triggeredAlerts
}

// Função para gerar sinais de trading em tempo real
export function generateTradingSignal(marketData: any[], strategy: any) {
  if (!marketData || marketData.length < 30) {
    return { signal: null, reason: "Dados insuficientes" }
  }

  // Obter os dados mais recentes
  const currentPrice = marketData[marketData.length - 1].price
  const previousPrice = marketData[marketData.length - 2].price

  let signal = null
  let reason = ""

  // Gerar sinal com base na estratégia selecionada
  if (strategy.type === "sma") {
    const shortSMA = calculateSMA(marketData, strategy.shortPeriod)
    const longSMA = calculateSMA(marketData, strategy.longPeriod)

    const currentShortSMA = shortSMA[shortSMA.length - 1]
    const currentLongSMA = longSMA[longSMA.length - 1]
    const prevShortSMA = shortSMA[shortSMA.length - 2]
    const prevLongSMA = longSMA[longSMA.length - 2]

    // Sinal de compra: média curta cruza para cima da média longa
    if (prevShortSMA <= prevLongSMA && currentShortSMA > currentLongSMA) {
      signal = "buy"
      reason = `SMA ${strategy.shortPeriod} cruzou acima de SMA ${strategy.longPeriod}`
    }
    // Sinal de venda: média curta cruza para baixo da média longa
    else if (prevShortSMA >= prevLongSMA && currentShortSMA < currentLongSMA) {
      signal = "sell"
      reason = `SMA ${strategy.shortPeriod} cruzou abaixo de SMA ${strategy.longPeriod}`
    }
  } else if (strategy.type === "rsi") {
    const rsi = calculateRSI(marketData, strategy.shortPeriod)
    const currentRSI = rsi[rsi.length - 1]
    const prevRSI = rsi[rsi.length - 2]

    // Sinal de compra: RSI cruza acima de 30 (saindo de sobrevendido)
    if (prevRSI <= 30 && currentRSI > 30) {
      signal = "buy"
      reason = `RSI saiu da zona de sobrevendido (${currentRSI.toFixed(2)})`
    }
    // Sinal de venda: RSI cruza abaixo de 70 (saindo de sobrecomprado)
    else if (prevRSI >= 70 && currentRSI < 70) {
      signal = "sell"
      reason = `RSI saiu da zona de sobrecomprado (${currentRSI.toFixed(2)})`
    }
  } else if (strategy.type === "macd") {
    const signalPeriod = strategy.signalPeriod || 9
    const macd = calculateMACD(marketData, strategy.shortPeriod, strategy.longPeriod, signalPeriod)

    const currentMACD = macd.macdLine[macd.macdLine.length - 1]
    const currentSignal = macd.signalLine[macd.signalLine.length - 1]
    const prevMACD = macd.macdLine[macd.macdLine.length - 2]
    const prevSignal = macd.signalLine[macd.signalLine.length - 2]

    // Sinal de compra: MACD cruza para cima da linha de sinal
    if (prevMACD <= prevSignal && currentMACD > currentSignal) {
      signal = "buy"
      reason = "MACD cruzou acima da linha de sinal"
    }
    // Sinal de venda: MACD cruza para baixo da linha de sinal
    else if (prevMACD >= prevSignal && currentMACD < currentSignal) {
      signal = "sell"
      reason = "MACD cruzou abaixo da linha de sinal"
    }
  } else if (strategy.type === "bollinger") {
    const period = strategy.bbPeriod || 20
    const deviation = strategy.bbDeviation || 2
    const bands = calculateBollingerBands(marketData, period, deviation)

    const currentBand = bands[bands.length - 1]
    const prevBand = bands[bands.length - 2]

    // Sinal de compra: preço cruza para cima da banda inferior
    if (previousPrice <= prevBand.lower && currentPrice > currentBand.lower) {
      signal = "buy"
      reason = "Preço cruzou acima da banda inferior de Bollinger"
    }
    // Sinal de venda: preço cruza para baixo da banda superior
    else if (previousPrice >= prevBand.upper && currentPrice < currentBand.upper) {
      signal = "sell"
      reason = "Preço cruzou abaixo da banda superior de Bollinger"
    }
  } else if (strategy.type === "volume_breakout") {
    const volumePeriod = strategy.volumePeriod || 20
    const pricePeriod = strategy.pricePeriod || 20
    const threshold = strategy.volumeThreshold || 2.0

    const volumeMA = calculateVMA(marketData, volumePeriod)
    const priceMA = calculateSMA(marketData, pricePeriod)

    const currentVolume = marketData[marketData.length - 1].volume
    const avgVolume = volumeMA[volumeMA.length - 1]
    const avgPrice = priceMA[priceMA.length - 1]

    const volumeRatio = currentVolume / avgVolume

    // Sinal de compra: volume acima do threshold e preço acima da média
    if (volumeRatio > threshold && currentPrice > avgPrice) {
      signal = "buy"
      reason = `Volume ${volumeRatio.toFixed(1)}x acima da média com preço acima da SMA ${pricePeriod}`
    }
    // Sinal de venda: volume acima do threshold e preço abaixo da média
    else if (volumeRatio > threshold && currentPrice < avgPrice) {
      signal = "sell"
      reason = `Volume ${volumeRatio.toFixed(1)}x acima da média com preço abaixo da SMA ${pricePeriod}`
    }
  } else if (strategy.type === "obv") {
    const obvPeriod = strategy.obvPeriod || 20
    const obv = calculateOBV(marketData)
    const obvMA = calculateEMA(obv, obvPeriod)

    const currentOBV = obv[obv.length - 1]
    const previousOBV = obv[obv.length - 2]
    const currentOBVMA = obvMA[obvMA.length - 1]
    const previousOBVMA = obvMA[obvMA.length - 2]

    // Sinal de compra: OBV cruza para cima da sua média móvel
    if (previousOBV < previousOBVMA && currentOBV > currentOBVMA) {
      signal = "buy"
      reason = `OBV cruzou acima da sua média móvel de ${obvPeriod} períodos`
    }
    // Sinal de venda: OBV cruza para baixo da sua média móvel
    else if (previousOBV > previousOBVMA && currentOBV < currentOBVMA) {
      signal = "sell"
      reason = `OBV cruzou abaixo da sua média móvel de ${obvPeriod} períodos`
    }
  } else if (strategy.type === "vpt") {
    const vptPeriod = strategy.vptPeriod || 20
    const vpt = calculateVPT(marketData)
    const vptMA = calculateEMA(vpt, vptPeriod)

    const currentVPT = vpt[vpt.length - 1]
    const previousVPT = vpt[vpt.length - 2]
    const currentVPTMA = vptMA[vptMA.length - 1]
    const previousVPTMA = vptMA[vptMA.length - 2]

    // Sinal de compra: VPT cruza para cima da sua média móvel
    if (previousVPT < previousVPTMA && currentVPT > currentVPTMA) {
      signal = "buy"
      reason = `VPT cruzou acima da sua média móvel de ${vptPeriod} períodos`
    }
    // Sinal de venda: VPT cruza para baixo da sua média móvel
    else if (previousVPT > previousVPTMA && currentVPT < currentVPTMA) {
      signal = "sell"
      reason = `VPT cruzou abaixo da sua média móvel de ${vptPeriod} períodos`
    }
  } else if (strategy.type === "cmf") {
    const cmfPeriod = strategy.cmfPeriod || 20
    const cmf = calculateCMF(marketData, cmfPeriod)

    const currentCMF = cmf[cmf.length - 1]
    const previousCMF = cmf[cmf.length - 2]

    // Sinal de compra: CMF cruza de negativo para positivo
    if (previousCMF < 0 && currentCMF > 0) {
      signal = "buy"
      reason = "CMF cruzou de negativo para positivo"
    }
    // Sinal de venda: CMF cruza de positivo para negativo
    else if (previousCMF > 0 && currentCMF < 0) {
      signal = "sell"
      reason = "CMF cruzou de positivo para negativo"
    }
  }

  return { signal, reason }
}

// Função para simular a execução de uma ordem
export function executeOrder(type: "buy" | "sell", price: number, amount: number, positionSize: number, fee = 0.1) {
  // Simular uma pequena variação no preço de execução (slippage)
  const slippage = type === "buy" ? 1 + Math.random() * 0.002 : 1 - Math.random() * 0.002
  const executionPrice = price * slippage

  // Calcular o tamanho da ordem em unidades
  const units = (amount * positionSize) / executionPrice

  // Calcular a taxa
  const feeAmount = (units * executionPrice * fee) / 100

  return {
    type,
    price: executionPrice,
    units,
    fee: feeAmount,
    total: type === "buy" ? units * executionPrice + feeAmount : units * executionPrice - feeAmount,
    timestamp: new Date(),
  }
}

// Função para simular a atualização de preço em tempo real
export function simulateRealtimePrice(lastPrice: number, volatility = 0.002) {
  // Gerar uma variação aleatória entre -volatility e +volatility
  const change = (Math.random() * 2 - 1) * volatility
  const newPrice = lastPrice * (1 + change)
  return newPrice
}

// Função para calcular o valor atual de uma posição
export function calculatePositionValue(entryPrice: number, currentPrice: number, units: number) {
  const value = units * currentPrice
  const pnl = units * (currentPrice - entryPrice)
  const pnlPercent = ((currentPrice - entryPrice) / entryPrice) * 100

  return {
    value,
    pnl,
    pnlPercent,
  }
}

// Função para verificar condições de stop loss e take profit
export function checkStopLossTakeProfit(
  position: any,
  currentPrice: number,
  stopLossPercent: number,
  takeProfitPercent: number,
) {
  if (!position) return { shouldExit: false, reason: "" }

  const entryPrice = position.entryPrice
  const pnlPercent = ((currentPrice - entryPrice) / entryPrice) * 100

  if (pnlPercent <= -stopLossPercent) {
    return { shouldExit: true, reason: "stop_loss" }
  }

  if (pnlPercent >= takeProfitPercent) {
    return { shouldExit: true, reason: "take_profit" }
  }

  return { shouldExit: false, reason: "" }
}
