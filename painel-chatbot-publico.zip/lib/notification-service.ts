// Serviço de notificações para o robô de trading

type NotificationChannel = "telegram" | "discord" | "email" | "app"

interface NotificationConfig {
  enabled: boolean
  channels: NotificationChannel[]
  telegram?: {
    botToken: string
    chatId: string
  }
  discord?: {
    webhookUrl: string
    enabled: boolean
  }
  email?: {
    recipient: string
  }
}

// Função para enviar notificação via Telegram
export async function sendTelegramNotification(
  botToken: string,
  chatId: string,
  message: string,
  parseMode: "HTML" | "Markdown" | "MarkdownV2" = "HTML",
): Promise<boolean> {
  try {
    const url = `https://api.telegram.org/bot${botToken}/sendMessage`
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: parseMode,
      }),
    })

    if (!response.ok) {
      const errorData = await response.json()
      console.error("Erro ao enviar notificação Telegram:", errorData)
      return false
    }

    return true
  } catch (error) {
    console.error("Erro ao enviar notificação Telegram:", error)
    return false
  }
}

// Função para enviar notificação via Discord
export async function sendDiscordNotification(
  webhookUrl: string,
  title: string,
  message: string,
  color = 3447003, // Azul por padrão
): Promise<boolean> {
  try {
    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        content: null,
        embeds: [
          {
            title,
            description: message,
            color,
            timestamp: new Date().toISOString(),
            footer: {
              text: "Robô de Trading",
            },
          },
        ],
      }),
    })

    if (!response.ok) {
      console.error("Erro ao enviar notificação Discord:", await response.text())
      return false
    }

    return true
  } catch (error) {
    console.error("Erro ao enviar notificação Discord:", error)
    return false
  }
}

// Função para formatar mensagem de alerta
export function formatAlertMessage(alert: any, price: number): string {
  const alertType =
    alert.type === "price"
      ? "Preço"
      : alert.type === "indicator"
        ? "Indicador"
        : alert.type === "signal"
          ? "Sinal"
          : alert.type === "volume"
            ? "Volume"
            : "Alerta"

  const condition =
    alert.condition === "above"
      ? "acima de"
      : alert.condition === "below"
        ? "abaixo de"
        : alert.condition === "crosses_above"
          ? "cruzou para cima de"
          : alert.condition === "crosses_below"
            ? "cruzou para baixo de"
            : alert.condition

  return `🚨 Alerta de Trading 🚨

${alertType} ${condition} ${alert.value}${alert.type === "price" ? "$" : ""}

Preço atual: $${price.toFixed(2)}
Data: ${new Date().toLocaleString()}`
}

// Função para formatar mensagem de sinal de trading
export function formatSignalMessage(signal: string, coin: string, price: number, reason: string): string {
  const signalEmoji = signal === "buy" ? "🟢" : "🔴"
  const signalText = signal === "buy" ? "COMPRA" : "VENDA"
  const variation1h = (Math.random() * 2 - 1).toFixed(2) // Simulação de variação
  const confidence = Math.floor(Math.random() * 30) + 50 // Simulação de confiabilidade entre 50-80%

  const now = new Date()
  const entryTime = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })

  return `🚨 Alerta de Trading - FlexInvest

📊 Moeda: ${coin.toUpperCase()}
💲 Preço Atual: R$${price.toFixed(2)}
${signalEmoji} Ação: ${signalText}
📊 Variação 1h: ${variation1h}%
✅ Confiabilidade: ${confidence}%

🕒 Horário de Entrada: ${entryTime}
⏳ Expiração: Entrada válida por 3 minutos

📝 Justificativa: ${reason}

🤖 Sinal gerado automaticamente por FlexInvest`
}

// Função para formatar mensagem de execução de ordem
export function formatOrderMessage(type: "buy" | "sell", coin: string, price: number, quantity: number): string {
  const orderEmoji = type === "buy" ? "🟢" : "🔴"
  const orderText = type === "buy" ? "COMPRA" : "VENDA"
  const now = new Date()
  const time = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })

  let message = `✅ Operação Confirmada

📊 ${coin.toUpperCase()} - ${orderText}
💰 Preço: R$${price.toFixed(2)}
🕒 Horário: ${time}`

  message += `\n\nOperação executada com sucesso! Aguarde o próximo sinal.`

  return message
}

// Função para formatar mensagem de erro
export function formatErrorMessage(message: string): string {
  return `❌ Operação Não Realizada

⚠️ Motivo: ${message}

Tente novamente quando o mercado estabilizar.`
}

// Função para formatar mensagem de sinal flash
export function formatFlashSignal(
  symbol: string,
  action: "buy" | "sell",
  entryTime: string,
  expirationMinutes: number,
  gale1Time: string,
  gale2Time: string,
  maxGale: number,
): string {
  const actionEmoji = action === "buy" ? "🟢" : "🔴"
  const actionText = action === "buy" ? "COMPRA" : "VENDA"

  return `📢 Flash: ${symbol}
⏳ Expiração: ${expirationMinutes} minutos
${actionEmoji} ${actionText}
🕒 Entrada: ${entryTime}

Gale 1 - ${gale1Time}
Gale 2 - ${gale2Time}

👉 Até gale ${maxGale} se necessário

🔗 Clique aqui para abrir a corretora`
}

// Função para formatar menu principal
export function formatMainMenu(notificationsEnabled: boolean): string {
  return `🤖 FlexInvest Trading Bot - Menu Principal 🤖

${notificationsEnabled ? "🔔 Notificações: ON" : "🔕 Notificações: OFF"}

📊 Ver Sinais Ativos
⚙️ Configurações
📈 Escolher Moedas
ℹ️ Status do Sistema
❓ Ajuda`
}

// Função para enviar notificação com base na configuração
export async function sendNotification(
  config: NotificationConfig,
  title: string,
  message: string,
  type: "alert" | "signal" | "order" | "flash" | "menu" | "error" = "alert",
): Promise<boolean> {
  if (!config.enabled) return false

  let success = false

  // Determinar título e cor com base no tipo
  let color = 3447003 // Azul por padrão

  if (type === "alert") {
    color = 16711680 // Vermelho
  } else if (type === "signal") {
    color = message.includes("COMPRA") ? 5763719 : 16711680 // Verde ou Vermelho
  } else if (type === "order") {
    color = message.includes("COMPRA") ? 5763719 : 16711680 // Verde ou Vermelho
  } else if (type === "flash") {
    color = 16750848 // Laranja
  } else if (type === "error") {
    color = 16711680 // Vermelho
  }

  // Enviar via Telegram se configurado
  if (config.channels.includes("telegram") && config.telegram?.botToken && config.telegram?.chatId) {
    const telegramSuccess = await sendTelegramNotification(config.telegram.botToken, config.telegram.chatId, message)
    success = success || telegramSuccess
  }

  // Enviar via Discord se configurado
  if (config.channels.includes("discord") && config.discord?.webhookUrl && config.discord?.enabled) {
    const discordSuccess = await sendDiscordNotification(config.discord.webhookUrl, title, message, color)
    success = success || discordSuccess
  }

  // Aqui poderia adicionar outros canais como email, etc.

  return success
}
